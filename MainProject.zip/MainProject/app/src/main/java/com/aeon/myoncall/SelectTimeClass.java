package com.aeon.myoncall;

import android.os.Bundle;

public class SelectTimeClass extends BaseActivity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		setScreenName("SetTime Screen");
		
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dialog_selecttime);
	}
}
