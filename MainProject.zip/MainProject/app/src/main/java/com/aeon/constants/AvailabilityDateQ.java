package com.aeon.constants;

public class AvailabilityDateQ {

	String date_to;

	public String getDate_to() {
		return date_to;
	}

	public void setDate_to(String date_to) {
		this.date_to = date_to;
	}
	
}
