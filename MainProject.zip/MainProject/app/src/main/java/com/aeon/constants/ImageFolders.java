package com.aeon.constants;

public class ImageFolders {

	
	String folder_img_path;

	String folder_path;
	String folder_name;
	public String getImagescounr() {
		return imagescounr;
	}
	public void setImagescounr(String imagescounr) {
		this.imagescounr = imagescounr;
	}
	String imagescounr;
	
	public String getFolder_img_path() {
		return folder_img_path;
	}
	public void setFolder_img_path(String folder_img_path) {
		this.folder_img_path = folder_img_path;
	}
	public String getFolder_path() {
		return folder_path;
	}
	public void setFolder_path(String folder_path) {
		this.folder_path = folder_path;
	}
	public String getFolder_name() {
		return folder_name;
	}
	public void setFolder_name(String folder_name) {
		this.folder_name = folder_name;
	}
}
