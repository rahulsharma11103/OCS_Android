package com.wagmob.golearningbus.model.requestModel;


public class CoursesSubscriptionRequest {
    public String course_id;
}
