package com.wagmob.golearningbus.feature.glb;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.notification.NotificationPaymentCheck;
import com.wagmob.golearningbus.util.ImageUtil;
import com.wagmob.golearningbus.util.JavaUtil;
import com.wagmob.golearningbus.view.LoadDataFragment;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;

/**
 * Show edCast App Details
 *
 * @author rahul sharma
 */
public class GLBFragmentTab extends LoadDataFragment {

    Context mContext;
    @BindString(R.string.install_he_library_app)
    String mInstallTheAppString;
    @BindString(R.string.open_the_library_app)
    String mOpenTheAppString;
    @BindView(R.id.library_title_view)
    AppCompatTextView mLibraryTitle;
    @BindView(R.id.library_title_description)
    AppCompatTextView mLibraryDescription;
    @BindView(R.id.library_image)
    AppCompatImageView mLibraryImage;
    @BindView(R.id.install_the_app_view)
    AppCompatButton mInstallTheAppButton;
    @BindView(R.id.adView)
    AdView mAdView;


    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    EventBus mEventBus;
    @Inject
    SharedPreferences mSharedPreference;
    private Unbinder mUnbinder;
    private boolean mIsAppInstallOrNot;
    private String mPackageName;
    boolean mIsNotificationPaymentCheckComplete;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.edcast_fragment, container, false);
        mUnbinder = ButterKnife.bind(this, view);
        mContext = getContext();
        return view;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (mContext != null) {
            initializeComponent();
            initializeLibrary();
            if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null
                    && mGlobalApp.appSettingModel.data.library != null && mGlobalApp.appSettingModel.data.library.android_bundleurl != null) {

                mPackageName = mGlobalApp.appSettingModel.data.library.android_bundleurl;
            }
            mIsAppInstallOrNot = new JavaUtil().appInstalledOrNot(mContext, mPackageName);
            if (mIsAppInstallOrNot) {
                mInstallTheAppButton.setText(mOpenTheAppString);
            } else {
                mInstallTheAppButton.setText(mInstallTheAppString);

            }
        }
    }

    private void initializeLibrary() {
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null
                && mGlobalApp.appSettingModel.data.library != null && mGlobalApp.appSettingModel.data.library.title != null) {

            mLibraryTitle.setText(mGlobalApp.appSettingModel.data.library.title);
            mLibraryDescription.setText(mGlobalApp.appSettingModel.data.library.description);
            new ImageUtil().loadImage(mContext, mGlobalApp.appSettingModel.data.library.libraryimage_url, mLibraryImage, R.drawable.placeholder_default_rectangular, false, true);
        }
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item = menu.findItem(R.id.search_icon);
        item.setVisible(false);
        super.onPrepareOptionsMenu(menu);
    }

    @OnClick(R.id.install_the_app_view)
    public void installTheAppButton() {
        if (mIsAppInstallOrNot) {
            try {
                Intent LaunchIntent = mContext.getPackageManager()
                        .getLaunchIntentForPackage(mPackageName);
                startActivity(LaunchIntent);
            } catch (Exception ex) {

            }
        } else {
            if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null
                    && mGlobalApp.appSettingModel.data.library != null && mGlobalApp.appSettingModel.data.library.android_url != null) {
                new JavaUtil().openPlayStoreByPlayStoreUrl(mContext, mGlobalApp.appSettingModel.data.library.android_url);
            }
        }
    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    /**
     * register event bus
     */
    @Override
    public void onStart() {
        super.onStart();
        if (!mEventBus.isRegistered(this)) {
            mEventBus.register(this);
        }

    }

    public void onEvent(NotificationPaymentCheck notificationPaymentCheck) {
        boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
        mIsNotificationPaymentCheckComplete = true;
        if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);
        } else {
            mAdView.setVisibility(View.GONE);
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {

            if (mAdView != null && mIsNotificationPaymentCheckComplete && mSharedPreference != null) {
                boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

                if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                    AdRequest adRequest = new AdRequest.Builder().build();
                    mAdView.loadAd(adRequest);
                } else {
                    mAdView.setVisibility(View.GONE);
                }
            }
        }
    }

    /*private void setupWebView() {
        mGoLearningBusWebView.getSettings().setJavaScriptEnabled(true);
        mGoLearningBusWebView.getSettings().setLoadsImagesAutomatically(true);
        mGoLearningBusWebView.getSettings().setUseWideViewPort(true);
        mGoLearningBusWebView.getSettings().setLoadWithOverviewMode(true);
        mGoLearningBusWebView.getSettings().setSupportZoom(true);
        mGoLearningBusWebView.getSettings().setBuiltInZoomControls(true);
        //  mTutorialWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);


        //   mTutorialWebView.getSettings().setDomStorageEnabled(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mGoLearningBusWebView.getSettings().setMixedContentMode(mGoLearningBusWebView.getSettings().MIXED_CONTENT_ALWAYS_ALLOW);
        }
        showLoading();
        mGoLearningBusWebView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

            public void onPageFinished(WebView view, String url) {
                hideLoading();
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {

                Toast.makeText(mContext, "Oh no! " + description, Toast.LENGTH_SHORT).show();
                hideLoading();

            }
        });
        if (mGlobalApp.appSettingModel.data.settings.deeplink != null) {
            mGoLearningBusWebView.loadUrl(mGlobalApp.appSettingModel.data.settings.deeplink);
        }

    }*/


}
