package com.wagmob.golearningbus.feature.setting;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.Toast;


import com.google.android.gms.ads.AdView;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.util.IabHelper;
import com.wagmob.golearningbus.util.IabResult;
import com.wagmob.golearningbus.util.Inventory;
import com.wagmob.golearningbus.util.JavaUtil;
import com.wagmob.golearningbus.util.Purchase;
import com.wagmob.golearningbus.view.BaseActivity;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by Rahul on 6/2/2017.
 */

public class SettingActivity extends BaseActivity {
    @BindView(R.id.toolbar)
    Toolbar mToolBar;


    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @BindString(R.string.sku_key)
    String mSkuKey;
    @BindString(R.string.payload_for_payment)
    String mPayload;
    @BindString(R.string.something__went_wrong)
    String mSomethingWrong;
    @BindString(R.string.restore_successfully)
    String mRestoreSuccess;
    @BindString(R.string.restore_failed)
    String mRestoreFailed;
    @BindString(R.string.base64_key_string)
    String mBase64Key;
    Context mContext;
    IabHelper mHelper;
    boolean mIsUserAlreadyPurchase;


    SettingFragment.SettingInterface settingInterface = new SettingFragment.SettingInterface() {
        @Override
        public void restorePurchase() {


            if (mIsUserAlreadyPurchase) {
                SharedPreferences.Editor editor = mSharedPreference.edit();
                editor.putBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, true);
                editor.commit();
                Toast.makeText(mContext, mRestoreSuccess, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(mContext, mRestoreFailed, Toast.LENGTH_LONG).show();
            }
        }

    };
    private Unbinder mUnBinder;
    private SettingFragment mSettingFragment;

    /**
     * @param context current activity context
     * @return intent of activity
     */
    public static Intent callingIntent(Context context) {
        return new Intent(context, SettingActivity.class);
    }

    /**
     * Use to initialize layout and App bar
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_common);
        mUnBinder = ButterKnife.bind(this);
        initializeComponent();
        mHelper = new IabHelper(this, mBase64Key);
        mHelper.startSetup(new
                                   IabHelper.OnIabSetupFinishedListener() {
                                       public void onIabSetupFinished(IabResult result) {
                                           if (!result.isSuccess()) {
                                               // Log.d("InApp", "In-app Billing setup not ok");

                                           } else {
                                               // Log.d("InApp", "In-app Billing is set up OK");
                                               //to get inventory details
                                               mHelper.queryInventoryAsync(mGotInventoryListener);

                                           }
                                       }
                                   });
        setSupportActionBar(mToolBar);
        ActionBar actionBar = getSupportActionBar();
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.color_primary_hex != null) {
            actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex)));
        }
        actionBar.setDisplayHomeAsUpEnabled(true);
        initializeFragment();
    }

    IabHelper.QueryInventoryFinishedListener mGotInventoryListener = new IabHelper.QueryInventoryFinishedListener() {

        @Override
        public void onQueryInventoryFinished(IabResult result, Inventory inv) {

            // Have we been disposed of in the meantime? If so, quit.
            if (mHelper == null) return;

            // Is it a failure?
            if (result.isFailure()) {
                //   complain("Failed to query inventory: " + result);
                Toast.makeText(SettingActivity.this, result.getMessage(), Toast.LENGTH_LONG).show();
                return;
            }


            //  Toast.makeText(InAppBillingActivity.this, "Inventry Successful", Toast.LENGTH_LONG).show();

            Purchase purchase = inv.getPurchase(mSkuKey);
            if (purchase != null && verifyPayload(purchase)) {
                mIsUserAlreadyPurchase = true;
                //Toast.makeText(SettingActivity.this, "User Already Purchased", Toast.LENGTH_LONG).show();
            } else {
                // Toast.makeText(SettingActivity.this, "No Purchasing", Toast.LENGTH_LONG).show();
            }

        }
    };

    private boolean verifyPayload(Purchase purchase) {
        String payloadFromGoogle = purchase.getDeveloperPayload();
        if (mPayload.equals(payloadFromGoogle)) {
            return true;
        } else {
            return false;
        }

    }

    /**
     * Add fragment to activity
     */
    private void initializeFragment() {
        mSettingFragment = SettingFragment.newInstance(mContext);
        mSettingFragment.setInterfaceListner(settingInterface);
        addFragment(R.id.fragment_common_container, mSettingFragment);
    }

    /**
     * unbind butter knife object
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mHelper != null) {
            mHelper.dispose();
        }
        mHelper = null;
        if (mUnBinder != null) {
            mUnBinder.unbind();
        }

    }

    /**
     * initializing dagger components
     */
    private void initializeComponent() {
        ((SalesUApplication) this.getApplication()).getApplicationModule().inject(this);
    }

    /**
     * menu option selection
     *
     * @param item
     * @return menu item
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home: {
                finish();
                overridePendingTransition(R.anim.activity_transition_stay_still, R.anim.activity_transition_out);
                break;
            }
        }

        return super.onOptionsItemSelected(item);
    }


}
