package com.wagmob.golearningbus.model;



public class FacebookResponseModel {
    public String id;
    public String first_name;
    public String last_name;
    public String email;
    public String email_id;
    public String image_url;
}
