package com.wagmob.golearningbus.model;


import java.util.List;

public class NotificationModelData {

    public List<NotificationModelInfo> notifications;
}
