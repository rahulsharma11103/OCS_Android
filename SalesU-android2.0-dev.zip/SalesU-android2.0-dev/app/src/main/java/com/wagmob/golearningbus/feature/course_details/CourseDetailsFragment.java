package com.wagmob.golearningbus.feature.course_details;


import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatRatingBar;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.allcourses.UpdateMyCourseListEvent;
import com.wagmob.golearningbus.model.CoursesSubscription;
import com.wagmob.golearningbus.model.RatingFeedbackModel;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.requestModel.CoursesSubscriptionRequest;
import com.wagmob.golearningbus.model.requestModel.FeedBackModelRequest;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.ImageUtil;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONException;
import org.json.JSONObject;

import javax.inject.Inject;

import butterknife.BindColor;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

/**
 * Fragment for  showing Course Details.It have tab layout for Curriculum and leaderboard
 *
 * @author Rahul Sharma
 */
public class CourseDetailsFragment extends LoadDataFragment {

    static boolean mIsEnrolled;
    private static Context mContext;
    private static String mCourseId;
    private static String mCourseUrl;
    private static String mCourseName;
    @BindString(R.string.courses_successfully_subscribed)
    public String mCourseSuccessfullySubscribed;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.view_pager)
    ViewPager viewPager;
    @BindView(R.id.tab_layout)
    TabLayout tabLayout;
    @BindView(R.id.course_image)
    AppCompatImageView mCourseImageView;
    @BindView(R.id.subject_name)
    AppCompatTextView mSubjectNameView;
    @BindView(R.id.rating_button)
    AppCompatButton mRatingButton;
    @BindView(R.id.buy_now_button)
    AppCompatButton mBuyNowButton;
    @BindString(R.string.empty_field_message)
    String mEmptyMessage;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.web_service_for_rating_feedback)
    String mRatingServiceUrl;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @BindString(R.string.all_courses_subscribe)
    String mEnrollLabel;
    @BindString(R.string.rate_this_course_label)
    String mRateThisCourseLabel;
    @BindString(R.string.web_service_subscribe_courses)
    String mSubscribeSlugUrl;
    @BindColor(R.color.rating_selected_color)
    int mSelectedRatingColor;
    @BindView(R.id.adView)
    AdView mAdView;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    Gson mGson;
    @Inject
    EventBus mEventBus;
    LayoutInflater mInflater;
    View mView;
    private Unbinder mUnbinder;
    private AlertDialog mAlert;
    private String mParamName, mSlugUrl, mMethodType;
    private boolean isAccessTokenExpire;
    private static boolean mIsDeafaultCourse;
    CourseDetailsFragmentInterface mCourseDetailsFragmentInterface;
    private boolean mIsGuestLogin;
    CourseDetailsActivity mCourseDetailsActivity;


    public interface CourseDetailsFragmentInterface {
        public void buyNowButtonEvent();
    }

    /**
     * To give instance of CourseDetails Screen
     *
     * @param ctx
     * @param courseId
     * @param courseUrl
     * @return
     */
    public static CourseDetailsFragment newInstance(Context ctx, String courseId, String courseUrl, String courseName, boolean isEnrolled, boolean isDefaultCourse) {
        mContext = ctx;
        mCourseId = courseId;
        mCourseUrl = courseUrl;
        mCourseName = courseName;
        mIsEnrolled = isEnrolled;
        mIsDeafaultCourse = isDefaultCourse;
        return new CourseDetailsFragment();
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Set title bar
        mInflater = inflater;
        mView = inflater.inflate(R.layout.course_details_fragment, container, false);
        mUnbinder = ButterKnife.bind(this, mView);
        getActivity().setTitle(mCourseName);
        return mView;
    }

    /**
     * Load UI
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (mContext != null) {
            initializeComponent();
            setupUI();
            setUpBannerImage();
        }
    }

    private void setUpBannerImage() {
        if (mSharedPreference != null) {
            boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
            mIsGuestLogin = mSharedPreference.getBoolean(SalesUConstants.SHARED_IS_GUEST_USER, false);
            if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                AdRequest adRequest = new AdRequest.Builder().build();
                mAdView.loadAd(adRequest);
            } else {
                mAdView.setVisibility(View.GONE);
            }
        }
    }

    private void showAlertForGuestLogin() {
        AlertDialog.Builder alert = new AlertDialog.Builder(mContext);
        alert.setTitle(mContext.getString(R.string.guest_login_alert_title));
        alert.setMessage(mContext.getString(R.string.guest_login_alert_message));
        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                new BaseNavigator().navigateToLoginActivity(mContext);
            }
        });
        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alert.show();
    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    /**
     * setup Pager Adapter
     */
    private void setupUI() {
        // setupDataResource();
        boolean isAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

        Drawable backgroundForRating = mRatingButton.getBackground();
        if (backgroundForRating != null && mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null
                && mGlobalApp.appSettingModel.data.settings != null && mGlobalApp.appSettingModel.data.settings.color_secondary_hex != null) {
            ((GradientDrawable) backgroundForRating).setColorFilter(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_secondary_hex), PorterDuff.Mode.SRC_ATOP);
        }

        Drawable backgroundForBuyNow = mRatingButton.getBackground();
        if (backgroundForBuyNow != null && mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null
                && mGlobalApp.appSettingModel.data.settings != null && mGlobalApp.appSettingModel.data.settings.color_secondary_hex != null) {
            ((GradientDrawable) backgroundForBuyNow).setColorFilter(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_secondary_hex), PorterDuff.Mode.SRC_ATOP);
        }
        if (mIsEnrolled) {
            mRatingButton.setText(mRateThisCourseLabel);
        } else {
            mRatingButton.setText(mEnrollLabel);
        }

        if (isAlreadyPurchase) {
            mBuyNowButton.setVisibility(View.GONE);
        } else {
            mBuyNowButton.setVisibility(View.VISIBLE);
        }

        //   mRatingButton.setBackgroundColor(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex));
        ImageUtil.getInstance().loadImage(mContext, mCourseUrl, mCourseImageView, R.drawable.placeholder_default_rectangular, false, true);
        CourseFragmentAdapter homeFragmentAdapter = new CourseFragmentAdapter(getActivity(), getFragmentManager(), mCourseId, mIsDeafaultCourse);
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.color_secondary_hex != null) {
            tabLayout.setSelectedTabIndicatorColor(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_secondary_hex));
        }
        viewPager.setOffscreenPageLimit(1);
        viewPager.setAdapter(homeFragmentAdapter);
        tabLayout.setupWithViewPager(viewPager);
      /*  viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));*/
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                tabLayout.setScrollPosition(tab.getPosition(), 0f, true);
                tab.select();
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        mSubjectNameView.setText(mCourseName);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (mEventBus != null && !mEventBus.isRegistered(this)) {
            mEventBus.register(this);
        }
    }

    @OnClick(R.id.rating_button)
    public void ratingButton() {
        if (!mIsGuestLogin) {
            if (mIsEnrolled) {
                try {
                    //inflating layout and finding RatingBar widget
                    View root = ((LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.course_rating_view, null);

                    final AppCompatRatingBar rb = (AppCompatRatingBar) root.findViewById(R.id.dialog_rating_bar);
                    AppCompatTextView cancelDialog = (AppCompatTextView) root.findViewById(R.id.cancel_dialog_button);
                    AppCompatTextView submitDialog = (AppCompatTextView) root.findViewById(R.id.submit_dialog_button);
                    AppCompatTextView subjectName = (AppCompatTextView) root.findViewById(R.id.subject_name);
                    subjectName.setText(mCourseName);
                    AppCompatImageView courseView = (AppCompatImageView) root.findViewById(R.id.subject_image);
                    RelativeLayout ratingBox = (RelativeLayout) root.findViewById(R.id.rating_feedback_layout);
                    final AppCompatEditText courseFeedback = (AppCompatEditText) root.findViewById(R.id.rating_feedback);
                    ImageUtil.getInstance().loadImage(mContext, mCourseUrl, courseView, R.drawable.placeholder_default_rectangular, true, true);
                    LayerDrawable stars = (LayerDrawable) rb.getProgressDrawable();
                    stars.getDrawable(2).setColorFilter(mSelectedRatingColor, PorterDuff.Mode.SRC_ATOP);
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext)
                            .setView(root);
                    mAlert = builder.create();
                    mAlert.show();
                    cancelDialog.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mAlert.dismiss();
                        }
                    });
                    ratingBox.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
                            if (imm != null) {
                                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
                            }
                        }
                    });
                    submitDialog.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int ratingCount = (int) rb.getRating();
                            String feedbackString = String.valueOf(courseFeedback.getText());
                            if (ratingCount > 0 && !feedbackString.isEmpty()) {
                                sendFeedback(ratingCount, feedbackString);
                                mAlert.dismiss();
                            } else if (ratingCount == 0) {
                                Toast.makeText(mContext, getString(R.string.rating_not_provided_message), Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(mContext, getString(R.string.rating_not_provided_feedback_message), Toast.LENGTH_SHORT).show();
                            }


                        }
                    });


                } catch (Exception e) {
                    if (SalesUConstants.ISLogVisible) {
                        Timber.e("ShowRateDialog Exception: " + e);
                    }
                }
            } else {
                CoursesSubscriptionRequest coursesSubscriptionRequest = new CoursesSubscriptionRequest();
                coursesSubscriptionRequest.course_id = mCourseId;
                String coursesJson = mGson.toJson(coursesSubscriptionRequest);
                callRatingService(coursesJson, mSubscribeSlugUrl, SalesUConstants.POST_METHOD_TYPE);
            }
        } else {
            showAlertForGuestLogin();
        }
    }

    public void initiateIterface(CourseDetailsFragmentInterface courseDetailsFragmentInterface) {
        mCourseDetailsFragmentInterface = courseDetailsFragmentInterface;
    }

    @OnClick(R.id.buy_now_button)
    public void buyNowClick() {
        if (mCourseDetailsFragmentInterface != null) {
            mCourseDetailsFragmentInterface.buyNowButtonEvent();
        }
    }

    private void sendFeedback(int ratingCount, String feedbackString) {
        FeedBackModelRequest feedBackModelRequest = new FeedBackModelRequest();
        feedBackModelRequest.points = String.valueOf(ratingCount);
        feedBackModelRequest.course_id = String.valueOf(mCourseId);
        feedBackModelRequest.message = feedbackString;
        String paramName = mGson.toJson(feedBackModelRequest);
        callRatingService(paramName, mRatingServiceUrl, SalesUConstants.POST_METHOD_TYPE);
    }

    /**
     * call Change password web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callRatingService(String paramName, String path, String methodType) {

        if (mGlobalApp.isNetworkAvailable()) {
            if (!mIsEnrolled) {
                showLoading();
            }
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new SubmitRatingService().execute();
        } else {
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    private void ratingServiceResponse(String s) {


        try {
            RatingFeedbackModel ratingFeedbackModel = mGson.fromJson(s, RatingFeedbackModel.class);
            if (ratingFeedbackModel != null && ratingFeedbackModel.message != null) {

                Toast.makeText(mContext, ratingFeedbackModel.message[0], Toast.LENGTH_LONG).show();

            } else {
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    /**
     * unBind Butter knife
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
        if (mEventBus != null) {
            mEventBus.unregister(this);
        }
    }

    public void onEvent(UpdateForPaymentEvent updateForPaymentEvent) {
        boolean isAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

        if (isAlreadyPurchase) {
            mBuyNowButton.setVisibility(View.GONE);
        } else {
            mBuyNowButton.setVisibility(View.VISIBLE);
        }

        setUpBannerImage();


    }

    private void
    enrollServiceResponse(String response) {
        try {
            CoursesSubscription coursesSubscription = mGson.fromJson(response, CoursesSubscription.class);

            if (coursesSubscription != null && !coursesSubscription.error) {
                mIsEnrolled = true;
                Toast.makeText(mContext, mCourseSuccessfullySubscribed, Toast.LENGTH_SHORT).show();
                mRatingButton.setText(mRateThisCourseLabel);
                mEventBus.post(new UpdateMyCourseListEvent(true));
                mEventBus.post(new CourseEnrolledEvent(true));
            } else {
                mIsEnrolled = true;
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }

        } catch (Exception ex) {
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * To Call Async Web Service
     */
    class SubmitRatingService extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new SubmitRatingService().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new SubmitRatingService().execute();
                    } else {
                        hideLoading();
                        if (mIsEnrolled) {
                            ratingServiceResponse(s);
                        } else {
                            enrollServiceResponse(s);
                        }
                    }
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_INVALID_PASSWORD_CODE) {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_INVALID_USER_ID) {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                hideLoading();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }


    }
}
