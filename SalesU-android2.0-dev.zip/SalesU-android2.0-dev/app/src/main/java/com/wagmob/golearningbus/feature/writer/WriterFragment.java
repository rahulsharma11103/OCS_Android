package com.wagmob.golearningbus.feature.writer;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatImageButton;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.assignments.UpdateProgressForSectionEvent;
import com.wagmob.golearningbus.feature.edit_user_profile.EditProfileEvent;
import com.wagmob.golearningbus.feature.flashcard.FlashCardListItemAdapter;
import com.wagmob.golearningbus.model.FlashCardModel;
import com.wagmob.golearningbus.model.FlashCardModelLetters;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.requestModel.AssignmentRequest;
import com.wagmob.golearningbus.util.ImageUtil;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import java.util.List;

import javax.inject.Inject;

import butterknife.BindDrawable;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

/**
 * Created by Rahul on 8/24/2017.
 */

public class WriterFragment extends LoadDataFragment {

    Context mContext;
    String mAssingmentId;
    WriterFragment mWriterFragment;
    List<FlashCardModelLetters> mFlashCardModelLetters;
    FlashCardListItemAdapter mFlashCardListItemAdapter;
    @BindView(R.id.writers_items_recycler_view)
    RecyclerView mWritersItemsRecyclerView;
    @BindView(R.id.writable_image_view)
    AppCompatImageView mWritableImageView;
    @BindView(R.id.card_count_view)
    AppCompatTextView mCardCountView;
    @BindView(R.id.next_language_view)
    AppCompatImageButton mNextAssignmentView;

    @BindView(R.id.previous_language_view)
    AppCompatImageButton mPreviousAssignmentView;
    @BindDrawable(R.drawable.writer_available_background)
    Drawable mAssignmentBackgroundAvailable;
    @BindDrawable(R.drawable.writer_unavailable_background)
    Drawable mAssignmentBackgroundUnAvailable;
    @BindView(R.id.canvas_view)
    CanvasView mCanvasView;
    @BindView(R.id.ic_word_color)
    AppCompatImageView mIcColorChooser;
    @BindView(R.id.ic_view_writer)
    AppCompatImageView mIcHideShow;
    @BindView(R.id.ic_word_image)
    AppCompatImageView mIcWordImage;
    @BindView(R.id.ic_word_sound)
    AppCompatImageView mIcWordSound;
    @BindView(R.id.ic_word_undo)
    AppCompatImageView mIcWordUndo;
    @BindView(R.id.ic_word_delete)
    AppCompatImageView mIcWordDelete;
    @BindDrawable(R.drawable.ic_delete_selected)
    Drawable mImageDeleteSelected;
    @BindDrawable(R.drawable.ic_delete)
    Drawable mImageDelete;
    @BindDrawable(R.drawable.ic_color)
    Drawable mImageColorChooser;
    @BindDrawable(R.drawable.ic_colo_selected)
    Drawable mImageColorChooserSelected;
    @BindDrawable(R.drawable.ic_view)
    Drawable mImageShowHide;
    @BindDrawable(R.drawable.ic_view_selected)
    Drawable mImageShowHideSelected;
    @BindDrawable(R.drawable.ic_sound)
    Drawable mImageSound;
    @BindDrawable(R.drawable.ic_sound_selected)
    Drawable mImageSoundSelected;
    @BindDrawable(R.drawable.ic_undo)
    Drawable mImageUndo;
    @BindDrawable(R.drawable.ic_undo_selected)
    Drawable mImageUndoSelected;
    @BindDrawable(R.drawable.ic_image)
    Drawable mImageWord;
    @BindDrawable(R.drawable.ic_image_selected)
    Drawable mImageWordSelected;
    @BindString(R.string.web_service_set_assignment_progress)
    String mWebServiceURlForSetAssignmentProgress;

    @BindString(R.string.network_message)
    String mNetworkMessage;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.web_service_to_get_quiz)
    String mAssignmentWebServiceUrl;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    Gson mGson;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    EventBus mEventBus;
    int mCurrentItemPosition = 0;
    private boolean mViewHidingFeature, mIsWordImage;
    private AlertDialog mAlert;
    RecyclerView mRecyclerViewForDialog;
    private boolean isSetProgress;
    FlashCardListItemAdapter.FlashCardListItemAdapterInterface flashCardListItemAdapterInterface = new FlashCardListItemAdapter.FlashCardListItemAdapterInterface() {
        @Override
        public void cardItemClick(int cardPosition) {
            setWritableImage(cardPosition);
        }
    };

    CustomColorPickerRecyclerViewAdapter.CustomRecyclerViewAdapterInterface customRecyclerViewAdapterInterface = new CustomColorPickerRecyclerViewAdapter.CustomRecyclerViewAdapterInterface() {
        @Override
        public void colorSelect(int itemPosition) {
            mCanvasView.setPaintColor(SalesUConstants.COLOR_HEX_CODE[itemPosition]);
            mAlert.dismiss();
        }
    };

    private Unbinder mUnbinder;
    private String mParamName, mSlugUrl, mMethodType;
    private boolean isAccessTokenExpire;

    public WriterFragment newInstance(Context context, String assignmentId) {
        mWriterFragment = new WriterFragment();
        mWriterFragment.mContext = context;
        mWriterFragment.mAssingmentId = assignmentId;
        return mWriterFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.writer, container, false);
        mUnbinder = ButterKnife.bind(this, view);
        return view;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (mContext != null) {
            initializeComponent();
            setupUI();
            loadWriterData();
        }
    }

    private void loadWriterData() {
        showLoading();
        callWriterWebService("na", mAssignmentWebServiceUrl + "?assignment_id=" + mAssingmentId, SalesUConstants.GET_METHOD_TYPE);
    }

    public void callWriterWebService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new GetWriterItem().execute();
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    private void setupUI() {
        boolean nextArrow = isNeedToShowNextArrow(mCurrentItemPosition);
        boolean previousArrow = isNeedToShowpreviousArrow(mCurrentItemPosition);
        setupAssignmentArrow(nextArrow, previousArrow);
        mFlashCardListItemAdapter = new FlashCardListItemAdapter(mContext, mFlashCardModelLetters);
        mWritersItemsRecyclerView.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false));
        mWritersItemsRecyclerView.setAdapter(mFlashCardListItemAdapter);
        mFlashCardListItemAdapter.initialteInterfaceListner(flashCardListItemAdapterInterface);
    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        if (mContext != null)
            ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    private void writerServiceResponse(String s) {
        hideLoading();
        try {
            FlashCardModel flashCardModel = mGson.fromJson(s, FlashCardModel.class);
            if (flashCardModel != null) {
                mFlashCardModelLetters = flashCardModel.data.assignment.letters;
                mFlashCardListItemAdapter.setFlashCardItems(mFlashCardModelLetters);
                setWritableImage(0);
            }
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    private void setWritableImage(int position) {

        if (mFlashCardListItemAdapter != null && mFlashCardModelLetters != null && position < mFlashCardModelLetters.size()
                && position >= 0
                && mFlashCardModelLetters.get(position).character_writableimage_url != null
                ) {
            wordDelete();
            mIsWordImage = true;
            mViewHidingFeature = true;
            wordImageDetailClick();
            viewDrawingFeature();

            boolean nextArrow = isNeedToShowNextArrow(position);
            boolean previousArrow = isNeedToShowpreviousArrow(position);
            setupAssignmentArrow(nextArrow, previousArrow);
            mFlashCardListItemAdapter.setBorderColorInItems(position);
            mWritersItemsRecyclerView.smoothScrollToPosition(position);
            setCardCount(position);
            mCurrentItemPosition = position;
            ImageUtil.getInstance().loadImage(mContext, mFlashCardModelLetters.get(position).character_writableimage_url, mWritableImageView, false);
        }
    }

    public void setCardCount(int currentItem) {
        if (mFlashCardModelLetters != null) {
            mCardCountView.setText(++currentItem + "/" + mFlashCardModelLetters.size());
        }
    }

    @OnClick(R.id.next_language_view)
    public void nextLanguageView() {
        int positionItem = mCurrentItemPosition;
        setWritableImage(++positionItem);
    }

    @OnClick(R.id.previous_language_view)
    public void previousLanguageView() {
        int positionItem = mCurrentItemPosition;
        setWritableImage(--positionItem);
    }

    @OnClick(R.id.ic_word_undo)
    public void wordUndo() {
        if (mCanvasView != null) {
            mCanvasView.doUndo();
        }
    }

    @OnClick(R.id.ic_word_delete)
    public void wordDeleteClick() {
        mIsWordImage = true;
        mViewHidingFeature = true;
        wordImageDetailClick();
        viewDrawingFeature();
        if (mCanvasView != null) {
            mCanvasView.clearCanvas();
        }

    }

    public void wordDelete() {
        if (mCanvasView != null) {
            mCanvasView.clearCanvas();
        }
    }

    @OnClick(R.id.ic_view_writer)
    public void viewDrawingFeature() {
        if (mViewHidingFeature) {
            mWritableImageView.setVisibility(View.VISIBLE);
            mViewHidingFeature = false;
            mIcHideShow.setImageDrawable(mImageShowHide);
        } else {
            mWritableImageView.setVisibility(View.INVISIBLE);
            mViewHidingFeature = true;
            mIcHideShow.setImageDrawable(mImageShowHideSelected);
        }
    }

    @OnClick(R.id.ic_word_color)
    public void colorDialogBox() {
        View root = ((LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.color_picker_for_dialog_layout, null);
        mRecyclerViewForDialog = (RecyclerView) root.findViewById(R.id.dialog_recycler);
        mRecyclerViewForDialog.setLayoutManager(new GridLayoutManager(mContext, 4));
        CustomColorPickerRecyclerViewAdapter customerRecyclerViewAdapter = new CustomColorPickerRecyclerViewAdapter(mContext);
        mRecyclerViewForDialog.setAdapter(customerRecyclerViewAdapter);
        customerRecyclerViewAdapter.intializeInterfaceObject(customRecyclerViewAdapterInterface);
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext)
                .setView(root);
        mAlert = builder.create();
        mAlert.show();
    }

    @OnClick(R.id.ic_word_image)
    public void wordImageDetailClick() {
        wordDelete();
        if (mIsWordImage) {
            ImageUtil.getInstance().loadImage(mContext, mFlashCardModelLetters.get(mCurrentItemPosition).character_writableimage_url, mWritableImageView, false);
            mIsWordImage = false;
            mIcWordImage.setImageDrawable(mImageWord);
            mCanvasView.setWillNotDraw(false);

        } else {
            ImageUtil.getInstance().loadImage(mContext, mFlashCardModelLetters.get(mCurrentItemPosition).word_image_url, mWritableImageView, false);
            mCanvasView.setWillNotDraw(true);
            mIsWordImage = true;
            mIcWordImage.setImageDrawable(mImageWordSelected);
        }
    }

    @OnClick(R.id.ic_word_sound)
    public void soundFileUrl() {
        MediaPlayer mp = new MediaPlayer();
        try {
            FlashCardModelLetters flashCardModelLettersSoundUrl = mFlashCardModelLetters.get(mCurrentItemPosition);
            if (mIsWordImage) {
                mp.setDataSource(flashCardModelLettersSoundUrl.wordsoundfile_url);//Write your location here

            } else {
                mp.setDataSource(flashCardModelLettersSoundUrl.charactersoundfile_url);//Write your location here
            }
            mp.prepare();
            mp.start();
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {

                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setupAssignmentArrow(boolean nextArrow, boolean previousArrow) {
        if (nextArrow) {
            mNextAssignmentView.setBackgroundDrawable(mAssignmentBackgroundAvailable);
        } else {
            mNextAssignmentView.setBackgroundDrawable(mAssignmentBackgroundUnAvailable);

        }

        if (previousArrow) {
            mPreviousAssignmentView.setBackgroundDrawable(mAssignmentBackgroundAvailable);
        } else {
            mPreviousAssignmentView.setBackgroundDrawable(mAssignmentBackgroundUnAvailable);
        }
    }


    public boolean isNeedToShowNextArrow(int currentLocation) {
        currentLocation++;
        if (mFlashCardModelLetters != null) {
            int collectionSize = mFlashCardModelLetters.size();
            if (currentLocation >= collectionSize) {
                setProgress();
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public boolean isNeedToShowpreviousArrow(int currentLocation) {
        if (currentLocation <= 0) {
            return false;
        } else {
            return true;
        }
    }

    private void setProgress() {
        isSetProgress = true;
        if (mGlobalApp.isNetworkAvailable()) {
            AssignmentRequest assignmentRequest = new AssignmentRequest();
            assignmentRequest.assignment_id = mAssingmentId;
            String paramName = mGson.toJson(assignmentRequest);
            callWriterWebService(paramName, mWebServiceURlForSetAssignmentProgress, SalesUConstants.POST_METHOD_TYPE);
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * calling of Flashcard Web service
     */
    class GetWriterItem extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new GetWriterItem().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new GetWriterItem().execute();
                    } else {
                        if (!isSetProgress) {
                            writerServiceResponse(s);
                        } else {
                            mEventBus.post(new EditProfileEvent(true));
                            mEventBus.post(new UpdateProgressForSectionEvent(true));
                            isSetProgress = false;
                        }
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.getMessage());
            }

        }
    }


}
