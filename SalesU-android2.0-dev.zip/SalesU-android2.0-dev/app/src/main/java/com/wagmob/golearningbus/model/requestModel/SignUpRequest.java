package com.wagmob.golearningbus.model.requestModel;

public class SignUpRequest {
    public String first_name;
    public String last_name;
    public String email_id;
    public String password;
}
