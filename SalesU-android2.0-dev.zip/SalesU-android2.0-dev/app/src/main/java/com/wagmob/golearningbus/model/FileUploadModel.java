package com.wagmob.golearningbus.model;


public class FileUploadModel {
    public boolean error;
    public int response_code;
    public String message[];
    public FileUploadModelData data;
}
