package com.wagmob.golearningbus.model;

/**
 * Created by rahul on 8/28/2017.
 */

public class FlashCardModelLetters {
    public String letter_id;
    public String title;
    public String description;
    public String character;
    public String word;
    public String meaning;
    public String pronunciation;
    public String soundfile_url;
    public String word_image_url;
    public String character_sideimage_url;
    public String character_writableimage_url;
    public String wordsoundfile_url;
    public String charactersoundfile_url;
}
