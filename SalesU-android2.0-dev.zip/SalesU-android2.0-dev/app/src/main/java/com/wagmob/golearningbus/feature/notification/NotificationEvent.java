package com.wagmob.golearningbus.feature.notification;

/**
 * Event for notification
 * @author Rahul Sharma
 */

public class NotificationEvent {

    public String mNotificationCount;

    public NotificationEvent(String notificationEvent)
    {
        mNotificationCount=notificationEvent;
    }

    public String getNotificationCount()
    {
        return mNotificationCount;
    }

}
