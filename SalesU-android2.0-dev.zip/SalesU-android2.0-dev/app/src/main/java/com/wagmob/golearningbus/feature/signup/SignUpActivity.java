package com.wagmob.golearningbus.feature.signup;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.view.BaseActivity;
import com.wagmob.golearningbus.webservice_helper.AsyncRequest;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Activity for login activity
 *
 * @author Rahul Sharma
 */
public class SignUpActivity extends BaseActivity implements AsyncRequest.OnAsyncRequestComplete, SignUpFragment.SignUpFragmentInterface {


    private final String CLASSNAME = this.getClass().getSimpleName();
    @BindView(R.id.toolbar)
    Toolbar mToolBar;
    @BindString(R.string.empty_field_message)
    String mEmptyMessage;
    @Inject
    Gson mGson;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    private Unbinder mUnBinder;
    private Context mContext;
    private SignUpFragment mSignUpFragment;
    private boolean mIsLoginCall;

    public static Intent callingIntent(Context context) {
        return new Intent(context, SignUpActivity.class);
    }

    /**
     * Use to initialize layout and App bar
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_common);
        mContext = this;
        mUnBinder = ButterKnife.bind(this);
        mToolBar.setVisibility(View.GONE);
        setSupportActionBar(mToolBar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        ((SalesUApplication) getApplication()).getApplicationModule().inject(this);
        initializeFragment();

    }

    /**
     * Add fragment to activity
     */
    private void initializeFragment() {
        mSignUpFragment = SignUpFragment.newInstance(mContext);
        addFragment(R.id.fragment_common_container, mSignUpFragment);
    }

    /**
     * unbind butter knife object
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mUnBinder.unbind();
    }

    /**
     * response of sign up web service
     *
     * @param response response of sign up web service
     */
    @Override
    public void asyncResponse(String response) {

        mSignUpFragment.asyncSignUpResponse(response,mIsLoginCall);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home: {
                finish();
                overridePendingTransition(R.anim.activity_transition_stay_still, R.anim.activity_transition_out);
                break;

            }
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * To call Sign up web service
     *
     * @param paramName  parameter name
     * @param url        url of web service
     * @param methodType method type
     */
    @Override
    public void callWebService(String paramName, String url, String methodType, boolean isLoginCall) {
        mIsLoginCall = isLoginCall;
        if (mGlobalApp.isNetworkAvailable()) {
            new AsyncRequest(mContext, paramName, url, methodType,null,null).execute();
        } else {
            mSignUpFragment.hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }
}
