package com.wagmob.golearningbus.model;



public class TutorialModelAssignment {
    public String tutorial_id;
    public String file_url;
    public String file_mime;
    public String file_size;
}
