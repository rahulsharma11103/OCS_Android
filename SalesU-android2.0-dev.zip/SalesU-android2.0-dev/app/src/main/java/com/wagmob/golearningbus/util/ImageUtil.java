package com.wagmob.golearningbus.util;

import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v7.widget.AppCompatImageView;
import android.util.Log;
import android.widget.RelativeLayout;

import com.wagmob.golearningbus.constants.SalesUConstants;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import com.squareup.picasso.Transformation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;


import timber.log.Timber;

/**
 * This class is common class for loading image asynchronously(Picasso library is used for loading image)
 *
 * @author Rahul Sharma
 */
public class ImageUtil {

    private static final float maxHeight = 1280.0f;
    private static final float maxWidth = 1280.0f;
    public static ImageUtil sImageUtil;

    /**
     * just return ImageUtil class object
     *
     * @return ImageUtil class object
     */
    public static ImageUtil getInstance() {
        if (sImageUtil == null) {
            synchronized (ImageUtil.class) {
                if (sImageUtil == null) {
                    sImageUtil = new ImageUtil();
                }
            }
        }
        return sImageUtil;
    }

    /**
     * Get a file path from a Uri. This will get the the path for Storage Access
     * Framework Documents, as well as the _data field for the MediaStore and
     * other file-based ContentProviders.
     *
     * @param context The context.
     * @param uri     The Uri to query.
     * @author paulburke
     */
    public static String getRealFilePathUsingFileUri(final Context context, final Uri uri) {

        final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;

        // DocumentProvider
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
                // ExternalStorageProvider
                if (isExternalStorageDocument(uri)) {
                    final String docId = DocumentsContract.getDocumentId(uri);
                    final String[] split = docId.split(":");
                    final String type = split[0];

                    if ("primary".equalsIgnoreCase(type)) {
                        return Environment.getExternalStorageDirectory() + "/" + split[1];
                    }

                    // TODO handle non-primary volumes
                }
                // DownloadsProvider
                else if (isDownloadsDocument(uri)) {

                    final String id = DocumentsContract.getDocumentId(uri);
                    final Uri contentUri = ContentUris.withAppendedId(
                            Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                    return getDataColumn(context, contentUri, null, null);
                }
                // MediaProvider
                else if (isMediaDocument(uri)) {
                    final String docId = DocumentsContract.getDocumentId(uri);
                    final String[] split = docId.split(":");
                    final String type = split[0];

                    Uri contentUri = null;
                    if ("image".equals(type)) {
                        contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    } else if ("video".equals(type)) {
                        contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    } else if ("audio".equals(type)) {
                        contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    }

                    final String selection = "_id=?";
                    final String[] selectionArgs = new String[]{
                            split[1]
                    };

                    return getDataColumn(context, contentUri, selection, selectionArgs);
                }
            }
            // MediaStore (and general)
            else if ("content".equalsIgnoreCase(uri.getScheme())) {

                // Return the remote address
                if (isGooglePhotosUri(uri))
                    return uri.getLastPathSegment();

                return getDataColumn(context, uri, null, null);
            }
            // File
            else if ("file".equalsIgnoreCase(uri.getScheme())) {
                return uri.getPath();
            }
        } else {
            String filePath = null;
            try {
                String[] projection = {MediaStore.Images.Media.DATA};
                Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                    filePath = cursor.getString(column_index);
                    cursor.close();
                }
            } catch (Exception e) {
                if (SalesUConstants.ISLogVisible) {
                    Timber.e("Exception Caught in getBitMapUsingFileUri ==>> " + e.getMessage());
                }
            }

            return filePath;
        }

        return null;
    }

    /**
     * Get the value of the data column for this Uri. This is useful for
     * MediaStore Uris, and other file-based ContentProviders.
     *
     * @param context       The context.
     * @param uri           The Uri to query.
     * @param selection     (Optional) Filter used in the query.
     * @param selectionArgs (Optional) Selection arguments used in the query.
     * @return The value of the _data column, which is typically a file path.
     */
    public static String getDataColumn(Context context, Uri uri, String selection,
                                       String[] selectionArgs) {

        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {
                column
        };

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is ExternalStorageProvider.
     */
    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is DownloadsProvider.
     */
    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is MediaProvider.
     */
    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is Google Photos.
     */
    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }

   /* public static String getRealFilePathUsingFileUri(Context context, Uri fileUri) {
        String filePath = null;
        try {
            String[] projection = {MediaStore.Images.Media.DATA};
            Cursor cursor = context.getContentResolver().query(fileUri, projection, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                filePath = cursor.getString(column_index);
                cursor.close();
            }
        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e("Exception Caught in getBitMapUsingFileUri ==>> " + e.getMessage());
            }
        }

        return filePath;
    }*/

    public static String getNewFileName() {
        File mediaStorageDir = new File(Environment.getExternalStorageDirectory() + "/GoLearningBus");
        if (!mediaStorageDir.exists()) {
            mediaStorageDir.mkdirs();
        }
        String mImageName = "glb_"+String.valueOf(System.currentTimeMillis()) + ".png";
        return (mediaStorageDir.getAbsolutePath() + "/" + mImageName);

    }

    public static void copyFile(String source, String destination) throws Exception {
        InputStream in = new FileInputStream(source);
        OutputStream out = new FileOutputStream(destination);

        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) > 0) {
            out.write(buf, 0, len);
        }

        in.close();
        out.close();
    }

    public static void compressImage(String filePath) {
        try {
            Bitmap scaledBitmap = null;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            Bitmap bmp = BitmapFactory.decodeFile(filePath, options);

            int actualHeight = options.outHeight;
            int actualWidth = options.outWidth;

            float imgRatio = (float) actualWidth / (float) actualHeight;
            float maxRatio = maxWidth / maxHeight;

            if (actualHeight > maxHeight || actualWidth > maxWidth) {
                if (imgRatio < maxRatio) {
                    imgRatio = maxHeight / actualHeight;
                    actualWidth = (int) (imgRatio * actualWidth);
                    actualHeight = (int) maxHeight;
                } else if (imgRatio > maxRatio) {
                    imgRatio = maxWidth / actualWidth;
                    actualHeight = (int) (imgRatio * actualHeight);
                    actualWidth = (int) maxWidth;
                } else {
                    actualHeight = (int) maxHeight;
                    actualWidth = (int) maxWidth;
                }
            }
            options.inSampleSize = calculateInSampleSize(options, actualWidth, actualHeight);
            options.inJustDecodeBounds = false;
            options.inDither = false;
            options.inPurgeable = true;
            options.inInputShareable = true;
            options.inTempStorage = new byte[16 * 1024];

            try {
                bmp = BitmapFactory.decodeFile(filePath, options);
            } catch (OutOfMemoryError e) {
                Timber.e("Exception caught ==>> " + e.getMessage());
            }
            try {
                scaledBitmap = Bitmap.createBitmap(actualWidth, actualHeight, Bitmap.Config.RGB_565);
            } catch (OutOfMemoryError e) {
                Timber.e("Exception caught ==>> " + e.getMessage());
            }

            float ratioX = actualWidth / (float) options.outWidth;
            float ratioY = actualHeight / (float) options.outHeight;
            float middleX = actualWidth / 2.0f;
            float middleY = actualHeight / 2.0f;
            Matrix scaleMatrix = new Matrix();
            scaleMatrix.setScale(ratioX, ratioY, middleX, middleY);
            Canvas canvas = new Canvas(scaledBitmap);
            canvas.setMatrix(scaleMatrix);
            canvas.drawBitmap(bmp, middleX - bmp.getWidth() / 2, middleY - bmp.getHeight() / 2, new Paint(Paint.FILTER_BITMAP_FLAG));
            if (bmp != null) {
                bmp.recycle();
            }
            ExifInterface exif;
            try {
                exif = new ExifInterface(filePath);
                int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, 0);
                Matrix matrix = new Matrix();
                if (orientation == 6) {
                    matrix.postRotate(90);
                } else if (orientation == 3) {
                    matrix.postRotate(180);
                } else if (orientation == 8) {
                    matrix.postRotate(270);
                }
                scaledBitmap = Bitmap.createBitmap(scaledBitmap, 0, 0, scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix, true);
            } catch (IOException e) {
                Timber.e("Exception caught ==>> " + e.getMessage());
            }
            FileOutputStream out;
            try {
                out = new FileOutputStream(filePath);
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 80, out);
            } catch (FileNotFoundException e) {
                Timber.e("Exception caught ==>> " + e.getMessage());
            }

        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e("Exception caught while compressing file ==>> " + e.getMessage());
            }
            Timber.e("Exception caught ==>> " + e.getMessage());
        }
    }

    public static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
        }
        final float totalPixels = width * height;
        final float totalReqPixelsCap = reqWidth * reqHeight * 2;
        while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
            inSampleSize++;
        }
        return inSampleSize;
    }

    public static String compressGalleryImage(final String imagePath) {
        String newCompressedPath = null;
        try {
            String copiedImagePath = getNewFileName();
            copyFile(imagePath, copiedImagePath);
            compressImage(copiedImagePath);
            newCompressedPath = copiedImagePath;
        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(e.getMessage());
                newCompressedPath = null;

            }
        }
        return newCompressedPath;
    }

    public static String saveImageUsingBitMap(Bitmap bitmap) {
        String myImagePathLocation = getNewFileName();
        if (bitmap != null) {
            File myFile = new File(myImagePathLocation);
            try {
                FileOutputStream fos = new FileOutputStream(myFile);
                bitmap.compress(Bitmap.CompressFormat.PNG, 90, fos);
                fos.close();
            } catch (FileNotFoundException e) {
                myImagePathLocation = null;
                Timber.e(e.getMessage());
            } catch (IOException e) {
                myImagePathLocation = null;
                Timber.e(e.getMessage());
            }
        } else {
            myImagePathLocation = null;
        }
        return myImagePathLocation;
    }

    public static Bitmap getBitMapFromUrl(String url) {
        Bitmap image = null;
        try {
            URL imageUrl = new URL(url);
            image = BitmapFactory.decodeStream(imageUrl.openConnection().getInputStream());
        } catch (IOException e) {
            image = null;
        }
        return image;
    }

    /**
     * this method is used for loading image according to passing parameter if we have placeholder(default image)
     *
     * @param context
     * @param imageUrl
     * @param appCompatImageView
     * @param placeholderResourceId
     * @param circularTransformation
     * @param fit
     */
    public void loadImage(Context context, String imageUrl, AppCompatImageView appCompatImageView, int placeholderResourceId, boolean circularTransformation, boolean fit) {
        try {
            if (imageUrl != null && circularTransformation && fit) {
                Picasso.with(context)
                        .load(imageUrl)
                        .transform(new CircularImage())
                        .placeholder(placeholderResourceId)
                        .fit()
                        .into(appCompatImageView);
            } else if (imageUrl != null && circularTransformation && !fit) {
                Picasso.with(context)
                        .load(imageUrl)
                        .transform(new CircularImage())
                        .placeholder(placeholderResourceId)
                        .into(appCompatImageView);
            } else if (imageUrl != null && !circularTransformation && fit) {
                Picasso.with(context)
                        .load(imageUrl)
                        .placeholder(placeholderResourceId)
                        .fit()
                        .into(appCompatImageView);
            } else {
                Picasso.with(context)
                        .load(imageUrl)
                        .placeholder(placeholderResourceId)
                        .into(appCompatImageView);
            }
        } catch (Exception e) {
            Timber.e("Exception caught while loading image ==>> " + e.getMessage());
        }
    }

    /**
     * this method is used for image loading when we don't want placeholder
     *
     * @param context
     * @param imageUrl
     * @param appCompatImageView
     * @param circularTransformation
     */
    public void loadImage(Context context, String imageUrl, AppCompatImageView appCompatImageView, boolean circularTransformation) {
        try {
            if (imageUrl != null && circularTransformation) {
                Picasso.with(context)
                        .load(imageUrl)
                        .transform(new CircularImage())
                        .into(appCompatImageView);
            } else {
                Picasso.with(context)
                        .load(imageUrl)
                        .into(appCompatImageView);
            }
        } catch (Exception e) {
            Timber.e("Exception caught while loading image ==>> " + e.getMessage());
        }
    }

    /**
     * This method use for loading image inside relative layout
     *
     * @param context
     * @param imageUrl
     * @param layout
     */
    public void loadImage(final Context context, String imageUrl, final RelativeLayout layout) {

        try {
            if (imageUrl != null) {
                Picasso.with(context)
                        .load(imageUrl)
                        .into(new Target() {

                            @Override
                            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                                if (Build.VERSION.SDK_INT >= 16) {
                                    layout.setBackground(new BitmapDrawable(context.getResources(), bitmap));
                                } else {
                                    layout.setBackgroundDrawable(new BitmapDrawable(bitmap));
                                }
                            }

                            @Override
                            public void onBitmapFailed(final Drawable errorDrawable) {
                                Log.d("TAG", "FAILED");
                            }

                            @Override
                            public void onPrepareLoad(final Drawable placeHolderDrawable) {
                                Log.d("TAG", "Prepare Load");
                            }
                        });
            }
        } catch (Exception e) {
            Timber.e("Exception caught while loading image ==>> " + e.getMessage());
        }
    }

    public void loadImage(Context context, int resourceId, AppCompatImageView appCompatImageView, boolean circularTransformation) {
        try {
            if (circularTransformation) {
                Picasso.with(context)
                        .load(resourceId)
                        .transform(new CircularImage())
                        .into(appCompatImageView);
            } else {
                Picasso.with(context)
                        .load(resourceId)
                        .into(appCompatImageView);
            }
        } catch (Exception e) {
            Timber.e("Exception caught while loading image ==>> " + e.getMessage());
        }
    }

    public void loadImage(Context context, Uri uri, AppCompatImageView appCompatImageView) {
        try {
            Picasso.with(context)
                    .load(uri)
                    .into(appCompatImageView);

        } catch (Exception e) {
            Timber.e("Exception caught while loading image ==>> " + e.getMessage());
        }
    }

    public void showImageInGallery(Context context,String filePath)
    {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.parse("file://"+filePath), "image/*");
        context.startActivity(intent);

    }

    /**
     * to create circular image
     */
    public class CircularImage implements Transformation {

        private static final String CIRCLE = "circle";

        /**
         * Transform the source bitmap into a new bitmap. If you create a new bitmap instance, you must
         * call {@link Bitmap#recycle()} on {@code source}. You may return the original
         * if no transformation is required.
         *
         * @param source
         */
        @Override
        public Bitmap transform(Bitmap source) {
            Bitmap bitmap = null;
            try {
                int size = Math.min(source.getWidth(), source.getHeight());

                int x = (source.getWidth() - size) / 2;
                int y = (source.getHeight() - size) / 2;

                Bitmap squaredBitmap = Bitmap.createBitmap(source, x, y, size, size);
                if (squaredBitmap != source) {
                    source.recycle();
                }

                Bitmap.Config config = source.getConfig() != null ? source.getConfig() : Bitmap.Config.ARGB_8888;
                bitmap = Bitmap.createBitmap(size, size, config);

                Canvas canvas = new Canvas(bitmap);
                Paint paint = new Paint();
                BitmapShader shader = new BitmapShader(squaredBitmap, BitmapShader.TileMode.CLAMP, BitmapShader.TileMode.CLAMP);
                paint.setShader(shader);
                paint.setAntiAlias(true);

                float r = size / 2f;
                canvas.drawCircle(r, r, r, paint);

                squaredBitmap.recycle();
                return bitmap;
            } catch (Exception e) {
                Timber.e("Exception Caught while transforming image to circular ==>> " + e.getMessage());
                if (bitmap != null) {
                    return bitmap;
                } else {
                    return source;
                }
            }
        }

        /**
         * Returns a unique key for the transformation, used for caching purposes. If the transformation
         * has parameters (e.g. size, scale factor, etc) then these should be part of the key.
         */
        @Override
        public String key() {
            return CIRCLE;
        }
    }


}