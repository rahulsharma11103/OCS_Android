package com.wagmob.golearningbus.feature.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.constants.SalesUConstants;

import java.util.List;

import butterknife.BindColor;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Fragment Adapter for tab layout
 *
 * @author Rahul Sharma
 */
public class HomeViewPagerAdapter extends FragmentPagerAdapter {

    int[] mImageId = new int[5];
    int[] mSelectedImageId = new int[5];

    List<Fragment> mfragmentList;
    Context mContext;
    @BindView(R.id.tab_icon)
    AppCompatImageView mTabIcon;
    @BindView(R.id.tab_name)
    AppCompatTextView mTabName;
    @BindColor(R.color.home_tab_title)
    int mSelectedTabTitleColor;
    @BindColor(R.color.home_tab_title_unselected)
    int mUnSelectedTabTitleColor;
    private String mSelectedTabColor;
    private String mTitle[];

    public HomeViewPagerAdapter(FragmentManager fm, List<Fragment> fragmentList, Context context, String selectedTabColor) {
        super(fm);
        mfragmentList = fragmentList;
        mContext = context;
        String tabTitle[] = new String[5];

        if (SalesUConstants.IS_INDIVIDUAL_APP) {
            mImageId[0] = R.drawable.my_course;
            mImageId[1] = R.drawable.dicover;
            mImageId[2] = R.drawable.my_coach;
            mImageId[3] = R.drawable.user_icon;
            mImageId[4] = R.drawable.library_icon;

            mSelectedImageId[0] = R.drawable.my_course_selected;
            mSelectedImageId[1] = R.drawable.dicover_selected;
            mSelectedImageId[2] = R.drawable.my_coach_selected;
            mSelectedImageId[3] = R.drawable.user_icon_selected;
            mSelectedImageId[4] = R.drawable.library_icon_selected;

            tabTitle[0] = context.getString(R.string.my_course);
            tabTitle[1] = context.getString(R.string.all_courses);
            tabTitle[2] = context.getString(R.string.tab_footer_notification);
            tabTitle[3] = context.getString(R.string.tab_footer_me);
            tabTitle[4] = context.getString(R.string.tab_footer_library);
        } else {
            mImageId[0] = R.drawable.dicover;
            mImageId[1] = R.drawable.my_course;
            mImageId[2] = R.drawable.my_coach;
            mImageId[3] = R.drawable.user_icon;
            mImageId[4] = R.drawable.library_icon;

            mSelectedImageId[0] = R.drawable.dicover_selected;
            mSelectedImageId[1] = R.drawable.my_course_selected;
            mSelectedImageId[2] = R.drawable.my_coach_selected;
            mSelectedImageId[3] = R.drawable.user_icon_selected;
            mSelectedImageId[4] = R.drawable.library_icon_selected;

            tabTitle[0] = context.getString(R.string.all_courses);
            tabTitle[1] = context.getString(R.string.my_course);
            tabTitle[2] = context.getString(R.string.tab_footer_notification);
            tabTitle[3] = context.getString(R.string.tab_footer_me);
            tabTitle[4] = context.getString(R.string.tab_footer_library);
        }
        mTitle = tabTitle;
        mSelectedTabColor = selectedTabColor;
    }

    @Override
    public Fragment getItem(int position) {
        return mfragmentList.get(position);
    }

    @Override
    public int getCount() {
        return mfragmentList.size();
    }

   /* @Override
    public CharSequence getPageTitle(int position) {
        return mTabTittle.get(position);
    }*/

    public View getTabView(int position, ViewGroup viewGroup, boolean isTabSelected) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.custom_home_tab_view, viewGroup);
        ButterKnife.bind(this, view);

        if (isTabSelected) {/*
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                mTabIcon.setBackgroundTintList(Color.parseColor(mSelectedTabColor));
            }*/

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                mTabIcon.setBackgroundResource(mImageId[position]);
                mTabIcon.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(mSelectedTabColor)));
            } else {
                mTabIcon.setBackgroundResource(mSelectedImageId[position]);
            }
            mTabName.setText(mTitle[position]);
            mTabName.setTextColor(Color.parseColor(mSelectedTabColor));
        } else {
            mTabIcon.setBackgroundResource(mImageId[position]);
            mTabName.setText(mTitle[position]);
            mTabName.setTextColor(mUnSelectedTabTitleColor);
        }
        return view;
    }
}
