package com.wagmob.golearningbus.model;

/**
 * Created by wagmob on 8/28/2017.
 */

public class FlashCardModelData {
    public FlashCardModelAssignment assignment;
}
