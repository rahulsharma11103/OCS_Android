package com.wagmob.golearningbus.feature.change_password;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.ChangePasswordModel;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.requestModel.ChangePasswordRequest;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import timber.log.Timber;

/**
 * Fragment for change password
 *
 * @author Rahul Sharma
 */

public class ChangePasswordFragment extends LoadDataFragment {

    static Context mContext;
    @BindView(R.id.current_password)
    AppCompatEditText mCurrentPasswordView;
    @BindView(R.id.new_current_password)
    AppCompatEditText mNewPasswordView;
    @BindView(R.id.re_type_password)
    AppCompatEditText mRetypePasswordView;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.change_password_button_layout)
    AppCompatButton mChangePasswordBackgroundButton;

    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.web_service_for_change_user_password)
    String mChangePasswordServiceUrl;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.empty_field_message)
    String mEmptyMessage;
    @BindString(R.string.minimum_password_length_message)
    String mMinimumPasswordLengthMessage;
    @BindString(R.string.new_password_and_re_type_password_not_match)
    String mPasswordNotMatchMessage;
    @BindString(R.string.network_message)
    String mNetworkMessage;


    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    Gson mGson;

    private Unbinder mUnbinder;
    private String mParamName, mSlugUrl, mMethodType;
    private boolean isAccessTokenExpire;


    /**
     * To initialize and return current fragment instance
     *
     * @param context
     * @return current fragment instance
     */
    public static ChangePasswordFragment newInstance(Context context) {

        mContext = context;
        return new ChangePasswordFragment();
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.change_password_view_fragment, container, false);
        mUnbinder = ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(mContext!=null) {
            initializeComponent();
            setupUi();
        }
    }

    private void setupUi() {
        Drawable background = mChangePasswordBackgroundButton.getBackground();
        ((GradientDrawable) background).setColorFilter(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex), PorterDuff.Mode.SRC_ATOP);
    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    @OnClick(R.id.change_password_button_layout)
    public void submitChangePassword() {
        changePassword();
    }

    private void changePassword() {
        String currentPassword = mCurrentPasswordView.getText().toString();
        String newPassword = mNewPasswordView.getText().toString();
        String reEnterPassword = mRetypePasswordView.getText().toString();
        ChangePasswordRequest changePasswordRequest = new ChangePasswordRequest();
        if ((currentPassword != null && !currentPassword.isEmpty()) && (newPassword != null && !newPassword.isEmpty()) &&
                (reEnterPassword != null && !reEnterPassword.isEmpty())) {
            if ((currentPassword.length() > SalesUConstants.MINIMUM_PASSWORD_LENGTH) && (newPassword.length() > SalesUConstants.MINIMUM_PASSWORD_LENGTH)
                    && (reEnterPassword.length() > SalesUConstants.MINIMUM_PASSWORD_LENGTH)) {
                if (newPassword.equalsIgnoreCase(reEnterPassword)) {
                    showLoading();
                    changePasswordRequest.old_password = currentPassword;
                    changePasswordRequest.new_password = newPassword;
                    String paramName = mGson.toJson(changePasswordRequest);
                    callChangePasswordService(paramName, mChangePasswordServiceUrl, SalesUConstants.POST_METHOD_TYPE);
                } else {
                    Toast.makeText(mContext, mPasswordNotMatchMessage, Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(mContext, mMinimumPasswordLengthMessage, Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(mContext, mEmptyMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * call Change password web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callChangePasswordService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new ChangePasswordService().execute();
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Response of Tutorial webservice
     *
     * @param response response of web service
     */
    public void changePasswordWebServiceResponse(String response) {

        hideLoading();

        try {
            ChangePasswordModel changePasswordModel = mGson.fromJson(response, ChangePasswordModel.class);
            if (changePasswordModel != null && changePasswordModel.message != null) {

                Toast.makeText(mContext, changePasswordModel.message[0], Toast.LENGTH_SHORT).show();

            } else {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ex) {
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }


    }


    /**
     * unbind butter knife
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }

    /**
     * To Call Async Web Service
     */
    class ChangePasswordService extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new ChangePasswordService().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new ChangePasswordService().execute();
                    } else {
                        changePasswordWebServiceResponse(s);
                    }
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_INVALID_PASSWORD_CODE) {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.getMessage());
            }

        }
    }
}