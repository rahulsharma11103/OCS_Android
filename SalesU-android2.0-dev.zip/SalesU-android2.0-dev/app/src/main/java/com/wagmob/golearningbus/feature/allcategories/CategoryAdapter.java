package com.wagmob.golearningbus.feature.allcategories;

import android.content.Context;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.model.CategoriesItem;
import com.wagmob.golearningbus.util.ImageUtil;

import java.util.List;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * RecyclerView Adapter For showing list of Category
 *
 * @author Rahul Sharma
 */
public class CategoryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    Context mContext;
    List<CategoriesItem> mCategoriesCollection;
    LinearLayoutManager mLinearLayoutManager;
    int mNumberOfLoadMore = 1;
    boolean isCurrentWebServiceCalling;
    CategoryAdapterInterface mCategoryAdapterInterface;
    private RecyclerView mRecyclerView;
    private int mVisibleThreshold = 2;
    private int mLastVisibleItem, mTotalItemCount;
    private boolean mLoading;

    /**
     * Constructor for Adapter, here we also call listener for pagination
     *
     * @param context         current activity context
     * @param categoriesItems list of category item
     * @param recyclerView    reference of recycler view
     */
    public CategoryAdapter(Context context, List<CategoriesItem> categoriesItems, RecyclerView recyclerView) {
        mRecyclerView = recyclerView;
        mContext = context;
        mCategoriesCollection = categoriesItems;
        if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {
            mLinearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        }
        setScrollListener();
    }

    /**
     * Logic of pagination
     * if total list item is 10 and current focus item is 8 then we call web service for load more items
     */
    private void setScrollListener() {
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                mTotalItemCount = mLinearLayoutManager.getItemCount();
                mLastVisibleItem = mLinearLayoutManager.findLastVisibleItemPosition();
                if (mCategoriesCollection.size() < 10 * mNumberOfLoadMore) {
                    mLoading = true;
                }
                if (!isCurrentWebServiceCalling && !mLoading && (mTotalItemCount <= mLastVisibleItem + mVisibleThreshold)) {
                    isCurrentWebServiceCalling = true;
                    mCategoryAdapterInterface.getMoreCategory(mCategoriesCollection.size());
                }

            }
        });
    }

    public void setOnItemClickListener(CategoryAdapterInterface categoryAdapterInterface) {
        mCategoryAdapterInterface = categoryAdapterInterface;
    }

    /**
     * Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.
     * This new ViewHolder should be constructed with a new View that can represent the items of the given type.
     * You can either create a new View manually or inflate it from an XML layout file.
     *
     * @param parent
     * @param viewType
     * @return Recycler view holder
     */
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.categories_list_item, parent, false);
        viewHolder = new CategoryViewHolder(view);
        return viewHolder;
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     * This method should update the contents of the itemView to reflect the item at the given position.
     *
     * @param holder   Recycler view holder
     * @param position position of current item
     */
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        CategoryViewHolder categoryViewHolder = (CategoryViewHolder) holder;
        configureCategoryViewHolder(categoryViewHolder, position);
    }

    private void configureCategoryViewHolder(CategoryViewHolder categoryViewHolder, int position) {
        final CategoriesItem categoriesItem = mCategoriesCollection.get(position);
        categoryViewHolder.mCategoryTitleName.setText(categoriesItem.title);
        categoryViewHolder.mCategoryNumberOfCourse.setText(categoryViewHolder.mCourseLabel + " : " + categoriesItem.course_count);
        String imageUrl = null;
        ImageUtil.getInstance().loadImage(mContext, categoriesItem.image_url, categoryViewHolder.mCategoryItemImage, R.drawable.placeholder_default_rectangular, false, true);
        categoryViewHolder.mCategoryLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCategoryAdapterInterface.categoryItemClick(categoriesItem);
            }
        });
    }

    /**
     * Called when load more and pagination will needed
     *
     * @param categoryCollection list of category items
     * @param isLoadMoreData     if load more than return true otherwise return false
     */
    public void setCategoryCollection(List<CategoriesItem> categoryCollection, boolean isLoadMoreData) {
        mCategoriesCollection = categoryCollection;
        if (!isLoadMoreData) {
            mNumberOfLoadMore = 1;
            mLoading = false;
            notifyDataSetChanged();
        } else {
            mNumberOfLoadMore = mNumberOfLoadMore + 1;
            isCurrentWebServiceCalling = false;
            notifyItemInserted(mCategoriesCollection.size());
        }
    }

    /**
     * @return list of category list
     */
    public List<CategoriesItem> getCategoryCollection() {
        return mCategoriesCollection;
    }

    /**
     * This method return number of item, if list is null then it return 0
     *
     * @return if list is not null then it return number of list items otherwise it return 0
     */
    @Override
    public int getItemCount() {
        return (mCategoriesCollection != null) ? mCategoriesCollection.size() : 0;
    }

    /**
     * Interface for Adapter
     */
    public interface CategoryAdapterInterface {
        void getMoreCategory(int offset);

        void categoryItemClick(CategoriesItem categoriesItem);
    }

    /**
     * For binding view item
     */
    static class CategoryViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.category_item_image)
        AppCompatImageView mCategoryItemImage;

        @BindView(R.id.category_item_tittle_name)
        AppCompatTextView mCategoryTitleName;

        @BindView(R.id.category_number_of_courses)
        AppCompatTextView mCategoryNumberOfCourse;

        @BindView(R.id.category_list_layout)
        RelativeLayout mCategoryLayout;


        @BindString(R.string.all_category_courses_label)
        String mCourseLabel;

        public CategoryViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }
}
