package com.wagmob.golearningbus.webservice_helper;


import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.net.ssl.HttpsURLConnection;

/**
 * Just Common webservice class, It have methods for consuming web service
 *
 * @author Rahul Sharma
 */

public class WebServiceHelper {

    private final String CLASSNAME = this.getClass().getSimpleName();
    @Inject
    SharedPreferences mSharedPreference;
    private Context mContext;
    private String mEndPoint;
    private String mApiKey;

    public WebServiceHelper(SalesUApplication myApp) {
        mContext = myApp.getApplicationContext();
        myApp.getApplicationModule().inject(this);
        mEndPoint = mContext.getString(R.string.web_service_end_point);
        mApiKey = mContext.getString(R.string.web_service_api_key);

    }

    /*
     *  For Writing param this method take HashMap
	 * object and return string containing required operator between parameter
	 *
	 */

    public String getPostDataString(HashMap<String, String> params)
            throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return result.toString();
    }


    /*
     * For making common web service calling
	 *
	 */


    public String getWebServiceResponse(String methodType, String bodyParams, String method) {

        String inputLine = "";
        StringBuffer resultStr = new StringBuffer("");
        // StringBuilder sb = new StringBuilder(bodyParams);
        // sb.deleteCharAt(0);
        //  sb.deleteCharAt(sb.length()-1);

        //   bodyParams=sb.toString();

        try {

            URL url = new URL(mEndPoint + method);
            //	HttpsURLConnection.setFollowRedirects(false);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();

            String token = mSharedPreference.getString(SalesUConstants.SHARED_ACCESS_TOKEN, "na");
            String refreshToken = mSharedPreference.getString(SalesUConstants.SHARED_REFRESH_TOKEN, "na");

            if (!methodType.equalsIgnoreCase("get")) {
                conn.setDoInput(true);
                conn.setDoOutput(true);
            }
            conn.setRequestMethod(methodType.toUpperCase());
            conn.setRequestProperty("ApiKey", mApiKey);
            conn.setRequestProperty("AccessToken", token);
            conn.setRequestProperty("RefreshToken", refreshToken);
            conn.setRequestProperty("Content-Type", "application/json");

            if (!methodType.equalsIgnoreCase("get")) {
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                        os, "UTF-8"));
                writer.write(bodyParams);
                writer.flush();
                writer.close();
                os.close();
            }
            conn.connect();


            BufferedReader in = new BufferedReader(new InputStreamReader(
                    conn.getInputStream()));

            while ((inputLine = in.readLine()) != null) {


                resultStr.append(inputLine);


            }


        } catch (Exception e) {
            e.printStackTrace();
            resultStr.append("exception");
            Log.i(CLASSNAME + "Exception", e.toString());

        }

        if (SalesUConstants.ISLogVisible)
            Log.i(CLASSNAME + "Webservice Response::", " " + resultStr);

        return resultStr.toString();

    }


     /*
     * For calling payment service
	 *
	 */


    public String getPaymentWebServiceResponse(String methodType, String bodyParams, String method) {

        String inputLine = "";
        StringBuffer resultStr = new StringBuffer("");
        // StringBuilder sb = new StringBuilder(bodyParams);
        // sb.deleteCharAt(0);
        //  sb.deleteCharAt(sb.length()-1);

        //   bodyParams=sb.toString();

        try {

            URL url = new URL(mEndPoint + method);
            //	HttpsURLConnection.setFollowRedirects(false);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();

            String token = mSharedPreference.getString(SalesUConstants.SHARED_ACCESS_TOKEN, "na");
            String refreshToken = mSharedPreference.getString(SalesUConstants.SHARED_REFRESH_TOKEN, "na");

            if (!methodType.equalsIgnoreCase("get")) {
                conn.setDoInput(true);
                conn.setDoOutput(true);
            }
            conn.setRequestMethod(methodType.toUpperCase());
            conn.setRequestProperty("PaymentToken", mContext.getString(R.string.payment_token));
            conn.setRequestProperty("AccessToken", token);
            conn.setRequestProperty("Content-Type", "application/json");

            if (!methodType.equalsIgnoreCase("get")) {
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                        os, "UTF-8"));
                writer.write(bodyParams);
                writer.flush();
                writer.close();
                os.close();
            }
            conn.connect();


            BufferedReader in = new BufferedReader(new InputStreamReader(
                    conn.getInputStream()));

            while ((inputLine = in.readLine()) != null) {


                resultStr.append(inputLine);


            }


        } catch (Exception e) {
            e.printStackTrace();
            resultStr.append("exception");
            Log.i(CLASSNAME + "Exception", e.toString());

        }

        if (SalesUConstants.ISLogVisible)
            Log.i(CLASSNAME + "Webservice Response::", " " + resultStr);

        return resultStr.toString();

    }

     /*
     * For making common web service calling
	 *
	 */


    public String getWebServiceResponse(String methodType, String bodyParams, String method, String googleToken,String facebookToken) {

        String inputLine = "";
        StringBuffer resultStr = new StringBuffer("");
        // StringBuilder sb = new StringBuilder(bodyParams);
        // sb.deleteCharAt(0);
        //  sb.deleteCharAt(sb.length()-1);

        //   bodyParams=sb.toString();

        try {

            URL url = new URL(mEndPoint + method);
            //	HttpsURLConnection.setFollowRedirects(false);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();

            String token = mSharedPreference.getString(SalesUConstants.SHARED_ACCESS_TOKEN, "na");
            String refreshToken = mSharedPreference.getString(SalesUConstants.SHARED_REFRESH_TOKEN, "na");

            if (!methodType.equalsIgnoreCase("get")) {
                conn.setDoInput(true);
                conn.setDoOutput(true);
            }
            conn.setRequestMethod(methodType.toUpperCase());
            conn.setRequestProperty("ApiKey", mApiKey);
            conn.setRequestProperty("AccessToken", token);
            conn.setRequestProperty("RefreshToken", refreshToken);
            if (googleToken != null) {
                conn.setRequestProperty("GoogleToken", googleToken);
            }
            if (facebookToken != null) {
                conn.setRequestProperty("FacebookToken", facebookToken);
            }
            conn.setRequestProperty("Content-Type", "application/json");

            if (!methodType.equalsIgnoreCase("get")) {
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                        os, "UTF-8"));
                writer.write(bodyParams);
                writer.flush();
                writer.close();
                os.close();
            }
            conn.connect();


            BufferedReader in = new BufferedReader(new InputStreamReader(
                    conn.getInputStream()));

            while ((inputLine = in.readLine()) != null) {


                resultStr.append(inputLine);


            }


        } catch (Exception e) {
            e.printStackTrace();
            resultStr.append("exception");
            Log.i(CLASSNAME + "Exception", e.toString());

        }

        if (SalesUConstants.ISLogVisible)
            Log.i(CLASSNAME + "Webservice Response::", " " + resultStr);

        return resultStr.toString();

    }
}
