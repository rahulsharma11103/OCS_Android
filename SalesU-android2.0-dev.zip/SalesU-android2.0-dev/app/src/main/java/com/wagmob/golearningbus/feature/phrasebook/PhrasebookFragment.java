package com.wagmob.golearningbus.feature.phrasebook;

import android.app.Activity;
import android.content.Context;

import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SnapHelper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.assignments.UpdateProgressForSectionEvent;
import com.wagmob.golearningbus.feature.edit_user_profile.EditProfileEvent;
import com.wagmob.golearningbus.model.FlashCardModel;
import com.wagmob.golearningbus.model.FlashCardModelLetters;
import com.wagmob.golearningbus.model.PhraseBookExpandableModelLetters;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.requestModel.AssignmentRequest;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindDrawable;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

public class PhrasebookFragment extends LoadDataFragment {

    @BindString(R.string.network_message)
    String mNetworkMessage;

    @BindString(R.string.web_service_to_get_quiz)
    String mAssignmentWebServiceUrl;

    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;

    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;

    @BindView(R.id.phrasebook_card_view_recycler_view)
    RecyclerView mPhrasebookRecyclerViewCardView;

    @BindView(R.id.phrasebook_list_view_recycler_view)
    RecyclerView mPhrasebookRecyclerViewListView;

    @BindView(R.id.card_number_view)
    AppCompatTextView mCardCountView;

    @BindView(R.id.phrase_list_view_text)
    AppCompatTextView mListCountView;

    @BindView(R.id.current_phrasebook_text)
    AppCompatTextView mCurrentPhrasebookText;

    @BindView(R.id.card_view_image)
    AppCompatImageView mCardViewImage;

    @BindView(R.id.list_view_image)
    AppCompatImageView mListViewImage;

    @BindDrawable(R.drawable.list_ic)
    Drawable mListUnselected;

    @BindDrawable(R.drawable.list_selected)
    Drawable mListSelected;

    @BindDrawable(R.drawable.card_slected)
    Drawable mCardSelected;

    @BindDrawable(R.drawable.card_ic)
    Drawable mCardUnelected;

    @BindDrawable(R.drawable.prev_btn)
    Drawable mPreviousButtonDarkSelected;

    @BindDrawable(R.drawable.prev_card_light_gray)
    Drawable mPreviousButtonLightSelected;

    @BindDrawable(R.drawable.next_card)
    Drawable mNextButtonDarkSelected;

    @BindDrawable(R.drawable.next_card_light_gray)
    Drawable mNextButtonLigthSelected;

    @BindView(R.id.previous_phrasebook_view)
    AppCompatImageView mPreviousImageView;

    @BindView(R.id.next_phrasebook_view)
    AppCompatImageView mNextImageView;

    @BindView(R.id.image_text_view)
    AppCompatTextView mImageSelectedTextView;

    @BindView(R.id.assignment_bottom)
    RelativeLayout mAssingnmentBottom;

    int mCurrentItemPosition = 0;

    @Inject
    SalesUApplication mGlobalApp;

    @Inject
    WebServiceHelper mWebServiceHelper;

    @Inject
    SharedPreferences mSharedPreference;

    @Inject
    EventBus mEventBus;

    @Inject
    Gson mGson;

    PhrasebookFragment mPhrasebookFragment;

    private Context mContext;

    String mAssingmentId;

    PhrasebookCardViewAdapter mPhrasebookCardViewAdapter;

    PhrasebookListViewAdapter mPhrasebookListViewAdapter;

    public List<PhraseBookExpandableModelLetters> mPhraseBookExpandableModelLetters = new ArrayList<PhraseBookExpandableModelLetters>();

    SnapHelper mSnapHelper;

    boolean IsButtonClicked = true;

    LinearLayoutManager mLinearLayoutManager;

    private String mParamName, mSlugUrl, mMethodType;

    private boolean isAccessTokenExpire;

    List<FlashCardModelLetters> mFlashCardModelLetters;

    private Unbinder mUnbinder;

    private boolean isSetProgress;


    PhrasebookCardViewAdapter.PhrasebookListItemAdapterInterface phrasebookListItemAdapterInterface = new PhrasebookCardViewAdapter.PhrasebookListItemAdapterInterface() {
        @Override
        public void cardItemClick(int cardPosition) {
            mPhrasebookRecyclerViewCardView.smoothScrollToPosition(cardPosition);
        }
    };

    public PhrasebookFragment newInstance(Context context, String assignmentId) {
        mPhrasebookFragment = new PhrasebookFragment();
        mPhrasebookFragment.mContext = context;
        mPhrasebookFragment.mAssingmentId = assignmentId;
        return mPhrasebookFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.phrase_card, container, false);
        mUnbinder = ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (mContext != null) {
            initializeComponent();
            initializeAdapter();
            loadPhrasebookCardData();
        }
    }

    private void initializeAdapter() {

        mLinearLayoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false);
        mPhrasebookCardViewAdapter = new PhrasebookCardViewAdapter(mContext, mFlashCardModelLetters);
        mPhrasebookRecyclerViewCardView.setLayoutManager(mLinearLayoutManager);
        mPhrasebookRecyclerViewCardView.setAdapter(mPhrasebookCardViewAdapter);
        mPhrasebookCardViewAdapter.initialteInterfaceListner(phrasebookListItemAdapterInterface);

        final LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        mPhrasebookListViewAdapter = new PhrasebookListViewAdapter(mContext, mFlashCardModelLetters);
        mPhrasebookRecyclerViewListView.setLayoutManager(linearLayoutManager1);
        mPhrasebookRecyclerViewListView.setAdapter(mPhrasebookListViewAdapter);

        mSnapHelper = new StartSnapHelper();
        mSnapHelper.attachToRecyclerView(mPhrasebookRecyclerViewCardView);
        mPhrasebookRecyclerViewCardView.addOnScrollListener(new RecyclerView.OnScrollListener() {

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            /**
             * Callback method to be invoked when the RecyclerView has been scrolled. This will be
             * called after the scroll has completed.
             * <p>
             * This callback will also be called if visible item range changes after a layout
             * calculation. In that case, dx and dy will be 0.
             *
             * @param recyclerView The RecyclerView which scrolled.
             * @param dx           The amount of horizontal scroll.
             * @param dy           The amount of vertical scroll.
             */
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int position = mLinearLayoutManager.findFirstCompletelyVisibleItemPosition();
                if (position >= 0) {
                    moveCardToPosition(position);
                }
            }
        });


        mListViewImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListViewImage.setImageDrawable(mListSelected);
                mCardViewImage.setImageDrawable(mCardUnelected);
                mPhrasebookRecyclerViewCardView.setVisibility(View.GONE);
                mPhrasebookRecyclerViewListView.setVisibility(View.VISIBLE);
                mImageSelectedTextView.setText("List View");
                mAssingnmentBottom.setVisibility(View.GONE);
                mCardCountView.setVisibility(View.GONE);
                mListCountView.setVisibility(View.VISIBLE);

            }
        });

        mCardViewImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mListViewImage.setImageDrawable(mListUnselected);
                mCardViewImage.setImageDrawable(mCardSelected);
                mPhrasebookRecyclerViewCardView.setVisibility(View.VISIBLE);
                mPhrasebookRecyclerViewListView.setVisibility(View.GONE);
                mImageSelectedTextView.setText("Card View");
                mAssingnmentBottom.setVisibility(View.VISIBLE);
                mCardCountView.setVisibility(View.VISIBLE);
                mListCountView.setVisibility(View.GONE);

            }
        });
    }

    private void moveCardToPosition(final int position) {
        if (position != -1 && position < mFlashCardModelLetters.size()) {
            mPhrasebookRecyclerViewCardView.smoothScrollToPosition(position);
            FlashCardModelLetters bookModelLetters = mFlashCardModelLetters.get(position);
            setCardCount(position);
            setTextAtBottom(bookModelLetters.word);
            mCurrentItemPosition = position;
            if (position == 0) {
                mPreviousImageView.setImageDrawable(mPreviousButtonLightSelected);
            } else {
                mPreviousImageView.setImageDrawable(mPreviousButtonDarkSelected);
            }
            if (position == mFlashCardModelLetters.size() - 1) {
                mNextImageView.setImageDrawable(mNextButtonLigthSelected);
            } else {
                mNextImageView.setImageDrawable(mNextButtonDarkSelected);
            }
        } else if (position == -1) {
            mPreviousImageView.setImageDrawable(mPreviousButtonLightSelected);
        }

    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        if (mContext != null)
            ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    @OnClick(R.id.next_phrasebook_view)
    public void moveNextPhrasebook() {
        int positionItem = mCurrentItemPosition;
        moveCardToPosition(++positionItem);
    }

    @OnClick(R.id.previous_phrasebook_view)
    public void movePreviousPhrasebook() {
        int positionItem = mCurrentItemPosition;
        moveCardToPosition(--positionItem);
    }


    public void setCardCount(int currentItem) {
        if (mFlashCardModelLetters != null) {
            mCardCountView.setText("Phrases " + (++currentItem) + " of " + mFlashCardModelLetters.size());
            mListCountView.setText("Phrases " + mFlashCardModelLetters.size());
            if (currentItem == mFlashCardModelLetters.size()) {
                setProgress();
            }
        }
    }


    /**
     * To load Assignment list
     */
    private void loadPhrasebookCardData() {
        showLoading();
        callCategoryListWebService("na", mAssignmentWebServiceUrl + "?assignment_id=" + mAssingmentId, SalesUConstants.GET_METHOD_TYPE);
    }

    /**
     * call All Courses Web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callCategoryListWebService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new GetFlashcardListItem().execute();
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    public void setTextAtBottom(String wordName) {
        mCurrentPhrasebookText.setText(wordName);
    }

    private void setProgress() {
        isSetProgress = true;
        if (mGlobalApp.isNetworkAvailable()) {
            AssignmentRequest assignmentRequest = new AssignmentRequest();
            assignmentRequest.assignment_id = mAssingmentId;
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * calling of Flashcard Web service
     */
    class GetFlashcardListItem extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new GetFlashcardListItem().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new GetFlashcardListItem().execute();
                    } else {
                        if (!isSetProgress) {
                            phrasebookServiceResponse(s);
                        } else {
                            mEventBus.post(new EditProfileEvent(true));
                            mEventBus.post(new UpdateProgressForSectionEvent(true));
                            isSetProgress = false;
                        }
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.getMessage());
            }

        }

    }

    private void phrasebookServiceResponse(String s) {
        hideLoading();
        try {
            FlashCardModel flashCardModel = mGson.fromJson(s, FlashCardModel.class);
            if (flashCardModel != null) {
                mFlashCardModelLetters = flashCardModel.data.assignment.phrasebook_letters;
                mPhrasebookCardViewAdapter.setFlashCardItems(mFlashCardModelLetters);
                mPhrasebookListViewAdapter.setFlashCardItems(mFlashCardModelLetters);
                setCardCount(0);
            }
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }


}