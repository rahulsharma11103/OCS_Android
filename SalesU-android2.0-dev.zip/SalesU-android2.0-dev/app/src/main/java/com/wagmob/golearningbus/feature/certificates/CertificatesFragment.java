package com.wagmob.golearningbus.feature.certificates;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.AppCompatImageView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.util.ImageUtil;
import com.wagmob.golearningbus.view.BaseFragment;
import com.wagmob.golearningbus.view.LoadDataFragment;

import java.io.File;
import java.io.InputStream;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by Rahul Sharma on 6/12/2017.
 */

public class CertificatesFragment extends LoadDataFragment {

    private static Context mContext;
    private static String mCertificateUrl;
    private static View mView;
    private static boolean mIsShareCertificate;
    @BindView(R.id.certificate_view)
    AppCompatImageView mCertificateView;
    @BindString(R.string.something__went_wrong)
    String mSomethingWrong;
    @BindString(R.string.download_location)
    String mDownloadLocationLabel;
    @BindString(R.string.share_certificate_lable)
    String mShareCertificateLable;
    @BindView(R.id.adView)
    AdView mAdView;
    static SharedPreferences mSharedPreference;
    CertificatesActivity.CertificateActivityInterface certificateActivityInterface = new CertificatesActivity.CertificateActivityInterface() {
        @Override
        public void downloadOption() {
            mIsShareCertificate = false;
            new DownloadCertificateAsync().execute(mCertificateUrl);
        }

        @Override
        public void shareOption() {
            mIsShareCertificate = true;
            new DownloadCertificateAsync().execute(mCertificateUrl);
        }
    };
    private Unbinder mUnbinder;

    /**
     * @param context
     * @param certificateUrl
     * @return instance of AssignmentFragment
     */
    public static CertificatesFragment newInstance(Context context, String certificateUrl,SharedPreferences sharedPreference) {
        mCertificateUrl = certificateUrl;
        mContext = context;
        mSharedPreference=sharedPreference;
        return new CertificatesFragment();
    }

    private void shareCertificatesToSocialSites(String fileUrl) {
      /*  Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, mShareCertificateLable);
        i.putExtra(Intent.EXTRA_TEXT, mCertificateUrl);
        startActivity(Intent.createChooser(i, mShareCertificateLable));*/
        File f = new File(fileUrl);
        Uri uri = Uri.parse("file://" + f.getAbsolutePath());
        Intent share = new Intent(Intent.ACTION_SEND);
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.setType("image/*");
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        mContext.startActivity(Intent.createChooser(share, mShareCertificateLable));
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.certificates, container, false);
        mUnbinder = ButterKnife.bind(this, mView);
        ImageUtil.getInstance().loadImage(mContext, mCertificateUrl, mCertificateView, R.drawable.certificate_placeholder, false, true);
        new CertificatesActivity().initializeInterface(certificateActivityInterface);
        setUpBannerImage();
        return mView;
    }

    private void setUpBannerImage() {
        if (mSharedPreference != null) {
            boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

            if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                AdRequest adRequest = new AdRequest.Builder().build();
                mAdView.loadAd(adRequest);
            } else {
                mAdView.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mUnbinder != null) {
            mUnbinder.unbind();
        }
    }

    private void downloadCertificateResponse(final String response) {
        hideLoading();
        if (response != null) {
            if (mIsShareCertificate) {
                mIsShareCertificate = false;
                shareCertificatesToSocialSites(response);
            } else {
                if (mView != null && mDownloadLocationLabel != null && response != null && mContext != null) {
                    Snackbar.make(mView, mDownloadLocationLabel + response, Snackbar.LENGTH_INDEFINITE).setAction(SalesUConstants.OPEN_TEXT, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            new ImageUtil().showImageInGallery(mContext, response);
                        }
                    }).show();
                }
            }
        } else {
            if (SalesUConstants.ISLogVisible)
                Snackbar.make(mView, mSomethingWrong, Snackbar.LENGTH_LONG).show();
        }
    }

    public class DownloadCertificateAsync extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            showLoading();
        }

        /**
         * Override this method to perform a computation on a background thread. The
         * specified parameters are the parameters passed to {@link #execute}
         * by the caller of this task.
         * <p>
         * This method can call {@link #publishProgress} to publish updates
         * on the UI thread.
         *
         * @param params The parameters of the task.
         * @return A result, defined by the subclass of this task.
         * @see #onPreExecute()
         * @see #onPostExecute
         * @see #publishProgress
         */
        @Override
        protected String doInBackground(String... params) {
            String imageURL = params[0];

            Bitmap bitmap = null;
            try {
                // Download Image from URL
                InputStream input = new java.net.URL(imageURL).openStream();
                // Decode Bitmap
                bitmap = BitmapFactory.decodeStream(input);
                imageURL = ImageUtil.saveImageUsingBitMap(bitmap);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return imageURL;

        }

        @Override
        protected void onPostExecute(String imagePath) {
            super.onPostExecute(imagePath);
            downloadCertificateResponse(imagePath);
        }
    }
}
