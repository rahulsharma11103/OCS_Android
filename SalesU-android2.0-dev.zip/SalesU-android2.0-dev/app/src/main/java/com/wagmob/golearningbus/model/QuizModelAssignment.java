package com.wagmob.golearningbus.model;

import java.util.List;

public class QuizModelAssignment {
    public String title;
    public String description;
    public String show_questions;
    public String duration;
    public String total_marks;
    public String passing_marks;
    public String allowed_attempts;
    public String is_shuffle;
    public List<QuizModelQuestion> questions;
}
