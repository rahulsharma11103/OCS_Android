package com.wagmob.golearningbus.feature.mycourses;


import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.JavaUtilClass;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.MyCoursesItem;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.util.ImageUtil;

import org.json.JSONObject;

import java.util.List;

import butterknife.BindColor;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import timber.log.Timber;

/**
 * RecyclerView Adapter For showing list of My Courses
 *
 * @author Rahul Sharma
 */
public class MyCoursesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context mContext;
    List<MyCoursesItem> mCategoriesCollection;
    LinearLayoutManager mLinearLayoutManager;
    int mNumberOfLoadMore = 1;
    boolean isCurrentWebServiceCalling;
    SalesUApplication mGlobalApp;
    CategoryViewHolder mCategoryViewHolder;
    CategoryAdapterInterface mCategoryAdapterInterface;
    private RecyclerView mRecyclerView;
    private int mVisibleThreshold = 2;
    private int mLastVisibleItem, mTotalItemCount;
    private boolean mLoading;
    private boolean mIsGuestLogin;

    /**
     * Constructor for Adapter, here we also call listener for pagination
     *
     * @param context         activity reference
     * @param categoriesItems list of course item
     * @param recyclerView    recycler view object
     */
    public MyCoursesAdapter(Context context, List<MyCoursesItem> categoriesItems, RecyclerView recyclerView, SalesUApplication globalApp, boolean isGuestLogin) {
        mRecyclerView = recyclerView;
        mContext = context;
        mGlobalApp = globalApp;
        mIsGuestLogin = isGuestLogin;
        mCategoriesCollection = categoriesItems;
        if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {
            mLinearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        }
        setScrollListener();
    }

    /**
     * Logic of pagination
     * if total list item is 10 and current focus item is 8 then we call web service for load more items
     */
    private void setScrollListener() {
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                mTotalItemCount = mLinearLayoutManager.getItemCount();
                mLastVisibleItem = mLinearLayoutManager.findLastVisibleItemPosition();

                if (mCategoriesCollection.size() < 10 * mNumberOfLoadMore) {
                    mLoading = true;
                }
                if (!isCurrentWebServiceCalling && !mLoading && (mTotalItemCount <= mLastVisibleItem + mVisibleThreshold)) {
                    isCurrentWebServiceCalling = true;
                    mCategoryAdapterInterface.getMoreCategory(mCategoriesCollection.size());
                }

            }
        });
    }

    public void setOnItemClickListener(CategoryAdapterInterface categoryAdapterInterface) {
        mCategoryAdapterInterface = categoryAdapterInterface;
    }

    /**
     * Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.
     * This new ViewHolder should be constructed with a new View that can represent the items of the given type.
     * You can either create a new View manually or inflate it from an XML layout file.
     *
     * @param parent
     * @param viewType
     * @return Recycler view holder
     */
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.my_courses_list, parent, false);
        viewHolder = new CategoryViewHolder(view);
        return viewHolder;
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     * This method should update the contents of the itemView to reflect the item at the given position.
     *
     * @param holder   Recycler view holder
     * @param position position of current item
     */
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        mCategoryViewHolder = (CategoryViewHolder) holder;
        configureCategoryViewHolder(mCategoryViewHolder, position);

    }

    private void configureCategoryViewHolder(final CategoryViewHolder categoryViewHolder, int position) {
        final MyCoursesItem categoriesItem = mCategoriesCollection.get(position);
        categoryViewHolder.mCategoryTitleName.setText(categoriesItem.title);
        if (categoriesItem.description != null)
            categoryViewHolder.mSubjectDescription.setText(categoriesItem.description);
        int userProgress = Integer.parseInt(JavaUtilClass.calculatePercentage(categoriesItem.total_assignments, categoriesItem.completed_assignments));
       /* categoryViewHolder.mUserProgressView.getProgressDrawable().setColorFilter(
                Color.GREEN, android.graphics.PorterDuff.Mode.SRC_IN);*/
        if (userProgress > 0) {
            if (mIsGuestLogin) {
                categoryViewHolder.mUserPercentageView.setText(categoryViewHolder.mCourseStartLabel);
                categoryViewHolder.mUserPercentageView.setTextColor(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex));
                categoryViewHolder.mUserProgressView.setVisibility(View.GONE);
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    categoryViewHolder.mUserProgressView.setProgressTintList(ColorStateList.valueOf(categoryViewHolder.mUserProgressMyCourseColor));
                }
                categoryViewHolder.mUserProgressView.setVisibility(View.VISIBLE);
                categoryViewHolder.mUserProgressView.setProgress(userProgress);
                categoryViewHolder.mUserPercentageView.setText(userProgress + "% " + categoryViewHolder.mCourseCompleteLabel);
                categoryViewHolder.mUserPercentageView.setTextColor(categoryViewHolder.mUserProgressMyCourseColor);
            }
        } else {
            categoryViewHolder.mUserPercentageView.setText(categoryViewHolder.mCourseStartLabel);
            categoryViewHolder.mUserPercentageView.setTextColor(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex));
            categoryViewHolder.mUserProgressView.setVisibility(View.GONE);
        }
        if (categoriesItem.is_default.equalsIgnoreCase(SalesUConstants.TRUE_RESPONSE_BY_SERVICE)) {
            categoryViewHolder.mUnSubscribeButton.setVisibility(View.GONE);
        } else {
            categoryViewHolder.mUnSubscribeButton.setVisibility(View.VISIBLE);
        }
        String imageUrl = null;
        ImageUtil.getInstance().loadImage(mContext, categoriesItem.image_url, categoryViewHolder.mCategoryItemImage, R.drawable.placeholder_default_rectangular, false, true);
        categoryViewHolder.mCategoryLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                triggerAmplitudeForCourseSelection(categoriesItem.title, mContext.getString(R.string.my_course));
                new BaseNavigator().navigateToCourseDetailsScreen(mContext, categoriesItem);
            }
        });
        categoryViewHolder.mUnSubscribeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(mContext);
                alertDialogBuilder.setTitle(SalesUConstants.ALERT_TITLE_MESSAGE);
                // set dialog message
                alertDialogBuilder
                        .setMessage(SalesUConstants.ALERT_MESSAGE)
                        .setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mCategoryAdapterInterface.unSubscribeClick(categoriesItem, categoryViewHolder);
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = alertDialogBuilder.create();
                // show it
                alertDialog.show();

            }
        });

    }

    private void triggerAmplitudeForCourseSelection(String courseName, String fromWhichScreen) {
        JSONObject jElement;
        try {
            jElement = new JSONObject();
            jElement.put(AmplitudeUtil.COURSE_NAME, courseName);
            jElement.put(AmplitudeUtil.FROM_SCREEN, fromWhichScreen);
            AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_COURSE_TAPPED, jElement);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    /**
     * Called when load more and pagination will needed
     *
     * @param categoryCollection list of my course list
     * @param isLoadMoreData     if load more than retrun true otherwise return false
     */
    public void setCategoryCollection(List<MyCoursesItem> categoryCollection, boolean isLoadMoreData) {
        mCategoriesCollection = categoryCollection;
        if (!isLoadMoreData) {
            mNumberOfLoadMore = 1;
            mLoading = false;
            notifyDataSetChanged();
        } else {
            mNumberOfLoadMore = mNumberOfLoadMore + 1;
            isCurrentWebServiceCalling = false;
            notifyItemInserted(mCategoriesCollection.size());
        }
    }

    /**
     * @return list of Course  list
     */
    public List<MyCoursesItem> getCategoryCollection() {
        return mCategoriesCollection;
    }

    /**
     * This method return number of item, if list is null then it return 0
     *
     * @return if list is not null then it return number of list items otherwise it return 0
     */
    @Override
    public int getItemCount() {
        return (mCategoriesCollection != null) ? mCategoriesCollection.size() : 0;
    }

    /**
     * Interface for Adapter
     */
    public interface CategoryAdapterInterface {
        void getMoreCategory(int offset);

        void unSubscribeClick(MyCoursesItem myCoursesItem, CategoryViewHolder categoryViewHolder);
    }

    /**
     * For binding view item
     */
    static class CategoryViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.category_item_image_view)
        AppCompatImageView mCategoryItemImage;

        @BindView(R.id.category_item_tittle_name)
        AppCompatTextView mCategoryTitleName;

        @BindView(R.id.sub_description)
        AppCompatTextView mSubjectDescription;

        @BindView(R.id.category_list_layout)
        RelativeLayout mCategoryLayout;

        @BindView(R.id.user_progress_bar)
        ProgressBar mUserProgressView;

        @BindView(R.id.course_percentage_view)
        AppCompatTextView mUserPercentageView;

        @BindView(R.id.un_subscribe_button)
        AppCompatButton mUnSubscribeButton;

        @BindColor(R.color.pink)
        int mPinkColor;

        @BindColor(R.color.subscribed_button_background)
        int mUserProgressMyCourseColor;

        @BindColor(R.color.start_course_label)
        int mStartCourseColor;

        @BindColor(R.color.user_progress_my_course_background)
        int mUserProgressMyCourseColorBackGround;

        @BindString(R.string.all_category_courses_label)
        String mCourseLabel;

        @BindString(R.string.my_course_progress_complete)
        String mCourseCompleteLabel;

        @BindString(R.string.my_course_start_course)
        String mCourseStartLabel;

        @BindString(R.string.my_course_course_unsubscribed)
        String mCourseUnsubscribeMessage;

        public CategoryViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }
}
