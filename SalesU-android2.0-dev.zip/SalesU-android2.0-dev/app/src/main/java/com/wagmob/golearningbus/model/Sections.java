package com.wagmob.golearningbus.model;

public class Sections {
    public boolean error;
    public int response_code;
    public String message[];
    public SectionsData data;
}
