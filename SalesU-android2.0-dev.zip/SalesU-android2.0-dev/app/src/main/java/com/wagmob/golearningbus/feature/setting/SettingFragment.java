package com.wagmob.golearningbus.feature.setting;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.requestModel.SharePermissionRequest;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.util.JavaUtil;
import com.wagmob.golearningbus.view.BaseFragment;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import timber.log.Timber;

/**
 * Created by Rahul on 6/2/2017.
 */

public class SettingFragment extends LoadDataFragment {

    static Context mContext;
    @BindView(R.id.build_number_value)
    AppCompatTextView mBuildVersionNameView;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindView(R.id.share_progress_switch)
    Switch mShareProgressSwitchView;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @BindString(R.string.web_service_share_score)
    String mSharePermissionUrl;
    @BindString(R.string.email_address)
    String mEmailAddress;
    @BindString(R.string.email_us_feedback_for)
    String mEmailFeedbackFor;
    @BindString(R.string.app_name)
    String mAppName;
    @BindString(R.string.email_us_application_android)
    String mApplicationOnAndroid;
    @BindString(R.string.sign_in_sign_up_text)
    String mSignInSignUpLabel;
    @BindView(R.id.profile_setting)
    RelativeLayout mProfileSetting;
    @BindView(R.id.profile_change_password)
    RelativeLayout mProfileChangePAssword;
    @BindView(R.id.restore_purchase_app_layout)
    RelativeLayout mRestorePurchaseLayout;
    @BindView(R.id.share_progress_logout)
    RelativeLayout mShareProgressView;
    @BindView(R.id.logout_text)
    AppCompatTextView mLogoutText;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    Gson mGson;

    private boolean isAccessTokenExpire;
    private String mParamName, mSlugUrl, mMethodType;
    private Unbinder mUnbinder;
    private String mVersionName;
    private int mVersionCode;
    SettingInterface mSettingInterface;
    private boolean mIsGuestLogin;

    public interface SettingInterface
    {
        public void restorePurchase();
    }

    public static SettingFragment newInstance(Context context) {
        mContext = context;
        return new SettingFragment();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.setting_screen, container, false);
        mUnbinder = ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(mContext!=null) {
            initializeComponent();
            setSwitcher();
            mIsGuestLogin=mSharedPreference.getBoolean(SalesUConstants.SHARED_IS_GUEST_USER,false);
            if(mIsGuestLogin)
            {
                mProfileSetting.setVisibility(View.GONE);
                mProfileChangePAssword.setVisibility(View.GONE);
                mRestorePurchaseLayout.setVisibility(View.GONE);
                mLogoutText.setText(mSignInSignUpLabel);
                mShareProgressView.setVisibility(View.GONE);
            }
            try {
                PackageInfo pInfo = mContext.getPackageManager().getPackageInfo(mContext.getPackageName(), 0);
                if (pInfo != null) {
                    mVersionName = pInfo.versionName;
                    mVersionCode = pInfo.versionCode;
                    mBuildVersionNameView.setText(mVersionName + " (" + mVersionCode + ")");
                }
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public void setInterfaceListner(SettingInterface settingInterface)
    {
        mSettingInterface=settingInterface;
    }

    private void setSwitcher() {
        final SharedPreferences.Editor mEditor = mSharedPreference.edit();
        boolean switchCondition = mSharedPreference.getBoolean(SalesUConstants.IS_USER_SHARE_PROGRESS + mSharedPreference.getString(SalesUConstants.USER_ID, SalesUConstants.DEFAULT_VALUE), true);
        if (switchCondition) {
            mShareProgressSwitchView.setChecked(true);
        } else {
            mShareProgressSwitchView.setChecked(false);
        }
        mShareProgressSwitchView.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    mEditor.putBoolean(SalesUConstants.IS_USER_SHARE_PROGRESS + mSharedPreference.getString(SalesUConstants.USER_ID, SalesUConstants.DEFAULT_VALUE), true);
                    mEditor.commit();
                    callSharePermissionWebService(SalesUConstants.TRUE_FLAG);
                } else {
                    mEditor.putBoolean(SalesUConstants.IS_USER_SHARE_PROGRESS + mSharedPreference.getString(SalesUConstants.USER_ID, SalesUConstants.DEFAULT_VALUE), false);
                    mEditor.commit();
                    callSharePermissionWebService(SalesUConstants.FALSE_FLAG);
                }
            }
        });
    }

    /**
     * Initialize Dagger
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }


    /*
      * logout button click
     */
    @OnClick(R.id.profile_logout)
    public void userLogout() {
        AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_USER_LOGOUT);
        new BaseNavigator().navigateToLoginActivity(mContext);
    }

    @OnClick(R.id.share_app)
    public void shareAppWithFriends() {
        AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_USER_SHARE);
        new BaseNavigator().navigateToShareActivity(mContext);
    }

    @OnClick(R.id.restore_purchase_app_layout)
    public void restorePurchaseOptionClick() {
        mSettingInterface.restorePurchase();
    }

    @OnClick(R.id.profile_setting)
    public void editProfile() {
        new BaseNavigator().navigateToEditProfileScreen(mContext);
    }

    @OnClick(R.id.profile_change_password)
    public void changePassword() {
        new BaseNavigator().navigateToChangePasswordScreen(mContext);
    }

    @OnClick(R.id.rate_this_app_layout)
    public void rateThisApp() {
        Uri uri = Uri.parse("market://details?id=" + mContext.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        // To count with Play market backstack, After pressing back button,
        // to taken back to our application, we need to add following flags to intent.
             /*   goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                        Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                        Intent.FLAG_ACTIVITY_MULTIPLE_TASK);*/
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(SalesUConstants.PLAY_STORE_URL + mContext.getPackageName())));
        }
    }

    @OnClick(R.id.email_us_layout)
    public void emailUsLayout() {
        try {
            String versionCode = android.os.Build.VERSION.RELEASE;
            String emailBody = "";
            if (mVersionName != null) {
                emailBody = "Hi\n\nMy Device Specification\nVersion Name: " + mVersionName + "\nVersion Code: " + mVersionCode + "\n"
                        + "OS Version: " + versionCode + "\nPhone Manufacture: " + JavaUtil.getDeviceName() + "\n";
            } else {

            }
            if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                    && mGlobalApp.appSettingModel.data.settings.email_id != null) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("mailto:" + mGlobalApp.appSettingModel.data.settings.email_id));
                intent.putExtra(Intent.EXTRA_SUBJECT, mEmailFeedbackFor + " " + mAppName + " " + mApplicationOnAndroid);
                intent.putExtra(Intent.EXTRA_TEXT, emailBody);
                startActivity(intent);
            }
        } catch (ActivityNotFoundException e) {
            //TODO smth
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mUnbinder != null) {
            mUnbinder.unbind();
        }
    }

    private void callSharePermissionWebService(String flag) {
        String userId = mSharedPreference.getString(SalesUConstants.USER_ID, null);
        SharePermissionRequest sharePermissionRequest = new SharePermissionRequest();
        sharePermissionRequest.flag = flag;
        if (userId != null) {
            sharePermissionRequest.user_id = userId;
        }
        String json = mGson.toJson(sharePermissionRequest);
        callLeaderBoardProgressWebService(json, mSharePermissionUrl, SalesUConstants.POST_METHOD_TYPE);
    }

    /**
     * call All Courses Web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callLeaderBoardProgressWebService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new SetLeaderBoardProgress().execute();
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    private void sharePermissionResponse(String s) {

    }

    /**
     * calling of Assignment Web service
     */
    class SetLeaderBoardProgress extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new SetLeaderBoardProgress().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new SetLeaderBoardProgress().execute();
                    } else {
                        sharePermissionResponse(s);
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }
    }
}
