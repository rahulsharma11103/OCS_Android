package com.wagmob.golearningbus.feature.Tour;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.UserInfo;
import com.wagmob.golearningbus.model.requestModel.SignInRequest;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.view.BaseFragment;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import timber.log.Timber;

/**
 * Created by rahul on 10/13/2017.
 */

public class GuestTour extends LoadDataFragment {

    @BindString(R.string.dialogLoadingTitle)
    String mProgressDialogTitle;
    @BindString(R.string.dialogLoadingMessage)
    String mProgressDialogMessage;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @Inject
    Gson mGson;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    SharedPreferences mSharedPreference;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    private boolean isAccessTokenExpire;

    private Unbinder mUnBinder;
    private Context mContext;
    ProgressDialog mProgressDialog;
    private String mParamName, mSlugUrl, mMethodType;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.guest_login, container, false);
        mUnBinder = ButterKnife.bind(this, view);
        mContext = getContext();
        initializeComponent();
        setupProgressDialog();
        return view;
    }

    private void setupProgressDialog() {
        mProgressDialog = new ProgressDialog(mContext);
        mProgressDialog.setTitle(mProgressDialogTitle);
        mProgressDialog.setMessage(mProgressDialogMessage);
        mProgressDialog.setCancelable(false);
    }

    @OnClick(R.id.guest_login_button)
    public void guestLoginClick() {
        callLoginWebService();

    }

    /**
     * Call  web service for login
     */
    private void callLoginWebService() {
        try {
            if (mProgressDialog != null) {
                mProgressDialog.show();
            }
            SignInRequest signInRequest = new SignInRequest();
            signInRequest.email_id = SalesUConstants.GUEST_EMAIL_ID;
            signInRequest.password = SalesUConstants.GUEST_PASSWORD;
            signInRequest.keep_login = String.valueOf(SalesUConstants.KEEP_LOGIN);
            String jobj = mGson.toJson(signInRequest);
            String loginUrlPath = mContext.getString(R.string.web_service_login_by_saleu);
            callLogin(jobj, loginUrlPath, SalesUConstants.POST_METHOD_TYPE);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.toString());
            }
        }
    }

    /**
     * call Login Web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callLogin(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new CallLoginAsnc().execute();
        } else {
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * calling of Assignment Web service
     */
    class CallLoginAsnc extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new CallLoginAsnc().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new CallLoginAsnc().execute();
                    } else {
                        asyncLoginResponse(s);
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.getMessage());
            }

        }
    }

    /**
     * Login web service response
     *
     * @param response
     */
    public void asyncLoginResponse(String response) {

        try {
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            UserInfo userInfo = mGson.fromJson(response, UserInfo.class);
            if (userInfo.error) {
                Toast.makeText(mContext, userInfo.message[0], Toast.LENGTH_SHORT).show();
            } else {
                mGlobalApp.userDetails = userInfo.data.user;
                SharedPreferences.Editor editor = mSharedPreference.edit();
                editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, mGlobalApp.userDetails.accesstoken);
                editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, mGlobalApp.userDetails.refreshtoken);
                editor.putString(SalesUConstants.USER_FIRST_NAME, mGlobalApp.userDetails.first_name);
                editor.putString(SalesUConstants.USER_LAST_NAME, mGlobalApp.userDetails.last_name);
                editor.putString(SalesUConstants.USER_IMAGE_URL, mGlobalApp.userDetails.image_url);
                editor.putString(SalesUConstants.USER_ID, mGlobalApp.userDetails.user_id);
                editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                editor.putBoolean(SalesUConstants.SHARED_IS_GUEST_USER,true);
                editor.commit();
                AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_SIGN_IN_SUCCESSFULLY);
                AmplitudeUtil.userLogIn(mGlobalApp.userDetails);
                new BaseNavigator().navigateToHomeActivity(mContext);
            }
        } catch (Exception ex) {
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    /**
     * initialize Dagger Component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mUnBinder != null) {
            mUnBinder.unbind();
        }
    }
}
