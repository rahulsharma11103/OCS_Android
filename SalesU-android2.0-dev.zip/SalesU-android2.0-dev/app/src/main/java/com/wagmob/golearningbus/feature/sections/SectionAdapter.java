package com.wagmob.golearningbus.feature.sections;


import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.model.SectionsItems;
import com.wagmob.golearningbus.model.SubSectionsItems;

import java.util.List;

/**
 * RecyclerView Adapter For showing list of All Courses
 *
 * @author Rahul Sharma
 */
public class SectionAdapter extends RecyclerView.Adapter<SectionsViewHolder> {


    public int mNumber = 0;
    Context mContext;
    List<SectionsItems> mSectionItems;
    boolean mIsAlreadyPurchase,mIsDefaultCourse;


    /**
     * @param context      reference of activity
     * @param sectionItems list of sections(milestone and sub-milestone)
     */
    public SectionAdapter(Context context, List<SectionsItems> sectionItems, boolean isAlreadyPurchase,boolean isDefaultCourse) {
        mContext = context;
        mSectionItems = sectionItems;
        mIsAlreadyPurchase = isAlreadyPurchase;
        mIsDefaultCourse=isDefaultCourse;
    }

    /**
     * Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.
     * This new ViewHolder should be constructed with a new View that can represent the items of the given type.
     * You can either create a new View manually or inflate it from an XML layout file.
     *
     * @param parent
     * @param viewType
     * @return Recycler view holder
     */
    @Override
    public SectionsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.section_items, parent, false);
        return new SectionsViewHolder(view);
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     * This method should update the contents of the itemView to reflect the item at the given position.
     *
     * @param holder   Recycler view holder
     * @param position position of current item
     */
    @Override
    public void onBindViewHolder(final SectionsViewHolder holder, int position) {

        final SectionsItems sectionsItems = mSectionItems.get(position);
        holder.mVerticalName.setText(sectionsItems.title);
        List<SubSectionsItems> subSectionsItems = sectionsItems.subsections;
        mNumber = 0;
        final SubsectionAdapter subsectionAdapter = new SubsectionAdapter(mContext, subSectionsItems, mNumber, mSectionItems, mIsAlreadyPurchase,mIsDefaultCourse);
        holder.mContentItemRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        holder.mContentItemRecyclerView.setAdapter(subsectionAdapter);
        subsectionAdapter.expand(holder.mArrow);
        holder.mArrow.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (subsectionAdapter.getItemCount() > 0) {
                    subsectionAdapter.collapse(holder.mArrow);
                } else {
                    subsectionAdapter.expand(holder.mArrow);
                }
            }

        });
    }

    /**
     * This method return number of item, if list is null then it return 0
     *
     * @return if list is not null then it return number of list items otherwise it return 0
     */
    @Override
    public int getItemCount() {
        return (mSectionItems != null) ? mSectionItems.size() : 0;
    }

    /**
     * set list of section items
     *
     * @param sectionItems list of section items
     */
    public void setSectionCollection(List<SectionsItems> sectionItems,boolean isAlreadyPurchase) {
        mSectionItems = sectionItems;
        mIsAlreadyPurchase=isAlreadyPurchase;
        notifyDataSetChanged();
    }
}
