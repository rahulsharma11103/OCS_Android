package com.wagmob.golearningbus.model;


public class DeleteWebServiceResponse {
    public boolean error;
    public int response_code;
    public String[] message;
}
