package com.wagmob.golearningbus.feature.pdf_reader;

import android.content.Context;

import com.github.barteksc.pdfviewer.PDFView;

/**
 * Interface for pdf reader
 * @author Rahul Sharma.
 */

public interface PDFViewerService {
    void initialize(Context context, String pdfUrl, PDFView pdfView, String pdfShowLocalProgressTitle, String pdfShowLocalProgressContent);
}
