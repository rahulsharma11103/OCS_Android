package com.wagmob.golearningbus.model.requestModel;



public class ForgotPasswordRequestModel {
    public String email_id;
    public String password;
    public String otp;
}
