package com.wagmob.golearningbus.model;


public class RefreshTokenData {
      public  RefreshTokenSession session;
}
