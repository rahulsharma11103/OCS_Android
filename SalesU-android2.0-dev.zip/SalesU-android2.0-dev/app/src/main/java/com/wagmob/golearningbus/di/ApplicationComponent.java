package com.wagmob.golearningbus.di;

import com.wagmob.golearningbus.feature.Tour.GuestTour;
import com.wagmob.golearningbus.feature.Tour.ImageTour;
import com.wagmob.golearningbus.feature.Tour.TourFragment;
import com.wagmob.golearningbus.feature.Tour.VideoTourFragment;
import com.wagmob.golearningbus.feature.Tour.WebViewTourFragment;
import com.wagmob.golearningbus.feature.allcategories.AllCategoriesFragment;
import com.wagmob.golearningbus.feature.allcategories.PromotionalImage;
import com.wagmob.golearningbus.feature.allcourses.AllCoursesActivity;
import com.wagmob.golearningbus.feature.allcourses.AllCoursesFragment;
import com.wagmob.golearningbus.feature.allcourses.CoursesAdapter;
import com.wagmob.golearningbus.feature.app.HomeActivity;
import com.wagmob.golearningbus.feature.assignment_swipe.SwipeAssignmentActivity;
import com.wagmob.golearningbus.feature.assignments.AssignmentActivity;
import com.wagmob.golearningbus.feature.assignments.AssignmentFragment;
import com.wagmob.golearningbus.feature.certificates.CertificatesActivity;
import com.wagmob.golearningbus.feature.certificates.CertificatesFragment;
import com.wagmob.golearningbus.feature.change_password.ChangePasswordActivity;
import com.wagmob.golearningbus.feature.change_password.ChangePasswordFragment;
import com.wagmob.golearningbus.feature.course_details.CourseDetailsActivity;
import com.wagmob.golearningbus.feature.course_details.CourseDetailsFragment;
import com.wagmob.golearningbus.feature.edit_user_profile.EditProfileActivity;
import com.wagmob.golearningbus.feature.edit_user_profile.EditProfileFragment;
import com.wagmob.golearningbus.feature.flashcard.FlashCardFragment;
import com.wagmob.golearningbus.feature.forgot_password.ForgotPasswordActivity;
import com.wagmob.golearningbus.feature.forgot_password.ForgotPasswordFragment;
import com.wagmob.golearningbus.feature.glb.GLBFragmentTab;
import com.wagmob.golearningbus.feature.home.HomeFragmentTab;
import com.wagmob.golearningbus.feature.launcher.LauncherActivity;
import com.wagmob.golearningbus.feature.launcher.LauncherFragment;
import com.wagmob.golearningbus.feature.leaderboard.LeaderBoardFragment;
import com.wagmob.golearningbus.feature.login.LoginActivity;
import com.wagmob.golearningbus.feature.login.LoginFragment;
import com.wagmob.golearningbus.feature.me.MeFragmentTab;
import com.wagmob.golearningbus.feature.mycourses.MyCoursesFragment;
import com.wagmob.golearningbus.feature.notification.NotificationFragmentTab;
import com.wagmob.golearningbus.feature.notification_detail.NotificationDetailsFragment;
//import com.wagmob.golearningbus.feature.quiz.QuizActivity;
import com.wagmob.golearningbus.feature.phrasebook.PhrasebookFragment;
import com.wagmob.golearningbus.feature.quiz.QuizFragment;
import com.wagmob.golearningbus.feature.quizreportcard.QuizReportCardActivity;
import com.wagmob.golearningbus.feature.quizreportcard.QuizReportCardFragment;
import com.wagmob.golearningbus.feature.search.SearchActivity;
import com.wagmob.golearningbus.feature.search.SearchFragment;
import com.wagmob.golearningbus.feature.sections.SectionsFragment;
import com.wagmob.golearningbus.feature.setting.SettingActivity;
import com.wagmob.golearningbus.feature.setting.SettingFragment;
import com.wagmob.golearningbus.feature.share.ShareActivity;
import com.wagmob.golearningbus.feature.share.ShareFragment;
import com.wagmob.golearningbus.feature.signup.SignUpActivity;
import com.wagmob.golearningbus.feature.signup.SignUpFragment;
//import com.wagmob.golearningbus.feature.tutorial.TutorialActivity;
import com.wagmob.golearningbus.feature.tutorial.TutorialFragment;
//import com.wagmob.golearningbus.feature.video.VideoPlayerActivity;
import com.wagmob.golearningbus.feature.video.VideoPlayerFragment;
import com.wagmob.golearningbus.feature.writer.WriterFragment;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.webservice_helper.AsyncRequest;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import javax.inject.Singleton;

import dagger.Component;

/**
 * It is a dagger component interface,Here we can declared method which is used in classes and fragment
 */
@Singleton
@Component(modules = ApplicationModule.class)
public interface ApplicationComponent {


    void inject(WebServiceHelper webServiceHelper);

    void inject(SignUpActivity sigUpActivity);

    void inject(AsyncRequest async);

    void inject(LauncherActivity launcherActivity);

    void inject(LoginFragment loginFragment);

    void inject(LoginActivity loginFragment);

    void inject(SignUpFragment submitFragment);

    void inject(AllCategoriesFragment allCategoriesFragment);

    void inject(HomeActivity homeActivity);

    void inject(AllCoursesActivity allCoursesActivity);

    void inject(AllCoursesFragment allCoursesFragment);

    void inject(BaseNavigator baseNavigator);

    void inject(MyCoursesFragment myCoursesFragment);

    void inject(CourseDetailsActivity courseDetailsActivity);

    void inject(CourseDetailsFragment courseDetailsFragment);

    void inject(SectionsFragment sectionsFragment);

    void inject(MeFragmentTab meFragmentTab);


    void inject(AssignmentActivity assignmentActivity);

    void inject(AssignmentFragment assignmentFragment);

    //  void inject(QuizActivity quizActivity);

    void inject(QuizFragment quizFragment);

    void inject(VideoPlayerFragment videoPlayerFragment);

    void inject(EditProfileActivity editProfileActivity);

    void inject(EditProfileFragment editProfileFragment);

    void inject(TutorialFragment tutorialFragment);

    void inject(QuizReportCardFragment quizReportCardFragment);

    void inject(LeaderBoardFragment leaderBoardFragment);

    void inject(NotificationFragmentTab notificationFragmentTab);

    void inject(ChangePasswordFragment changePasswordFragment);

    void inject(ForgotPasswordFragment forgotPasswordFragment);

    void inject(SearchFragment searchFragment);

    void inject(LauncherFragment launcherFragment);

    void inject(ImageTour imageTour);

    void inject(TourFragment tourFragment);

    void inject(VideoTourFragment videoTourFragment);

    void inject(WebViewTourFragment webViewTourFragment);

    void inject(NotificationDetailsFragment notificationDetailsFragment);

    void inject(CoursesAdapter coursesAdapter);

    void inject(ChangePasswordActivity changePasswordActivity);

    void inject(ForgotPasswordActivity forgotPasswordActivity);

    void inject(QuizReportCardActivity quizReportCardActivity);

    void inject(SearchActivity searchActivity);

    // void inject(TutorialActivity tutorialActivity);

    // void inject(VideoPlayerActivity videoPlayerActivity);

    void inject(HomeFragmentTab homeFragmentTab);

    void inject(SwipeAssignmentActivity swipeAssignmentActivity);

    void inject(GLBFragmentTab glbFragmentTab);

    void inject(ShareActivity shareActivity);

    void inject(ShareFragment shareFragment);

    void inject(SettingActivity settingActivity);

    void inject(SettingFragment settingFragment);

    void inject(CertificatesActivity certificatesActivity);

    void inject(CertificatesFragment certificatesFragment);

    void inject(PromotionalImage promotionalImage);

    void inject(FlashCardFragment flashCardFragment);

    void inject(WriterFragment writerFragment);

    void inject(GuestTour guestTour);

    void inject(PhrasebookFragment phrasebookFragment);

}
