package com.wagmob.golearningbus.feature.course_details;

/**
 * Created by rahul on 10/23/2017.
 */

public class UpdateForPaymentEvent {
}
