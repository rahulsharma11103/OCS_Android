package com.wagmob.golearningbus.feature.phrasebook;

import android.graphics.drawable.Drawable;
import android.support.v7.widget.AppCompatImageButton;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.wagmob.golearningbus.R;

import butterknife.BindDrawable;
import butterknife.BindView;
import butterknife.ButterKnife;

public class PhrasebookListViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.section_title_name)
    public AppCompatTextView mWordNameView;

    @BindView(R.id.subsection_item_list)
    public RecyclerView mSubSectionRecyclerView;

    @BindView(R.id.card_view)
    public CardView mCardView;


    public PhrasebookListViewHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
    }
}
