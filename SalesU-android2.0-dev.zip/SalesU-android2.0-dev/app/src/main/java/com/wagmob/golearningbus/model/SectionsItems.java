package com.wagmob.golearningbus.model;




import java.util.List;

public class SectionsItems {
    public String section_id;
    public String title;
    public String description;
    public String image_id;
    public String image_url;
    public String section_order;
    public List<SubSectionsItems> subsections;
}
