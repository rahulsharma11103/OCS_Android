package com.wagmob.golearningbus.feature.edit_user_profile;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.UpdateProfileModel;
import com.wagmob.golearningbus.model.UserProfile;
import com.wagmob.golearningbus.model.requestModel.UpdateProfileRequest;
import com.wagmob.golearningbus.util.ImageUtil;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;


/**
 * Fragment for edit profile
 *
 * @author Rahul Sharma
 */

public class EditProfileFragment extends LoadDataFragment {

    private static Context mContext;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.edit_user_image)
    AppCompatImageView mUserImage;

    /*@BindView(R.id.swipe_to_refresh)
    SwipeRefreshLayout mSwipeRefreshLayout;*/
    @BindView(R.id.salesu_icon)
    AppCompatImageView mSalesUIcon;
    @BindView(R.id.edit_profile_first_name_value)
    AppCompatEditText mFirstNameView;
    @BindView(R.id.edit_profile_last_name_value)
    AppCompatEditText mLastNameView;
    @BindView(R.id.edit_profile_email_id_value)
    AppCompatTextView mEmailIdView;
    @BindView(R.id.camera_icon)
    AppCompatImageView mCameraIcon;
    @BindView(R.id.adView)
    AdView mAdView;
    @BindString(R.string.web_service_get_user_profile)
    String mGetUserProfileWebService;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.fields_can_not_null)
    String mEmptyFieldsMessage;
    @BindString(R.string.web_service_update_profile)
    String mUpdateProfileUrl;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @Inject
    Gson mGson;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    EventBus mEventBus;
    View view;
    boolean isSuccessfullyUpdate;
    UpdateProfileRequest updateProfileRequest;
    private String mParamName, mSlugUrl, mMethodType;
    private UserProfile mUserProfile;
    private Unbinder mUnBinder;
    private boolean isAccessTokenExpire;
    private EditProfileInterface mEditProfileInterface;

    public static EditProfileFragment newInstance(Context context) {
        mContext = context;
        return new EditProfileFragment();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.edit_profile, container, false);
        mUnBinder = ButterKnife.bind(this, view);
        mEditProfileInterface = (EditProfileInterface) getActivity();
       /* mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadAssignmentList();
            }
        });*/
        return view;
    }

    @OnClick(R.id.edit_user_image)
    public void selectCameraIcon() {
        mEditProfileInterface.selectImageOption(mUserImage);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(mContext!=null) {
            initializeComponent();
            getUserProfileService();
            setUpBannerImage();
        }
    }

    private void setUpBannerImage() {
        if (mSharedPreference != null) {
            boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

            if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                AdRequest adRequest = new AdRequest.Builder().build();
                mAdView.loadAd(adRequest);
            } else {
                mAdView.setVisibility(View.GONE);
            }
        }
    }

    private void getUserProfileService() {
        /*if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
            // mGlobalApp.sectionsItems = null;
        } else {
            showLoading();
        }*/
        showLoading();
        getUserProfileService("na", mGetUserProfileWebService, SalesUConstants.GET_METHOD_TYPE);
    }

    private void setUpUi() {
        if (mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data.settings.logo_url != null) {
            ImageUtil.getInstance().loadImage(mContext, mGlobalApp.appSettingModel.data.settings.logo_url, mSalesUIcon, true);
        }

        if (mLastNameView != null && mFirstNameView != null &&mEmailIdView!=null
                && mUserProfile != null && mUserProfile.first_name != null && mUserProfile.last_name != null
                &&mUserProfile.email_id!=null) {
            mFirstNameView.setText(mUserProfile.first_name);
            mLastNameView.setText(mUserProfile.last_name);
            mEmailIdView.setText(mUserProfile.email_id);
            ImageUtil.getInstance().loadImage(mContext, mUserProfile.image_url, mUserImage, R.drawable.anonymous_person_big, true, true);
        } else {
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
        }
        hideLoading();
    }

    public void getUserProfileServiceResponse(String response) {
       /* if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
            mSwipeRefreshLayout.setRefreshing(false);
        }*/


        com.wagmob.golearningbus.model.GetUserProfile getUserProfileData = mGson.fromJson(response, com.wagmob.golearningbus.model.GetUserProfile.class);
        mUserProfile = getUserProfileData.data.profile;
        setUpUi();

    }

    public void updateProfileServiceResponse(String response) {
        try {
            hideLoading();
            UpdateProfileModel updateProfileModel = mGson.fromJson(response, UpdateProfileModel.class);
            isSuccessfullyUpdate = true;
            if (updateProfileRequest != null && updateProfileRequest.first_name != null && updateProfileRequest.last_name != null && mUserProfile.image_url != null) {
                SharedPreferences.Editor editor = mSharedPreference.edit();
                editor.putString(SalesUConstants.USER_FIRST_NAME, updateProfileRequest.first_name);
                editor.putString(SalesUConstants.USER_LAST_NAME, updateProfileRequest.last_name);
                editor.putString(SalesUConstants.USER_IMAGE_URL, mUserProfile.image_url);
                editor.commit();
            }
            Toast.makeText(mContext, updateProfileModel.message[0], Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            hideLoading();
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            if (SalesUConstants.ISLogVisible)
                Timber.e(ex.getMessage());
        }

    }


   /* private MyCoursesAdapter.CategoryAdapterInterface categoryAdapterListener = new MyCoursesAdapter.CategoryAdapterInterface() {


    };*/

    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    public void getUserProfileService(String paramName, String path, String methodType) {
        mParamName = paramName;
        mSlugUrl = path;
        mMethodType = methodType;
        new GetUserProfile().execute();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnBinder.unbind();
    }

    public void saveButtonClicked() {
        if (EditProfileActivity.isUserPicNeedToUpdate) {
            EditProfileActivity.isUserPicNeedToUpdate = false;
            showLoading();
            mEditProfileInterface.callUploadToServerImage();
        } else {
            updateProfile();
        }
    }

    private void updateProfile() {
        try {
            if (mFirstNameView != null && mLastNameView != null) {
                if ((mFirstNameView.getText().toString() != null && mFirstNameView.getText().toString().length() >= 1) &&
                        (mLastNameView.getText().toString() != null && mLastNameView.getText().toString().length() >= 1) &&
                        (mUserProfile != null && mUserProfile.image_id != null)) {
                    updateProfileRequest = new UpdateProfileRequest();
                    updateProfileRequest.first_name = mFirstNameView.getText().toString();
                    updateProfileRequest.last_name = mLastNameView.getText().toString();
                    updateProfileRequest.image_id = mUserProfile.image_id;
                    String updateProfileJsonRequest = mGson.toJson(updateProfileRequest);
                    callUpdateProfile(updateProfileJsonRequest, mUpdateProfileUrl, SalesUConstants.POST_METHOD_TYPE);
                } else {
                    Toast.makeText(mContext, mEmptyFieldsMessage, Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ex) {
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }

    }

    public void updateUserPicId(String userPicId, String imageUrl) {
        if (mUserProfile != null && userPicId != null && imageUrl != null) {
            mUserProfile.image_id = userPicId;
            mUserProfile.image_url = imageUrl;
            updateProfile();
        } else {
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            hideLoading();
        }

    }

    @Override
    public void onPause() {
        super.onPause();
        mEventBus.post(new EditProfileEvent(isSuccessfullyUpdate));
    }

    private void callUpdateProfile(String paramName, String mSubscribeSlugUrl, String postMethodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            showLoading();
            mSlugUrl = mSubscribeSlugUrl;
            mParamName = paramName;
            mMethodType = postMethodType;
            new UpdateProfileService().execute();
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    public interface EditProfileInterface {
        void selectImageOption(AppCompatImageView appCompatImageView);

        void callUploadToServerImage();
    }

    class GetUserProfile extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new GetUserProfile().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new GetUserProfile().execute();
                    } else {
                        getUserProfileServiceResponse(s);
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();

                }
            } catch (Exception e) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                hideLoading();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }
    }

    class UpdateProfileService extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new UpdateProfileService().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new UpdateProfileService().execute();
                    } else {
                        updateProfileServiceResponse(s);
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();

                }
            } catch (Exception e) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }
    }
}
