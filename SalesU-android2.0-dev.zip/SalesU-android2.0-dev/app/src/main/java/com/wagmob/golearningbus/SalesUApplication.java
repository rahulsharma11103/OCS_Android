package com.wagmob.golearningbus;

import android.app.Application;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;


import com.crashlytics.android.Crashlytics;
import com.google.android.gms.ads.MobileAds;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.di.ApplicationComponent;
import com.wagmob.golearningbus.di.ApplicationModule;
import com.wagmob.golearningbus.di.DaggerApplicationComponent;
import com.wagmob.golearningbus.model.AppSettingModel;
import com.wagmob.golearningbus.model.AssignmentItems;
import com.wagmob.golearningbus.model.CategoriesItem;
import com.wagmob.golearningbus.model.CoursesItems;
import com.wagmob.golearningbus.model.LeaderBoardModeUserInfo;
import com.wagmob.golearningbus.model.MyAchievement;
import com.wagmob.golearningbus.model.MyAchievementCertificate;
import com.wagmob.golearningbus.model.MyCoursesItem;
import com.wagmob.golearningbus.model.NotificationModelInfo;
import com.wagmob.golearningbus.model.QuizModelAssignment;
import com.wagmob.golearningbus.model.SectionsItems;
import com.wagmob.golearningbus.model.TutorialModelAssignment;
import com.wagmob.golearningbus.model.UserDetails;
import com.wagmob.golearningbus.model.VideoPlayerAssignment;
import com.wagmob.golearningbus.util.AmplitudeUtil;

import io.fabric.sdk.android.Fabric;

import java.util.HashMap;
import java.util.List;

/**
 * It is Base class for maintaining global application state
 *
 * @author Rahul Sharma
 */
public class SalesUApplication extends Application {

    private static Application sApplication;

    public long quizCurrentTime;
    public long quizTime;
    public int videoCurrentTIme;
    /**
     * User Info
     */
    public UserDetails userDetails;
    /**
     * List Of Category Item
     */
    public List<CategoriesItem> categoryItem;
    /*
    *List of My Achievement Item
     */
    public List<MyAchievementCertificate> myAchievementList;
    /**
     * List of CoursesItem
     */
    public List<CoursesItems> coursesItem;
    /**
     * List of My Courses
     */
    public List<MyCoursesItem> myCoursesItem;
    /**
     * List Of Sections
     */
    public List<SectionsItems> sectionsItems;

    /**
     * Quiz Data
     */
    public QuizModelAssignment quizModelAssignment;
    /**
     * Video Data
     */
    public VideoPlayerAssignment videoModelAssignment;
    /**
     * Tutorial  Data
     */
    public TutorialModelAssignment tutorialModelAssignment;
    /**
     * List Of Assignment
     */
    public List<AssignmentItems> assignmentItems;
    /**
     * List Of LeaderBoard Items
     */
    public List<LeaderBoardModeUserInfo> leaderBoardItems;

    /**
     * Notification Info
     */
    public List<NotificationModelInfo> notificationItems;

    /**
     * Info of app setting
     */
    public AppSettingModel appSettingModel;

    private ApplicationModule mApplicationModule;
    private ApplicationComponent mApplicationComponent;

    public static Application getApplication() {
        return sApplication;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        // Fabric.with(this, new Crashlytics());
        sApplication = this;
        initializeInjector();

        // Initialize Amplitude Library.
        AmplitudeUtil.initialize();
        if (SalesUConstants.IS_INDIVIDUAL_APP) {
            MobileAds.initialize(this, SalesUConstants.ADMOB_ADD_ID);
        }

    }

    /**
     * Initialize Dagger Injector
     */
    private void initializeInjector() {

        mApplicationComponent = DaggerApplicationComponent
                .builder()
                .applicationModule(new ApplicationModule(this))
                .build();

    }

    /**
     * this method written Dagger Application Component
     *
     * @return Dagger Application Component
     */
    public ApplicationComponent getApplicationModule() {
        return mApplicationComponent;
    }

    /**
     * To refresh all global object
     */
    public void refreshAllObject() {
        userDetails = null;
        categoryItem = null;
        coursesItem = null;
        myCoursesItem = null;
        quizModelAssignment = null;
        videoModelAssignment = null;
        tutorialModelAssignment = null;
        leaderBoardItems = null;
        notificationItems = null;
        myAchievementList = null;
    }

    /**
     * @return true if network available otherwise it will return false
     */
    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


}
