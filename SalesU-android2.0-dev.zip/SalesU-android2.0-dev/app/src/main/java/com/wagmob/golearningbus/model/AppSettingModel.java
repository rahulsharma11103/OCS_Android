package com.wagmob.golearningbus.model;



public class AppSettingModel {
    public boolean error;
    public int response_code;
    public String[] message;
    public AppSettingModelData data;
}
