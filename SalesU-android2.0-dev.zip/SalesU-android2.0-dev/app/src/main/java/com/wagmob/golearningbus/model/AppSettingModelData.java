package com.wagmob.golearningbus.model;


import java.util.List;

public class AppSettingModelData {
    public AppSettingModelSetting settings;
    public List<AppSettingModelSplash> splash;
    public LibraryInfoModel library;
    public List<PaidPromotionalImageModel> paidpromotional_images;
    public List<UnPaidPromotionalImageModel> unpaidpromotional_images;
}
