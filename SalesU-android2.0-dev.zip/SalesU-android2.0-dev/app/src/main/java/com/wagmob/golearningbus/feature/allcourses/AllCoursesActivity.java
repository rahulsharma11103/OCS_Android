package com.wagmob.golearningbus.feature.allcourses;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.JavaUtil;
import com.wagmob.golearningbus.view.BaseActivity;

import javax.inject.Inject;

import butterknife.BindColor;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Activity class for show list of all courses
 *
 * @author Rahul Sharma
 */
public class AllCoursesActivity extends BaseActivity {

    @BindColor(R.color.white)
    public int mColorWhite;
    @BindView(R.id.toolbar)
    Toolbar mToolBar;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;

    Context mContext;
    @BindString(R.string.search_label_search)
    String mSearchLabel;
    @BindString(R.string.interstitial_add_id)
    String mInterstitialId;
    private InterstitialAd mInterstitialAd;
    boolean mIsAlreadyPurchase;
    private Unbinder mUnBinder;
    private AllCoursesFragment allCoursesFragment;
    private String mCategoryId, mCategoryTitle;
    private SearchView mSearchView;

    /**
     * For getting intent of Current Activity
     *
     * @param context
     * @return Current activity intent
     */
    public static Intent callingIntent(Context context) {
        return new Intent(context, AllCoursesActivity.class);
    }

    /**
     * Use to initialize layout and App bar
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_common);
        mUnBinder = ButterKnife.bind(this);
        setSupportActionBar(mToolBar);
        initializeComponent();
        ActionBar actionBar = getSupportActionBar();
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.color_primary_hex != null) {
            actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex)));
        }
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowTitleEnabled(true);
        mCategoryTitle = getIntent().getStringExtra(SalesUConstants.CATEGORY_TITLE);
        mCategoryId = getIntent().getStringExtra(SalesUConstants.CATEGORY_ID);
        actionBar.setTitle(mCategoryTitle);
        initializeComponent();
        if(mSharedPreference!=null) {
            mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

            if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                mInterstitialAd = new InterstitialAd(this);
                mInterstitialAd.setAdUnitId(mInterstitialId);
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }
        }
        initializeFragment();
    }

    /**
     * Add fragment to activity
     */
    private void initializeFragment() {
        allCoursesFragment = AllCoursesFragment.newInstance(mContext, mCategoryId);
        addFragment(R.id.fragment_common_container, allCoursesFragment);
    }

    /**
     * Initialize Dagger Component
     */
    private void initializeComponent() {
        ((SalesUApplication) this.getApplication()).getApplicationModule().inject(this);
    }

    /**
     * on back pressed course item list refresh
     */
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
            if (mInterstitialAd!=null&&mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            }}
        mGlobalApp.coursesItem = null;
        finish();
    }

    /**
     * unbind butter knife object
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mUnBinder.unbind();
    }

    /**
     * menu option selection
     *
     * @param item
     * @return menu item
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home: {
                if (mInterstitialAd!=null&&mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                mGlobalApp.coursesItem = null;
                finish();
                overridePendingTransition(R.anim.activity_transition_stay_still, R.anim.activity_transition_out);
                break;
            }
            case R.id.search_icon: {
                new BaseNavigator().navigateToSearchScreen(mContext);
                break;
            }

        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * inflate option menu
     *
     * @param menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_item, menu);
       /* mSearchView = (SearchView) menu.findItem(R.id.search_icon).getActionView();
        // mSearchView.setMaxWidth(mSearchViewAutoCompleteMaxSize);
        SearchView.SearchAutoComplete searchAutoComplete = (SearchView.SearchAutoComplete) mSearchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
        searchAutoComplete.setHintTextColor(mColorWhite);
        mSearchView.setQueryHint(mSearchLabel);
        setSearchViewOnQueryTextListener(mSearchView);
        // hide other menu item when SearchView is open or expanded
        mSearchView.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getSupportActionBar() != null) {

                }
            }
        });

        // show other menu item when SearchView close
        mSearchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                // re-show the action button
                if (getSupportActionBar() != null) {

                }
                return false;
            }
        });*/
        return super.onCreateOptionsMenu(menu);
    }

   /* public void setSearchViewOnQueryTextListener(SearchView searchView) {
        try {
            if (searchView != null) {
                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        mSearchView.clearFocus();
                        mSearchView.onActionViewCollapsed();
                        new BaseNavigator().navigateToSearchScreen(mContext, query);
                        //onQueryTextSubmitListener(query);
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        // onQueryTextChangeListener(newText);
                        return false;
                    }
                });
            }
        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e("Exception Caught ==>> " + e.getMessage());
            }
        }
    }*/

}
