package com.wagmob.golearningbus.model;


public class CheckPaymentStatusModelMessage {
    public boolean has_master_subscription;
}
