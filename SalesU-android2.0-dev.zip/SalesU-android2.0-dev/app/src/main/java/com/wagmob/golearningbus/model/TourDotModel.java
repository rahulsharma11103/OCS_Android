package com.wagmob.golearningbus.model;



public class TourDotModel {
    public int tourNumber;
    public boolean isSelected;
}
