package com.wagmob.golearningbus.model;



public class TutorialModelData {

    public TutorialModelAssignment assignment;

}
