package com.wagmob.golearningbus.model;


import java.util.List;

public class QuizModelQuestion {
    public String question_id;
    public String data;
    public String type;
    public List<QuizModelOptions> options;
}
