package com.wagmob.golearningbus.feature.course_details;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;
import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.assignments.UpdateProgressForSectionEvent;
import com.wagmob.golearningbus.feature.notification.NotificationPaymentCheck;
import com.wagmob.golearningbus.feature.sections.SubsectionAdapter;
import com.wagmob.golearningbus.model.MyCoursesItem;
import com.wagmob.golearningbus.model.PostPaymentStatusModel;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.requestModel.PaymentRequestModel;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.util.IabHelper;
import com.wagmob.golearningbus.util.IabResult;
import com.wagmob.golearningbus.util.Inventory;
import com.wagmob.golearningbus.util.JavaUtil;
import com.wagmob.golearningbus.util.Purchase;
import com.wagmob.golearningbus.view.BaseActivity;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.UUID;

import javax.inject.Inject;

import butterknife.BindColor;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

/**
 * Activity class to show course details
 *
 * @author Rahul Sharma
 */
public class CourseDetailsActivity extends BaseActivity {

    @BindColor(R.color.white)
    public int mColorWhite;
    @BindView(R.id.toolbar)
    Toolbar mToolBar;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    Gson mGson;
    @Inject
    EventBus mEventBus;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @BindString(R.string.base64_key_string)
    String mBase64Key;
    @BindString(R.string.payment_already_owned)
    String mPaymentLareadyOwnedLabel;
    @BindString(R.string.payment_canceled_message)
    String mPaymentCancelledLabel;
    @BindString(R.string.sku_key)
    String mSkuKey;
    @BindString(R.string.search_label_search)
    String mSearchLabel;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.dialogLoadingTitle)
    String mProgressDialogTitle;
    @BindString(R.string.dialogLoadingMessage)
    String mProgressDialogMessage;
    @BindString(R.string.web_service_for_post_payment_status)
    String mPostPaymentServiceUrl;
    @BindString(R.string.alert_title)
    String mAlertTitle;
    @BindString(R.string.already_purchase)
    String mAlreadyPurchaseMessage;
    @BindString(R.string.alert_user_purchase_title)
    String mALertTitle;
    @BindString(R.string.alert_offer_for_purchase)
    String mLimitedTimeOfferAlertTitle;
    @BindString(R.string.alert_purchase_message_option_part1)
    String mAlertPurchaseMessageOptionPartOne;
    @BindString(R.string.alert_purchase_message_option_part2)
    String mAlertPurchaseMessageOptionPartTwo;
    @BindString(R.string.alert_continue_with_ads_option)
    String mAlertAdvOption;
    @BindString(R.string.rewarded_video_add_id)
    String mRewardedVideoAdId;
    @BindString(R.string.payload_for_payment)
    String mPayload;
    Context mContext;
    MyCoursesItem myCoursesItem;
    ProgressDialog mProgressDialog;
    private SearchView mSearchView;
    private Unbinder mUnBinder;
    private String mCourseUrl;
    private String mSubsectionId;
    private String mAssignmentTitle;
    boolean mIsDefaultCourse;
    AlertDialog mAlertDialogForUserChoise;
    boolean misAdsVideoLoaded;
    boolean mIsSubsectionClick;
    IabHelper mHelper;
    int mAareadyPurchaseResponse = 7;
    boolean mIsInAppV3SetupCompleted;
    private boolean mIsGuestLogin;
    Purchase mPurchaseDetails;
    SubsectionAdapter.SubsectionAdapterInterface subsectionAdapterInterface = new SubsectionAdapter.SubsectionAdapterInterface() {
        @Override
        public void subSectionItemClicked(String subsectionId, String assignmentTitle, boolean isDefaultCourse) {
            mSubsectionId = subsectionId;
            mAssignmentTitle = assignmentTitle;
            mIsDefaultCourse = isDefaultCourse;
            boolean isAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
            if (isAlreadyPurchase) {
                navigateToAssignmentScreen(mSubsectionId);
            } else {
                if (SalesUConstants.IS_INDIVIDUAL_APP) {
                    if (mIsDefaultCourse) {
                        boolean isShowAds = mSharedPreference.getBoolean(SalesUConstants.IS_USER_CHOOSE_PLAY_ADS, false);

                        navigateToAssignmentScreen(mSubsectionId);

                    } else {
                        if (mIsGuestLogin) {
                            showAlertForGuestLogin();
                        } else {
                            showAlertForAlreadyPurchaseItem();
                        }
                    }

                } else {
                    if (mIsGuestLogin) {
                        showAlertForGuestLogin();
                    } else {
                        showAlertForAlreadyPurchaseItem();
                    }
                }

            }
        }
    };

    CourseDetailsFragment.CourseDetailsFragmentInterface courseDetailsFragmentInterface = new CourseDetailsFragment.CourseDetailsFragmentInterface() {
        @Override
        public void buyNowButtonEvent() {
            if (mIsGuestLogin) {
                showAlertForGuestLogin();
            } else {
                showAlertForAlreadyPurchaseItem();
            }
        }
    };

    public void processPayment() {
        if (mHelper != null && mIsInAppV3SetupCompleted) {
            mHelper.launchPurchaseFlow(CourseDetailsActivity.this, mSkuKey, 1001, mPurchaseFinishedListener, mPayload);
        } else {
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_LONG).show();
        }
    }

    IabHelper.OnIabPurchaseFinishedListener mPurchaseFinishedListener
            = new IabHelper.OnIabPurchaseFinishedListener() {
        public void onIabPurchaseFinished(IabResult result,
                                          Purchase purchase) {
            if (result.isFailure()) {
                String failureMessage = result.getMessage();
                if (result.getResponse() == mAareadyPurchaseResponse) {
                    Toast.makeText(CourseDetailsActivity.this, mAlreadyPurchaseMessage, Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(CourseDetailsActivity.this, mPaymentCancelledLabel, Toast.LENGTH_LONG).show();
                }
                return;
            } else if ((purchase.getSku().equals(mSkuKey)) && verifyPayload(purchase)) {
                mPurchaseDetails = purchase;
                if (mGlobalApp != null && mGlobalApp.appSettingModel != null
                        && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                        && mGlobalApp.appSettingModel.data.settings.app_price != null) {
                    callPayment(mGlobalApp.appSettingModel.data.settings.app_price, purchase);
                } else {
                    callPayment(SalesUConstants.DEFAULT_PAYMENT_AMOUNT, purchase);
                }

            }

        }
    };

    private boolean mIsEnrolled;
    private String mParamName, mSlugUrl, mMethodType;
    private boolean isAccessTokenExpire;

    public static Intent callingIntent(Context context) {
        return new Intent(context, CourseDetailsActivity.class);
    }

    private void showAlertForAlreadyPurchaseItem() {
        String message = null;

        if (mGlobalApp != null && mGlobalApp.appSettingModel != null
                && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.app_price != null) {
            message = mAlertPurchaseMessageOptionPartOne + " "+"$" + mGlobalApp.appSettingModel.data.settings.app_price + " " + mAlertPurchaseMessageOptionPartTwo;
        }
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle(mLimitedTimeOfferAlertTitle);
        if (message != null) {
            alert.setMessage(message);
        }
        alert.setPositiveButton("ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                processPayment();
            }
        });
        alert.show();
    }

    /**
     * Use to initialize layout and App bar
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_common);
        mUnBinder = ButterKnife.bind(this);
        initializeComponent();
        boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
        mIsGuestLogin = mSharedPreference.getBoolean(SalesUConstants.SHARED_IS_GUEST_USER, false);

        mHelper = new IabHelper(this, mBase64Key);
        mHelper.startSetup(new
                                   IabHelper.OnIabSetupFinishedListener() {
                                       public void onIabSetupFinished(IabResult result) {
                                           if (!result.isSuccess()) {
                                               // Log.d("InApp", "In-app Billing setup not ok");
                                               mIsInAppV3SetupCompleted = false;
                                           } else {
                                               mIsInAppV3SetupCompleted = true;
                                               // Log.d("InApp", "In-app Billing is set up OK");
                                               //to get inventory details
                                               //  mHelper.queryInventoryAsync(mGotInventoryListener);

                                           }
                                       }
                                   });

        SubsectionAdapter subsectionAdapter = new SubsectionAdapter();
        subsectionAdapter.initializeInterface(subsectionAdapterInterface);
        setSupportActionBar(mToolBar);
        ActionBar actionBar = getSupportActionBar();
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.color_primary_hex != null) {
            actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex)));
        }
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowTitleEnabled(true);
        myCoursesItem = (MyCoursesItem) getIntent().getSerializableExtra(SalesUConstants.MY_COURSE_MODEL);
        if (myCoursesItem.is_default != null) {
            if (myCoursesItem.is_default.equalsIgnoreCase(SalesUConstants.TRUE_RESPONSE_BY_SERVICE)) {
                mIsDefaultCourse = true;
            }
        }
        setupProgressDialog();
        initializeFragment();
    }

    IabHelper.QueryInventoryFinishedListener mGotInventoryListener = new IabHelper.QueryInventoryFinishedListener() {

        @Override
        public void onQueryInventoryFinished(IabResult result, Inventory inv) {

            // Have we been disposed of in the meantime? If so, quit.
            if (mHelper == null) return;

            // Is it a failure?
            if (result.isFailure()) {
                //   complain("Failed to query inventory: " + result);
                Toast.makeText(CourseDetailsActivity.this, "Inventry Failed", Toast.LENGTH_LONG).show();
                return;
            }


            //  Toast.makeText(InAppBillingActivity.this, "Inventry Successful", Toast.LENGTH_LONG).show();

            Purchase purchase = inv.getPurchase(mSkuKey);
            if (purchase != null && verifyPayload(purchase)) {
                Toast.makeText(CourseDetailsActivity.this, "User Already Purchased", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(CourseDetailsActivity.this, "No Purchasing", Toast.LENGTH_LONG).show();
            }

        }
    };

    private boolean verifyPayload(Purchase purchase) {
        String payloadFromGoogle = purchase.getDeveloperPayload();
        if (mPayload.equals(payloadFromGoogle)) {
            return true;
        } else {
            return false;
        }

    }

    private void showAlertForGuestLogin() {
        AlertDialog.Builder alert = new AlertDialog.Builder(mContext);
        alert.setTitle(mContext.getString(R.string.guest_login_alert_title));
        alert.setMessage(mContext.getString(R.string.guest_login_alert_message));
        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                new BaseNavigator().navigateToLoginActivity(mContext);
            }
        });
        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alert.show();
    }

    /*public void createAlertDialogWithRadioButtonGroup() {
        CharSequence[] alertvalues = {mAlertPurchaseMessageOption, mAlertAdvOption};

        final SharedPreferences.Editor editor = mSharedPreference.edit();


        AlertDialog.Builder builder = new AlertDialog.Builder(CourseDetailsActivity.this);

        builder.setTitle(mALertTitle);

        builder.setSingleChoiceItems(alertvalues, -1, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int item) {

                switch (item) {
                    case 0:
                        editor.putBoolean(SalesUConstants.IS_USER_CHOOSE_PLAY_ADS, false);
                        editor.commit();
                        processPayment();
                        break;
                    case 1:
                        editor.putBoolean(SalesUConstants.IS_USER_CHOOSE_PLAY_ADS, true);
                        editor.commit();


                        break;

                }
                mAlertDialogForUserChoise.dismiss();
            }
        });
        mAlertDialogForUserChoise = builder.create();
        mAlertDialogForUserChoise.show();

    }*/


    /*private void initializePayment() {

        boolean isAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
        if (!isAlreadyPurchase) {
            boolean restorePurchase = bp.loadOwnedPurchasesFromGoogle();
            boolean isSubscribed=bp.isSubscribed(mSkuKey);
           // boolean successfullyConsumed = bp.consumePurchase(mSkuKey);
           // TransactionDetails transactionDetails = bp.getSubscriptionTransactionDetails(mSkuKey);
            if (isSubscribed) {
                // boolean isAutoRenew = transactionDetails.purchaseInfo.purchaseData.autoRenewing;
                SharedPreferences.Editor editor = mSharedPreference.edit();
                editor.putBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, true);
                editor.commit();
            }
            *//*TransactionDetails transactionDetails = bp.getPurchaseTransactionDetails(mSkuKey);
            if (transactionDetails != null) {
                //Already purchased
                //You may save this as boolean in the SharedPreferences.
                SharedPreferences.Editor editor = mSharedPreference.edit();
                editor.putBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, true);
                editor.commit();
              //  showAlertForAlreadyPurchaseItem();
            }*//*
        }

    }*/

    /**
     * Add fragment to activity
     */
    private void initializeFragment() {
        if (myCoursesItem != null) {
            if (myCoursesItem.subscription_id == 0) {
                mIsEnrolled = false;
            } else {
                mIsEnrolled = true;
            }
            CourseDetailsFragment courseDetailsFragment = CourseDetailsFragment.newInstance(mContext, myCoursesItem.course_id, myCoursesItem.image_url, myCoursesItem.title, mIsEnrolled, mIsDefaultCourse);
            addFragment(R.id.fragment_common_container, courseDetailsFragment);
            courseDetailsFragment.initiateIterface(courseDetailsFragmentInterface);
        }
    }

    /**
     * Initialize Dagger Component
     */
    private void initializeComponent() {
        ((SalesUApplication) this.getApplication()).getApplicationModule().inject(this);
    }

    private void setupProgressDialog() {
        mProgressDialog = new ProgressDialog(mContext);
        mProgressDialog.setTitle(mProgressDialogTitle);
        mProgressDialog.setMessage(mProgressDialogMessage);
        mProgressDialog.setCancelable(false);
    }


    /**
     * unbind butter knife object
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mGlobalApp.sectionsItems = null;
        if (mHelper != null) {
            mHelper.dispose();
        }
        mHelper = null;
        if (mUnBinder != null)
            mUnBinder.unbind();
        /*if (mAd != null) {
            mAd.destroy(this);
        }*/
    }

    /**
     * menu option selection
     *
     * @param item
     * @return menu item
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home: {
                finish();
                overridePendingTransition(R.anim.activity_transition_stay_still, R.anim.activity_transition_out);
                break;

            }
            case R.id.search_icon: {
                new BaseNavigator().navigateToSearchScreen(mContext);
                break;
            }

        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * inflate option menu
     *
     * @param menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_item, menu);
      /*  mSearchView = (SearchView) menu.findItem(R.id.search_icon).getActionView();
        // mSearchView.setMaxWidth(mSearchViewAutoCompleteMaxSize);
        SearchView.SearchAutoComplete searchAutoComplete = (SearchView.SearchAutoComplete) mSearchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
        searchAutoComplete.setHintTextColor(mColorWhite);
        mSearchView.setQueryHint(mSearchLabel);
        setSearchViewOnQueryTextListener(mSearchView);
        // hide other menu item when SearchView is open or expanded
        mSearchView.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getSupportActionBar() != null) {

                }
            }
        });

        // show other menu item when SearchView close
        mSearchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                // re-show the action button
                if (getSupportActionBar() != null) {

                }
                return false;
            }
        });*/
        return super.onCreateOptionsMenu(menu);
    }

  /*  public void setSearchViewOnQueryTextListener(SearchView searchView) {
        try {
            if (searchView != null) {
                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        mSearchView.clearFocus();
                        mSearchView.onActionViewCollapsed();
                        new BaseNavigator().navigateToSearchScreen(mContext, query);
                        //onQueryTextSubmitListener(query);
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        // onQueryTextChangeListener(newText);
                        return false;
                    }
                });
            }
        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e("Exception Caught ==>> " + e.getMessage());
            }
        }
    }*/


    private void initializeAmplitudeForPayment(String orderId, boolean isPaymentDone, String originalJson) {
        JSONObject jElement;
        try {
            jElement = new JSONObject(originalJson);
            AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_NAME_FOR_PAYMENT_STATUS, jElement);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    //To generate unique id
    public String generateUniqueId() {
        UUID idOne = UUID.randomUUID();
        return idOne.toString();
    }


    private void navigateToAssignmentScreen(String mSubsectionId) {
        if (mSubsectionId != null) {
            new BaseNavigator().navigateToAssignmentScreen(this, mSubsectionId, mAssignmentTitle);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (!mHelper.handleActivityResult(requestCode,
                resultCode, data)) {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void callPayment(String amount, Purchase purchase) {
        mProgressDialog.show();
        PaymentRequestModel paymentRequestModel = new PaymentRequestModel();
        paymentRequestModel.course_id = myCoursesItem.course_id;
        paymentRequestModel.amount = amount;
        paymentRequestModel.provider = mContext.getString(R.string.payment_provider);
        paymentRequestModel.transaction_key = purchase.getOrderId();
        paymentRequestModel.pkgname = purchase.getPackageName();
        paymentRequestModel.productid = purchase.getSku();
        paymentRequestModel.purchasetoken = purchase.getToken();
        String jsonValue = mGson.toJson(paymentRequestModel);
        callPaymentWebService(jsonValue, mPostPaymentServiceUrl, SalesUConstants.POST_METHOD_TYPE);
    }

    /**
     * call All Courses Web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callPaymentWebService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new SubmitPaymentStatusService().execute();
        } else {
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    private void paymentServiceResponse(String s) {
        if (mProgressDialog != null) {
            mProgressDialog.dismiss();
        }
        try {
            PostPaymentStatusModel postPaymentStatusModel = mGson.fromJson(s, PostPaymentStatusModel.class);
            if (!postPaymentStatusModel.error) {
                SharedPreferences.Editor editor = mSharedPreference.edit();
                editor.putBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, true);
                editor.commit();
                Toast.makeText(mContext, postPaymentStatusModel.message[0], Toast.LENGTH_SHORT).show();
                mEventBus.post(new UpdateProgressForSectionEvent(true));
                mEventBus.post(new NotificationPaymentCheck());
                mEventBus.post(new UpdateForPaymentEvent());
                AmplitudeUtil.logAmplitudeRevenue(mPurchaseDetails.getSku(), SalesUConstants.QUANTITY, SalesUConstants.DEFAULT_PAYMENT_AMOUNT);
                initializeAmplitudeForPayment(mPurchaseDetails.getOrderId(), true, mPurchaseDetails.getOriginalJson());
            } else {
                Toast.makeText(mContext, postPaymentStatusModel.message[0], Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ex) {
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }


    @Override
    protected void onPause() {
        super.onPause();
    }


    @Override
    protected void onResume() {
        super.onResume();

    }

    /**
     * To Call Async Web Service
     */
    class SubmitPaymentStatusService extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getPaymentWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new SubmitPaymentStatusService().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new SubmitPaymentStatusService().execute();
                    } else {
                        paymentServiceResponse(s);
                    }
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_INVALID_PASSWORD_CODE) {
                    if (mProgressDialog != null) {
                        mProgressDialog.dismiss();
                    }
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_INVALID_USER_ID) {
                    if (mProgressDialog != null) {
                        mProgressDialog.dismiss();
                    }
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                } else {
                    if (mProgressDialog != null) {
                        mProgressDialog.dismiss();
                    }
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                if (mProgressDialog != null) {
                    mProgressDialog.dismiss();
                }
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }


    }

}
