package com.wagmob.golearningbus.model;


public class AppSettingModelSplash {
    public String splash_id;
    public String splash_type;
    public String splash_url;
    public String image_landscape;
    public String image_landscape_url;
    public String image_portrait;
    public String image_portrait_url;
    public String splash_order;
    public String video_url;
    public String html_url;
}
