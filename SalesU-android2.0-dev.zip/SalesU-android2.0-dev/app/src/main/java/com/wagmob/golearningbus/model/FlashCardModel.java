package com.wagmob.golearningbus.model;

/**
 * Created by Rahul on 8/28/2017.
 */

public class FlashCardModel {
    public boolean error;
    public int response_code;
    public String message[];
    public FlashCardModelData data;
}
