package com.wagmob.golearningbus.feature.quiz;


import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.AssignmentItems;
import com.wagmob.golearningbus.model.QuizModel;
import com.wagmob.golearningbus.model.QuizModelQuestion;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import timber.log.Timber;

/**
 * Fragment for  showing Quiz
 *
 * @author Rahul Sharma
 */
public class QuizFragment extends LoadDataFragment {

    public long mQuizCurrentTime;
    Context mContext;
    String mAssignmentId;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.quiz_option_list)
    RecyclerView mQuizOptionView;
    @BindView(R.id.quiz_timer)
    AppCompatTextView mQuizTimer;
    @BindView(R.id.quiz_question_text)
    AppCompatTextView mQuizQuestionText;
    @BindView(R.id.quiz_question_html)
    WebView mQuizQuestionHtml;
    @BindView(R.id.quiz_no_of_question)
    AppCompatTextView mNumberOfQuizView;
    @BindView(R.id.scrollViewLayout)
    ScrollView mScrollView;
    @BindString(R.string.quiz_time_up_message)
    String mTimeUpMessage;
    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.web_service_to_get_quiz)
    String quizServiceUrl;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.quiz_html_type)
    String mQuizHtmlTypeString;
    @BindString(R.string.quiz_text_type)
    String mQuizTextTypeString;
    @BindString(R.string.quiz_number_of_question)
    String mNumberOfQuizString;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @BindView(R.id.adView)
    AdView mAdView;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    Gson mGson;
    LayoutInflater mInflater;
    View mView;
    QuizAdapter mQuizAdapter;
    CountDownTimer mCountDownTimer;
    int currentQuestion = 0;
    long mTimeForSingleQuiz = 0;
    int mTotalCorrectAnswer = 0;
    int mTotalShowQuestion = 0;
    int mTotalPercentage = 0;
    QuizFragment mQuizFragment;
    private boolean isViewShown = false;
    private Unbinder mUnbinder;
    private long mCurrentTime;
    private boolean isQuizPause;
    private boolean isQuestionChange;
    private String mParamName, mSlugUrl, mMethodType;
    private boolean isAccessTokenExpire;
    private AlertDialog mAlert;
    private boolean mIsFirstQuiz;
    private int mTabPosition;
    private boolean mIsAlreadyGetServiceResponse;
    private List<AssignmentItems> mCollectionAssignmentItems;
    private QuizAdapter.QuizAdapterInterface quizAdapterInterface = new QuizAdapter.QuizAdapterInterface() {
        @Override
        public void quizOptionSelectEvent(boolean isSelectedOptionTrue) {
            showDialogMessage(isSelectedOptionTrue);

        }
    };

    /**
     * To return Current Fragment instance
     *
     * @param ctx Activity Context
     * @return Current Fragment instance
     */
    public QuizFragment newInstance(Context ctx, String assignmentId, boolean isFirstQuiz, List<AssignmentItems> collectionAssignmentItems, int tabPosition) {
        mQuizFragment = new QuizFragment();
        mQuizFragment.mContext = ctx;
        mQuizFragment.mAssignmentId = assignmentId;
        mQuizFragment.mIsFirstQuiz = isFirstQuiz;
        mQuizFragment.mCollectionAssignmentItems = collectionAssignmentItems;
        mQuizFragment.mTabPosition = tabPosition;
        return mQuizFragment;
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mInflater = inflater;
        mView = inflater.inflate(R.layout.quiz_fragment, container, false);
        mUnbinder = ButterKnife.bind(this, mView);
        mQuizQuestionHtml.getSettings().setJavaScriptEnabled(true);
        return mView;
    }

    /**
     * Load UI and Components
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initializeComponent();
        if (mGlobalApp != null) {
            boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

            if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                AdRequest adRequest = new AdRequest.Builder().build();
                mAdView.loadAd(adRequest);
            } else {
                mAdView.setVisibility(View.GONE);
            }
            loadQuiz();
        }
    }

    /**
     * Initialize Dagger Component
     */
    private void initializeComponent() {
        if (mContext != null) {
            ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
        }
    }

    /**
     * set up Ui and adapter for recycler view
     */
    private void setupUI() {
        mQuizOptionView.setLayoutManager(new LinearLayoutManager(mContext));
        mQuizAdapter = new QuizAdapter(mContext, mGlobalApp);
        mQuizAdapter.setQuizAdapterOptionListener(quizAdapterInterface);
        mQuizOptionView.setAdapter(mQuizAdapter);
        if (mGlobalApp.quizModelAssignment != null && mGlobalApp.quizModelAssignment.show_questions != null && mGlobalApp.quizModelAssignment.duration != null) {
            int totalDuration = Integer.parseInt(mGlobalApp.quizModelAssignment.duration);
            mTotalShowQuestion = Integer.parseInt(mGlobalApp.quizModelAssignment.show_questions);
            float timeInFloat = totalDuration / mTotalShowQuestion;
            int totalSeconds = (int) (timeInFloat * 60);
            mTimeForSingleQuiz = totalSeconds * 1000;
            mGlobalApp.quizTime = mTimeForSingleQuiz;
        }
        setupQuizQuestionAndOption(currentQuestion);
    }

   /* */

    /**
     * show alert dialog box for correct or incorrect option selection
     *//*
    private void showDialogMessage(boolean isSelectedOptionTrue) {
        final Dialog dialog = new Dialog(mContext);

        dialog.setContentView(R.layout.quiz_dialog);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(false);

        AppCompatImageView correct_or_incorrect_icon = (AppCompatImageView) dialog.findViewById(R.id.correct_or_incorrect_icon);
        AppCompatTextView optionDetails = (AppCompatTextView) dialog.findViewById(R.id.option_details);

        if (isSelectedOptionTrue) {
            ++mTotalCorrectAnswer;
            correct_or_incorrect_icon.setImageResource(R.drawable.quizright);
        } else {
            correct_or_incorrect_icon.setImageResource(R.drawable.quizwrong);
        }

        AppCompatButton quizContinue = (AppCompatButton) dialog.findViewById(R.id.continue_quiz);
        optionDetails.setVisibility(View.INVISIBLE);
        mCountDownTimer.cancel();
        dialog.show();

        quizContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

                setupQuizQuestionAndOption(++currentQuestion);


            }
        });
    }*/
    private void showDialogMessage(boolean isSelectedOptionTrue) {
        try {
            //inflating layout and finding RatingBar widget
            View dialog = ((LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.quiz_dialog, null);

            AppCompatImageView correct_or_incorrect_icon = (AppCompatImageView) dialog.findViewById(R.id.correct_or_incorrect_icon);
            AppCompatTextView optionDetails = (AppCompatTextView) dialog.findViewById(R.id.option_details);
            AppCompatTextView correct_or_incorrect_text_view = (AppCompatTextView) dialog.findViewById(R.id.option_details_correct_or_incorrect);
            AppCompatTextView quizContinue = (AppCompatTextView) dialog.findViewById(R.id.continue_quiz);

            isQuestionChange = true;

            if (isSelectedOptionTrue) {
                ++mTotalCorrectAnswer;
                correct_or_incorrect_icon.setImageResource(R.drawable.quiz_correct_emoji);
                correct_or_incorrect_text_view.setText(getString(R.string.quiz_correct_string));
                optionDetails.setText(R.string.quiz_well_done_message);
                optionDetails.setTextColor(ContextCompat.getColor(mContext, R.color.quiz_right_option_text_background));
            } else {
                correct_or_incorrect_icon.setImageResource(R.drawable.quiz_incorrect_emoji);
                correct_or_incorrect_text_view.setText(getString(R.string.quiz_incorrect_string));
                optionDetails.setText(R.string.quiz_oops_message);
                optionDetails.setTextColor(ContextCompat.getColor(mContext, R.color.red));
            }

            AlertDialog.Builder builder = new AlertDialog.Builder(mContext)
                    .setView(dialog);
            mAlert = builder.create();
            mAlert.setCanceledOnTouchOutside(false);
            mAlert.setCancelable(false);
            mAlert.show();
            boolean isTablet = mContext.getResources().getBoolean(R.bool.isTablet);
            if (isTablet) {
                mAlert.getWindow().setLayout(600, 300);
            }
            mCountDownTimer.cancel();

            quizContinue.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mAlert.dismiss();
                    setupQuizQuestionAndOption(++currentQuestion);
                }
            });


        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e("ShowRateDialog Exception: " + e);
            }
        }
    }

    private void setupQuizQuestionAndOption(int currentQuestion) {
        if (mGlobalApp != null && mGlobalApp.quizModelAssignment != null && mGlobalApp.quizModelAssignment.questions != null) {
            if (!(mGlobalApp.quizModelAssignment.questions.size() == 0)) {
                if (currentQuestion < mGlobalApp.quizModelAssignment.questions.size()) {
                    mScrollView.fullScroll(ScrollView.FOCUS_UP);
                    mIsAlreadyGetServiceResponse = true;
                    QuizModelQuestion quizQuestion = mGlobalApp.quizModelAssignment.questions.get(currentQuestion);
                    if (quizQuestion != null && mGlobalApp.quizModelAssignment.show_questions != null && quizQuestion.type != null && quizQuestion.data != null) {
                        if (Integer.parseInt(mGlobalApp.quizModelAssignment.show_questions) > currentQuestion) {
                            mNumberOfQuizView.setText(mNumberOfQuizString + " " + (++currentQuestion) + " of  " + mGlobalApp.quizModelAssignment.show_questions);
                            if (quizQuestion.type.equalsIgnoreCase(mQuizTextTypeString)) {
                                mQuizQuestionHtml.setVisibility(View.GONE);
                                mQuizQuestionText.setVisibility(View.VISIBLE);
                                mQuizQuestionText.setText(quizQuestion.data);

                            } else {
                                mQuizQuestionText.setVisibility(View.GONE);
                                mQuizQuestionHtml.setVisibility(View.VISIBLE);
                                mQuizQuestionHtml.loadDataWithBaseURL("", quizQuestion.data, "text/html", "UTF-8", "");
                            }
                            if (quizQuestion.options != null) {
                                mQuizOptionView.setLayoutManager(new LinearLayoutManager(mContext));
                                mQuizAdapter = new QuizAdapter(mContext, mGlobalApp);
                                mQuizAdapter.setQuizAdapterOptionListener(quizAdapterInterface);
                                mQuizOptionView.setAdapter(mQuizAdapter);
                                mQuizAdapter.setQuizOption(quizQuestion.options);
                            }
                            if (!isViewShown || isQuestionChange) {
                                //setTimerHelper(mTimeForSingleQuiz);
                            }
                            if (isQuestionChange) {
                                setTimerHelper(mTimeForSingleQuiz);
                            } else if (mIsFirstQuiz) {
                                mIsFirstQuiz = false;
                                setTimerHelper(mTimeForSingleQuiz);
                            } else if (isViewShown && mIsAlreadyGetServiceResponse) {
                                setTimerHelper(mTimeForSingleQuiz);
                            }
                        } else {
                            calculatePercentage();
                            new BaseNavigator().navigateToQuizReportCardScreen(mContext, mAssignmentId, String.valueOf(mTotalPercentage), mCollectionAssignmentItems, mTabPosition);
                        }
                    } else {
                        Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    calculatePercentage();
                    new BaseNavigator().navigateToQuizReportCardScreen(mContext, mAssignmentId, String.valueOf(mTotalPercentage), mCollectionAssignmentItems, mTabPosition);
                }
            } else {
                if (mCountDownTimer != null) {
                    mCountDownTimer.cancel();
                    mCountDownTimer = null;
                }
                Toast.makeText(mContext, mContext.getString(R.string.quiz_no_question_available), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void calculatePercentage() {
        mTotalPercentage = ((mTotalCorrectAnswer * 100) / mTotalShowQuestion);
    }

    /**
     * Timer for quiz
     *
     * @param startTimer start time for quiz
     */
    public void setTimerHelper(long startTimer) {
        if (mCountDownTimer != null) {
            mCountDownTimer.cancel();
            mCountDownTimer = null;
        }
        mCountDownTimer = new CountDownTimer(startTimer, 1000) {

            public void onTick(long millisUntilFinished) {
                mGlobalApp.quizCurrentTime = millisUntilFinished;
                mQuizTimer.setText("" + String.format("%d : %d",
                        TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished),
                        TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));
            }

            public void onFinish() {
                mQuizTimer.setText(mTimeUpMessage);
                isQuestionChange = true;
                setupQuizQuestionAndOption(++currentQuestion);
            }
        }.start();
    }

    /**
     * To call Quiz web service
     */
    private void loadQuiz() {
        showLoading();
        callQuizDataService("na", quizServiceUrl + "?assignment_id=" + mAssignmentId, SalesUConstants.GET_METHOD_TYPE);
    }

    /**
     * call Quiz web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callQuizDataService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new QuizService().execute();
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Response of Quiz webservice
     *
     * @param response response of web service
     */
    public void quizWebServiceResponse(String response) {

        hideLoading();
        try {
            QuizModel quizModel = mGson.fromJson(response, QuizModel.class);
            if (quizModel != null && quizModel.data.assignment != null) {
                mGlobalApp.quizModelAssignment = quizModel.data.assignment;
                setupUI();
            } else {
                //  Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            //   Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        if (mIsAlreadyGetServiceResponse) {
            setTimerHelper(mGlobalApp.quizTime);
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (getView() != null) {
            if (mAdView != null && mSharedPreference != null) {
                boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

                if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                    AdRequest adRequest = new AdRequest.Builder().build();
                    mAdView.loadAd(adRequest);
                } else {
                    mAdView.setVisibility(View.GONE);
                }
            }
            isViewShown = true;
            // fetchdata() contains logic to show data when page is selected mostly asynctask to fill the data
            if (mIsAlreadyGetServiceResponse) {
                setTimerHelper(mGlobalApp.quizTime);
            }
        } else {
            isQuestionChange = false;
            isViewShown = false;
            if (mCountDownTimer != null)
                mCountDownTimer.cancel();
        }

        if (!isVisibleToUser) {
            if (mCountDownTimer != null) {
                mCountDownTimer.cancel();
            }
        }
       /* if (isVisibleToUser) {
            if (mQuizFragment != null) {
             *//*   if(mQuizCurrentTime!=0)
                mQuizFragment.setTimerHelper(mQuizCurrentTime);*//*
               // loadQuiz();
            }
        } else {
            if (mCountDownTimer != null) {
                mCountDownTimer.cancel();
            }
        }*/
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mCountDownTimer != null) {
            mCountDownTimer.cancel();
        }
    }

    /**
     * To Call Async Web Service
     */
    class QuizService extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new QuizService().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new QuizService().execute();
                    } else {
                        quizWebServiceResponse(s);
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                //  Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());

            }

        }
    }
}
