package com.wagmob.golearningbus.constants;

/**
 * Class contains all static constants variable
 */

public class SalesUConstants {

    public static final java.lang.String ADMOB_ADD_ID ="ca-app-pub-3866852057283684~2475472107" ;

    public static final boolean ISLogVisible = true;
    public static final boolean IS_INDIVIDUAL_APP=true;

    public static final int KEEP_LOGIN = 1;
    public static final String GET_METHOD_TYPE = "get";
    public static final String POST_METHOD_TYPE = "post";

    public static final String GUEST_EMAIL_ID="guestuser569vctf@hfg.com";
    public static final String GUEST_PASSWORD="19Jerkldj&!";

    //Share Preferences Key
    public static final String SHARED_ACCESS_TOKEN = "accesstoken";
    public static final String SHARED_REFRESH_TOKEN = "refreshtoken";
    public static final String SHARED_IS_ALREADY_LOGGED_IN = "already_login";
    public static final String SHARED_IS_GUEST_USER="is_guest_user";
    public static final String USER_FIRST_NAME = "first_name";
    public static final String USER_LAST_NAME = "last_name";
    public static final String USER_IMAGE_URL = "image_url";
    public static final String USER_ID = "user_id";
    public static final String RESPONSE_CODE_STRING = "response_code";
    public static final String RESPONSE_CODE_MESSAGE_STRING = "message";
    public static final int RESPONSE_CODE_NUMBER_FOR_SESSION_EXPIRED_CODE = 1004;
    public static final int RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN = 1003;
    public static final int RESPONSE_CODE_NUMBER_FOR_SUCCESS = 1000;
    public static final int RESPONSE_CODE_NUMBER_FOR_INVALID_PASSWORD_CODE = 1007;
    public static final int RESPONSE_CODE_NUMBER_FOR_INVALID_USER_ID = 1002;
    public static final int REQUEST_MAX_LIMIT_DATA = 10;
    public static final float DEFAULT_COURSE_RATING = 3.5f;
    public static final String CATEGORY_ID = "category_id";
    public static final String CATEGORY_TITLE = "category_title";
    public static final String COURSE_ID = "course_id";
    public static final String COURSE_IMAGE_URL = "course_image_url";
    public static final String DEFAULT_PROGRESS_PERCENTAGE = "70";
    public static final int DEFAULT_TOTAL_PROGRESS_PERCENTAGE = 100;
    public static final String SUBSECTION_ID = "subsection_id";
    public static final long QUIZ_TOTAL_TIME_DURATION = 90000;
    public static final String ASSIGNMENT_VIDEO_URL = "video_url";
    public static final String ASSIGNMENT_ID = "assignment_id";
    public static final String ASSIGNMENT_NAME = "assignment_name";
    public static final int MINIMUM_PASSWORD_LENGTH = 5;
    public static final String NOTIFICATION_MODEL_INFO = "notification_details";
    public static final String ASSIGNMENT_DETAILS = "assignment_details";
    public static final String ASSIGNMENT_DEFAULT_TAB = "assignment_default_tab";
    public static final String COURSE_READ = "1";
    public static final String ZERO_MILISECONDS = ".000Z";
    public static final String BUG_SEE_KEY = "afed1ff6-d9db-404f-9a9b-7a2502acbdf0";
    public static final int BUG_SEE_MAX_RECORD_TIME = 30;
    public static final String DEFAULT_PAYMENT_AMOUNT = "9.99";
    public static final int QUANTITY = 1;
    public static final String TRUE_FLAG = "1";
    public static final String FALSE_FLAG = "0";
    public static final String PERMISSION_ASKED = "permission_request";
    public static final String IS_USER_SHARE_PROGRESS="is_user_share_progress";
    public static final String DEFAULT_VALUE = "no_value";
    public static final String OPEN_TEXT = "Open";
    public static String IS_USER_ALREADY_PURCHASE_ITEM = "is_already_purchase";
    public static String IS_USER_CHOOSE_PLAY_ADS="is_show_ads";
    public static String AD_TAKE_PHOTO = "Take Photo";
    public static String AD_CHOOSE_FROM_LIBRARY = "Choose from Library";
    public static String AD_CANCEL = "Cancel";
    public static String AD_ADD_PHOTO = "Add Photo!";
    public static String SELECT_FILE = "Select File";
    public static String SELECT_IMAGE_TYPE = "image/*";
    public static String CAMERA_PERMISSION_MESSAGE = "Camera permission needed. Please allow in App Settings for additional functionality.";
    public static String STORAGE_PERMISSION_MESSAGE = "External Storage permission needed. Please allow in App Settings for additional functionality.";
    public static String MICROPHONE_PERMISSION_MESSAGE = "Microphone permission needed for recording. Please allow in App Settings for additional functionality.";
    public static String QUIZ_CORRECT_OPTION_STRING = "1";
    public static String QUIZ_PERCENTAGE = "quiz_percentage";
    public static String PERCENTAGE_SYMBOL = "%";
    public static int MINIMUM_PERCENTAGE_TO_PASS = 75;
    public static String GOOGLE_URL_FOR_PDF_VIEWER = "http://drive.google.com/viewerng/viewer?embedded=true&url=";
    public static String SEARCH_QUERY_STRING = "search_query_string";
    public static String TRUE_RESPONSE_BY_SERVICE = "1";
    public static String FREE_COURSE_STRING = "0";
    public static String SPLASH_TYPE_VIDEO = "video";
    public static String SPLASH_TYPE_IMAGE = "image";
    public static String SPLASH_TYPE_HTML = "html";
    public static String SPLASH_TYPE_GUEST_LOGIN = "guest_login";
    public static String DEFAULT_URL_FOR_VIDEO = "https://guidemevideoprod.blob.core.windows.net/asset-d313884c-182c-449a-855c-bbed0abab70b/welcome-to-edcast-57e64ace83826_1280x720_4500.mp4?sv=2012-02-12&sr=c&si=f6470998-511d-44e6-b526-a39461989ec0&sig=CvsE7Y5rHxJ8aBT3Py6K0oagFJVzxleqThHtRLl6LkA%3D&se=2017-09-24T09%3A45%3A37Z";
    public static String TOUR_NOT_SHOWN_AGAIN = "not_shown_again";
    public static String DOLLAR_SYMBOL_LABEL = "$";
    public static String FREE_COURSE_LABEL = "Free";
    public static String NOTIFICATION_UNREAD_TAG = "0";
    public static String MY_COURSE_MODEL = "my_course";

    public static int REQUEST_CODE_FOR_PAYMENT = 5;
    public static String ENCODED_CHARACTER_SET_NAME = "UTF-8";

    public static String AMPLITUDE_KEY = "c482d6778f4a81e642f1dfe371d4b1e3";
    public static String RUN_BEFORE_OVERLAY = "run_before_overlay";

    public static int PREVIEW_TEXT_SIZE = 13;

    public static String FIRST_NAME_ERROR_MESSAGE = "Should be between 1 to 30 characters long";
    public static String LAST_NAME_ERROR_MESSAGE = "Should be between 1 to 30 characters long";
    public static String EMAIL_ERROR_MESSAGE = "Enter a Valid Email Address";
    public static String PASSWORD_ERROR_MESSAGE = "Should be between 6 and 20 characters long";
    public static String PASSWORD_ERROR_MESSAGE_FOR_LOGIN = "Should be between 4 and 20 characters long";

    public static String ALERT_TITLE_MESSAGE = "Alert";
    public static String ALERT_MESSAGE = "Do you want to remove this course?";

    public static String OUTPUT_X= "outputX";
    public static String OUTPUT_Y= "outputY";
    public static String ASPECT_X= "aspectX";
    public static String ASPECT_Y= "aspectY";
    public static String SCALE = "scale";
    public static String CHOOSE_CROPING_APP = "Choose Croping App";
    public static final int PENDING_REMOVAL_TIMEOUT = 60000;
    public static final String MARKET_PLACE_URL =  "https://play.google.com/store/apps/details?id=";
    public static String CERTIFICATES_URL="certificates_url";
    public static String TOTAL_APP_LAUNCH="app_launch_count";
    public static String RATE_IT_NOW="RATE IT NOW";
    public static String RATE_NO_THANKS="NO, THANKS";
    public static String RATE_REMIND_ME_LATER="REMIND ME LATER";
    public static String PLAY_STORE_URL="http://play.google.com/store/apps/details?id=";
    public static String IS_NEED_TO_SHOW_RATING_POPUP="is_need_to_show_rating_popup";
    public static int RATE_MAX_COUNT=5;

    public static String []COLOR_HEX_CODE={"#ffa859","#fadcdc","#f4b8f2","#a1a566","#58c69f","#31bae7","#ff9a00","#cfff98"
    ,"#6f6d64","#b01919","#008080","#2a2a2a"};
}
