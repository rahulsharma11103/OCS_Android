package com.wagmob.golearningbus.model;



public class AppSettingModelSetting {
    public String setting_id;
    public String application_name;
    public String description;
    public String logo;
    public String logo_url;
    public String banner;
    public String banner_url;
    public String theme_id;
    public String signup_allowed;
    public String google_signin;
    public String facebook_signin;
    public String linkedin_signin;
    public String color_primary_hex;
    public String color_secondary_hex;
    public String policy;
    public String deeplink;
    public String email_id;
    public String app_price;
}
