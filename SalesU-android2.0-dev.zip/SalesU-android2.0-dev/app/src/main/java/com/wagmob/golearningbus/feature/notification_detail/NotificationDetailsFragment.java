package com.wagmob.golearningbus.feature.notification_detail;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.notification.NotificationReadEvent;
import com.wagmob.golearningbus.model.NotificationModelInfo;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.requestModel.NotificationUpdateRequest;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONException;
import org.json.JSONObject;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

/**
 * Fragment for notification details
 *
 * @author Rahul Sharma.
 */

public class NotificationDetailsFragment extends LoadDataFragment {
    static Context mContext;
    static NotificationModelInfo mNotificationModelInfo;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.notification_details_data)
    AppCompatTextView mNotificationDataView;
    @BindView(R.id.notification_web_view)
    WebView mTutorialWebView;

    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.web_service_for_update_notification_status)
    String mUpdateNotificationStatusServiceUrl;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.empty_field_message)
    String mEmptyMessage;
    @BindString(R.string.quiz_html_type)
    String mNotificationTypeHtml;


    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    Gson mGson;
    @Inject
    EventBus mEventBus;

    private Unbinder mUnbinder;
    private String mParamName, mSlugUrl, mMethodType;
    private boolean isAccessTokenExpire;


    /**
     * To initialize and return current fragment instance
     *
     * @param context
     * @return current fragment instance
     */
    public static NotificationDetailsFragment newInstance(Context context, NotificationModelInfo notificationModelInfo) {
        mNotificationModelInfo = notificationModelInfo;
        mContext = context;
        return new NotificationDetailsFragment();
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.notification_details_fragment, container, false);
        mUnbinder = ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(mContext!=null) {
            initializeComponent();
            if (mNotificationModelInfo != null && mNotificationModelInfo.notification_type != null) {
                if (mNotificationModelInfo.notification_type.equalsIgnoreCase(mNotificationTypeHtml)) {
                    if (mNotificationModelInfo != null && mNotificationModelInfo.data != null) {
                        setupWebView(mNotificationModelInfo.data);
                    }
                } else {
                    updateNotificationStatus();
                    setNotificationData();
                }
            }
        }
    }

    private void setNotificationData() {
        mTutorialWebView.setVisibility(View.GONE);
        if (mNotificationModelInfo != null && mNotificationModelInfo.data != null) {
            mNotificationDataView.setText(mNotificationModelInfo.data);
        } else {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        if (mContext != null) {
            ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
        }
    }


    private void updateNotificationStatus() {

        NotificationUpdateRequest notificationUpdateRequest = new NotificationUpdateRequest();

        if (mNotificationModelInfo != null && mNotificationModelInfo.relation_id != null) {

            notificationUpdateRequest.relation_id = Integer.parseInt(mNotificationModelInfo.relation_id);

            String paramName = mGson.toJson(notificationUpdateRequest);
            callUpdateNotificationService(paramName, mUpdateNotificationStatusServiceUrl, SalesUConstants.POST_METHOD_TYPE);
        } else {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        }


    }


    private void setupWebView(String webUrl) {
        mTutorialWebView.getSettings().setJavaScriptEnabled(true);
        mTutorialWebView.getSettings().setBuiltInZoomControls(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mTutorialWebView.getSettings().setMixedContentMode(mTutorialWebView.getSettings().MIXED_CONTENT_ALWAYS_ALLOW);
        }
        showLoading();
        mTutorialWebView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                //  view.loadUrl(url);
                return true;
            }

            public void onPageFinished(WebView view, String url) {
                hideLoading();
                updateNotificationStatus();
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {

                Toast.makeText(mContext, "Oh no! " + description, Toast.LENGTH_SHORT).show();
                hideLoading();

            }
        });

        mTutorialWebView.loadUrl(webUrl);

    }

    /**
     * call Update Notification web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callUpdateNotificationService(String paramName, String path, String methodType) {
        mParamName = paramName;
        mSlugUrl = path;
        mMethodType = methodType;
        new UpdateNotificationStatusService().execute();
    }

    /**
     * Response of Tutorial webservice
     *
     * @param response response of web service
     *//*
    public void changePasswordWebServiceResponse(String response) {

        hideLoading();

        try {
            ChangePasswordModel changePasswordModel = mGson.fromJson(response, ChangePasswordModel.class);
            if (changePasswordModel != null && changePasswordModel.message != null) {

                Toast.makeText(mContext, changePasswordModel.message[0], Toast.LENGTH_SHORT).show();

            } else {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ex) {
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }


    }*/


    /**
     * unbind butter knife
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }

    /**
     * To Call Async Web Service
     */
    class UpdateNotificationStatusService extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new UpdateNotificationStatusService().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new UpdateNotificationStatusService().execute();
                    } else {
                        // changePasswordWebServiceResponse(s);
                        mEventBus.post(new NotificationReadEvent());
                    }
                } else {
                    hideLoading();
                    if (SalesUConstants.ISLogVisible) {
                        Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                    }
                }
            } catch (JSONException e) {
                hideLoading();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }
    }
}
