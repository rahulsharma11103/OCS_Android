package com.wagmob.golearningbus.model;


import java.util.List;

public class MyCourses {
    public List<MyCoursesItem> subscriptions;
}
