package com.wagmob.golearningbus.model;


public class GetUserProfileData {
    public UserProfile profile;
}
