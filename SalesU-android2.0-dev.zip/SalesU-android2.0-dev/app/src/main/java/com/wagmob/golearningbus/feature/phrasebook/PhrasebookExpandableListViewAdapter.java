package com.wagmob.golearningbus.feature.phrasebook;

import android.content.Context;
import android.media.MediaPlayer;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.model.FlashCardModelLetters;
import com.wagmob.golearningbus.model.PhraseBookExpandableModelLetters;

import java.util.ArrayList;
import java.util.List;


public class PhrasebookExpandableListViewAdapter extends RecyclerView.Adapter<PhrasebookExpandableViewHolder> {


    private Context mContext;

    private List<PhraseBookExpandableModelLetters> mPhraseBookExpandableModelLetters;

    List<FlashCardModelLetters> mPhrasebookModelLetters;

    PhrasebookExpandableViewHolder mPhrasebookExpandableViewHolder;

    private final List<PhraseBookExpandableModelLetters> mTmpPhraseBookExpandableModelLetters = new ArrayList<>();

    int mCurrentFocusItem = -1;


    public PhrasebookExpandableListViewAdapter(Context context, List<PhraseBookExpandableModelLetters> phraseBookExpandableModelLetters) {
        mContext = context;
        mPhraseBookExpandableModelLetters = phraseBookExpandableModelLetters;
        if (phraseBookExpandableModelLetters != null && phraseBookExpandableModelLetters.size() > 0) {
            mTmpPhraseBookExpandableModelLetters.addAll(phraseBookExpandableModelLetters);
            mPhraseBookExpandableModelLetters.clear();
        }
    }

    public void collapse() {
        mPhraseBookExpandableModelLetters.clear();
        notifyDataSetChanged();
    }

    public void expand() {
        mPhraseBookExpandableModelLetters.addAll(mTmpPhraseBookExpandableModelLetters);
        notifyDataSetChanged();

    }

    @Override
    public PhrasebookExpandableViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.phrasebook_two_word_listview_layout, parent, false);
        mPhrasebookExpandableViewHolder = new PhrasebookExpandableViewHolder(view);
        return new PhrasebookExpandableViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final PhrasebookExpandableViewHolder holder, final int position) {

        final PhraseBookExpandableModelLetters phraseBookExpandableModelLetters = mPhraseBookExpandableModelLetters.get(position);

        holder.mWordMeaningView.setText(phraseBookExpandableModelLetters.meaning);
        holder.mWordPronunciationView.setText(phraseBookExpandableModelLetters.pronunciation);
        final String soundfile_url = phraseBookExpandableModelLetters.soundfile_url;
        mPhrasebookExpandableViewHolder.mSoundFileIconList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentFocusItem = position;
                notifyItemChanged(position);
                MediaPlayer mp = new MediaPlayer();
                try {
                    mp.setDataSource(soundfile_url);//Write your location here
                  /*  PhraseBookExpandableModelLetters flashCardModelLettersSoundUrl = mPhraseBookExpandableModelLetters.get(position);
                    mp.setDataSource(flashCardModelLettersSoundUrl.soundfile_url);//Write your location here*/
                    mp.prepare();
                    mp.start();
                    mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mp) {
                            mCurrentFocusItem = -1;
                            notifyDataSetChanged();
                        }
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        if (mCurrentFocusItem == position) {
            mPhrasebookExpandableViewHolder.mSoundFileIconList.setImageDrawable(mPhrasebookExpandableViewHolder.mSoundIconBlue);
        } else {
            mPhrasebookExpandableViewHolder.mSoundFileIconList.setImageDrawable(mPhrasebookExpandableViewHolder.mSoundIcon);
        }
    }

    @Override
    public int getItemCount() {
        return mPhraseBookExpandableModelLetters != null ? mPhraseBookExpandableModelLetters.size() : 0;
    }
}
