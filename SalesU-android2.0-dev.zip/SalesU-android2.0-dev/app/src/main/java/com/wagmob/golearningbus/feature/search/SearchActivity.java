package com.wagmob.golearningbus.feature.search;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.google.android.gms.ads.AdView;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.util.JavaUtil;
import com.wagmob.golearningbus.view.BaseActivity;

import javax.inject.Inject;

import butterknife.BindColor;
import butterknife.BindDimen;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Activity for search
 *
 * @author Rahul Sharma
 */

public class SearchActivity extends BaseActivity implements SearchFragment.SearchListener {

    public interface SearchActivityListener {

        void onMenuInitialized(SearchView mSearchView);

        boolean onBackPressed();

        void doSearch(String query);

    }

    @BindColor(R.color.white)
    public int mColorWhite;
    @BindDimen(R.dimen.tab46_margin)
    public int mSearchViewAutoCompleteMaxSize;
    @BindView(R.id.toolbar)
    Toolbar mToolBar;
    Context mContext;
    @BindString(R.string.search_label_search)
    String mSearchLabel;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    SalesUApplication mGlobalApp;

    private Unbinder mUnBinder;
    private SearchView mSearchView;
    private SearchActivityListener mSearchActivityListener;
    private SearchFragment mSearchFragment;
    private String mQueryString;


    /**
     * @param context current activity context
     * @return intent of activity
     */
    public static Intent callingIntent(Context context) {
        return new Intent(context, SearchActivity.class);
    }

    @Override
    public void setSearchActivityListener(SearchActivityListener searchActivityListener) {
        mSearchActivityListener = searchActivityListener;
    }

    /**
     * Use to initialize layout and App bar
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_common);
        mUnBinder = ButterKnife.bind(this);
        initializeComponent();
        setSupportActionBar(mToolBar);
       // mQueryString=getIntent().getStringExtra(SalesUConstants.SEARCH_QUERY_STRING);
        ActionBar actionBar = getSupportActionBar();
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.color_primary_hex != null) {
            actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex)));
        }
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);
        AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_SEARCH_TAPPED);
        initializeFragment();
    }

    /**
     * initializing dagger components
     */
    private void initializeComponent() {
        ((SalesUApplication) this.getApplication()).getApplicationModule().inject(this);
    }

    /**
     * Add fragment to activity
     */
    private void initializeFragment() {
        mSearchFragment = SearchFragment.newInstance(mContext);
        addFragment(R.id.fragment_common_container, mSearchFragment);
    }

    /**
     * unbind butter knife object
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mUnBinder.unbind();
    }

    /**
     * menu option selection
     *
     * @param item
     * @return menu item
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home: {
                finish();
                overridePendingTransition(R.anim.activity_transition_stay_still, R.anim.activity_transition_out);
                break;

            }

        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.search_menu, menu);
        mSearchView = (SearchView) menu.findItem(R.id.search).getActionView();
        // mSearchView.setMaxWidth(mSearchViewAutoCompleteMaxSize);
        SearchView.SearchAutoComplete searchAutoComplete = (SearchView.SearchAutoComplete) mSearchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
        searchAutoComplete.setHintTextColor(mColorWhite);
        mSearchView.setQueryHint(mSearchLabel);
        mSearchView.setMaxWidth(Integer.MAX_VALUE);
        
        if (validateActivityListener()) {
            mSearchActivityListener.onMenuInitialized(mSearchView);
          /*  if(mQueryString!=null)
            mSearchActivityListener.doSearch(mQueryString);*/
        }
        // hide other menu item when SearchView is open or expanded
        mSearchView.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getSupportActionBar() != null) {
                    getSupportActionBar().setDisplayShowTitleEnabled(false);
                }
            }
        });

        // show other menu item when SearchView close
        mSearchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                // re-show the action button
                if (getSupportActionBar() != null) {
                    getSupportActionBar().setDisplayShowTitleEnabled(true);
                }
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    private boolean validateActivityListener() {
        return mSearchActivityListener != null;
    }


}
