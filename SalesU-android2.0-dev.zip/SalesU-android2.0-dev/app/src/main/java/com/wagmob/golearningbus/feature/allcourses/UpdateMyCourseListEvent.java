package com.wagmob.golearningbus.feature.allcourses;

/**
 * For checking course is subscribe or not
 */
public class UpdateMyCourseListEvent {

    public boolean mIsCourseSubscribe;

    public UpdateMyCourseListEvent(boolean isCourseSubscribe) {
        mIsCourseSubscribe = isCourseSubscribe;
    }

    public boolean getCourseSubscribeUpdate() {
        return mIsCourseSubscribe;
    }
}
