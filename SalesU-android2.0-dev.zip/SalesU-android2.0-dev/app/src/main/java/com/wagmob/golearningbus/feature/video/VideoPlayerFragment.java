package com.wagmob.golearningbus.feature.video;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.VideoView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.assignments.UpdateProgressForSectionEvent;
import com.wagmob.golearningbus.feature.edit_user_profile.EditProfileEvent;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.VideoPlayerAssignmentVimeo;
import com.wagmob.golearningbus.model.VideoPlayerModel;
import com.wagmob.golearningbus.model.requestModel.AssignmentRequest;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

/**
 * Fragment for  showing Video
 *
 * @author Rahul Sharma
 */
public class VideoPlayerFragment extends LoadDataFragment {

    String mAssignmentId;
    Context mContext;
    MediaController mMediaController;
    @BindView(R.id.video_player_view)
    VideoView mVideoView;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.adView)
    AdView mAdView;
    @BindString(R.string.quiz_time_up_message)
    String mTimeUpMessage;
    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.web_service_to_get_quiz)
    String quizServiceUrl;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.web_service_set_assignment_progress)
    String mWebServiceURlForSetAssignmentProgress;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @BindString(R.string.video_type_azure)
    String mVideoTypeAzure;
    @BindString(R.string.video_type_vimeo)
    String mVideoTypeVimeo;


    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    Gson mGson;
    @Inject
    EventBus mEventBus;
    VideoPlayerFragment mVideoPlayerFragment;
    ViewPager mPager;
    private Unbinder mUnbinder;
    private Uri mVideoUri;
    private boolean isVideoPause;
    private String mParamName, mSlugUrl, mMethodType;
    private boolean isAccessTokenExpire;
    private boolean isSetProgress;
    private boolean mIsFirstTabVideo;

    /**
     * To initialize and return current fragment instance
     *
     * @param context
     * @param assignmentid
     * @return current fragment instance
     */
    public VideoPlayerFragment newInstance(Context context, String assignmentid, boolean isFirstTabVideo, ViewPager viewPager) {
        mVideoPlayerFragment = new VideoPlayerFragment();
        mVideoPlayerFragment.mAssignmentId = assignmentid;
        mVideoPlayerFragment.mContext = context;
        mVideoPlayerFragment.mIsFirstTabVideo = isFirstTabVideo;
        mVideoPlayerFragment.mPager = viewPager;
        return mVideoPlayerFragment;
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.video_player, container, false);
        mUnbinder = ButterKnife.bind(this, view);
        return view;
    }

    /**
     * Load UI and Video player
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {

        super.onActivityCreated(savedInstanceState);
        initializeComponent();
        if (mGlobalApp != null) {
            boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
            if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                AdRequest adRequest = new AdRequest.Builder().build();
                mAdView.loadAd(adRequest);
            } else {
                mAdView.setVisibility(View.GONE);
            }
            loadVideo();
        }
        // setupVideoPlayer();
    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        if (mContext != null)
            ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    /**
     * setup video player
     */
    private void setupVideoPlayer(String videoUrl) {
        showLoading();
        try {
            mMediaController = new MediaController(mContext);
            mVideoUri = Uri.parse(videoUrl);
            mVideoView.setMediaController(mMediaController);
            mVideoView.setVideoURI(mVideoUri);
            mVideoView.requestFocus();
            mVideoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    hideLoading();
                }
            });
            mVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    setProgress();
                }
            });
            if (mIsFirstTabVideo) {
                mIsFirstTabVideo = false;
                mVideoView.start();
            }
        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(e.getMessage());
            }
        }

    }

 /*   *//**
     * resume video
     *//*
    @Override
    public void onResume() {

        super.onResume();
        if (isVideoPause) {
            mVideoView.seekTo(mGlobalApp.videoCurrentTIme);
            mVideoView.resume();
        } else {
            mVideoView.start();
        }

    }

    */

    /**
     * pause video
     *//*
    @Override
    public void onPause() {
        isVideoPause = true;
        mGlobalApp.videoCurrentTIme = mVideoView.getCurrentPosition();
        mVideoView.pause();
        super.onPause();
    }
*/
    /*@Override
    public void onStop() {
        super.onStop();
        try {
            mVideoView.pause();
        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                e.printStackTrace();
            }
        }

    }*/
    @Override
    public void onPause() {
        super.onPause();
        if (mVideoView != null) {
            mVideoView.pause();
        }
    }

    /**
     * To call Video web service
     */
    private void loadVideo() {
        showLoading();
        callVideoDataService("na", quizServiceUrl + "?assignment_id=" + mAssignmentId, SalesUConstants.GET_METHOD_TYPE);
    }

    private void setProgress() {
        isSetProgress = true;
        if (mGlobalApp.isNetworkAvailable()) {
            AssignmentRequest assignmentRequest = new AssignmentRequest();
            assignmentRequest.assignment_id = mAssignmentId;
            String paramName = mGson.toJson(assignmentRequest);
            callVideoDataService(paramName, mWebServiceURlForSetAssignmentProgress, SalesUConstants.POST_METHOD_TYPE);
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * call Video web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callVideoDataService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new VideoService().execute();
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Response of Video webservice
     *
     * @param response response of web service
     */
    public void videoWebServiceResponse(String response) {

        hideLoading();
        try {


            VideoPlayerModel videoPlayerModel = mGson.fromJson(response, VideoPlayerModel.class);
            if (videoPlayerModel != null && videoPlayerModel.data.assignment != null) {
                mGlobalApp.videoModelAssignment = videoPlayerModel.data.assignment;
                if (mGlobalApp.videoModelAssignment.video_type.equalsIgnoreCase(mVideoTypeAzure)) {
                    if (mGlobalApp.videoModelAssignment.video_url != null)
                        setupVideoPlayer(mGlobalApp.videoModelAssignment.video_url);
                } else if (mGlobalApp.videoModelAssignment.video_type.equalsIgnoreCase(mVideoTypeVimeo)) {
                    VideoPlayerAssignmentVimeo videoPlayerAssignmentVimeo = mGlobalApp.videoModelAssignment.vimeo_urls;
                    setupVideoPlayer(videoPlayerAssignmentVimeo.Sdvimeourl);
                }
            } else {
                //   Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            // Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            Timber.e(e.getMessage());
        }
    }

    /**
     * unbind butter knife
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            if (mAdView != null && mSharedPreference != null) {
                boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

                if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                    AdRequest adRequest = new AdRequest.Builder().build();
                    mAdView.loadAd(adRequest);
                } else {
                    mAdView.setVisibility(View.GONE);
                }
            }
            if (mVideoView != null) {
                mVideoView.start();
            }
        } else {
            if (mVideoView != null) {
                mVideoView.pause();
            }
        }
    }

    /**
     * To Call Async Web Service
     */
    class VideoService extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new VideoService().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new VideoService().execute();
                    } else {
                        if (!isSetProgress) {
                            videoWebServiceResponse(s);
                        } else {
                            mEventBus.post(new EditProfileEvent(true));
                            mEventBus.post(new UpdateProgressForSectionEvent(true));
                            if (mPager != null) {
                                mPager.setCurrentItem(mPager.getCurrentItem() + 1);
                            }
                        }
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                //    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }
    }
}
