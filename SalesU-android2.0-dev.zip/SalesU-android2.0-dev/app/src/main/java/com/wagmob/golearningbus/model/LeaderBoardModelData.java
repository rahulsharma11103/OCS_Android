package com.wagmob.golearningbus.model;


import java.util.List;

public class LeaderBoardModelData {
  public List<LeaderBoardModeUserInfo> leaderboard;
}
