package com.wagmob.golearningbus.feature.sections;

import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.RelativeLayout;

import com.wagmob.golearningbus.R;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * To bind item in butter knife
 *
 * @author Rahul sharma
 */
public class SubSectionsViewHolder extends RecyclerView.ViewHolder {

    @BindString(R.string.sub_section_preview)
    String mSubSectionPreview;

    @BindString(R.string.subsection_free)
    String mSubFree;

    @BindView(R.id.subsection_item_name)
    public AppCompatTextView mSubsectionItemName;

    @BindView(R.id.subsection_separator)
    View mSubSectionSeparator;

    @BindView(R.id.subsection_number)
    AppCompatTextView mNumberCountView;

    @BindView(R.id.subsection_item_layout)
    RelativeLayout mSubsectionLayout;

    @BindView(R.id.sub_line_separator_layout)
    RelativeLayout mSeparatorLayout;

    @BindView(R.id.progress_number)
    AppCompatTextView mTotalProgressNumberView;

    @BindView(R.id.lock_image)
    AppCompatImageView mLockImageView;

    public SubSectionsViewHolder(View viewItem) {
        super(viewItem);
        ButterKnife.bind(this, itemView);
    }


}
