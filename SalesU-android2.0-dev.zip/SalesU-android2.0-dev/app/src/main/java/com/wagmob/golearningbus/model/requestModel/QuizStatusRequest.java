package com.wagmob.golearningbus.model.requestModel;



public class QuizStatusRequest {
    public String assignment_id;
    public int percentage;
}
