package com.wagmob.golearningbus.feature.home;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;

import javax.inject.Inject;

/**
 * Home page Fragment for showing My Course,All Category and video role play in tab view
 *
 * @author Rahul Sharma
 */
public class HomeFragmentTab extends Fragment {

    LayoutInflater mInflater;
    View mView;

    TabLayout tabLayout;
    ViewPager viewPager;

    @Inject
    SalesUApplication mGlobalApp;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mInflater = inflater;

        mView = inflater.inflate(R.layout.home_fragment, container, false);


        return mView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initializeComponent();
        setupUI();
    }

    /**
     * Initialize Dagger Component
     */
    private void initializeComponent() {
        ((SalesUApplication) getActivity().getApplication()).getApplicationModule().inject(this);
    }

    private void setupUI() {
        viewPager = (ViewPager) mView.findViewById(R.id.view_pager);
        tabLayout = (TabLayout) mView.findViewById(R.id.tab_layout);
        tabLayout.setBackgroundColor(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex));
        tabLayout.setSelectedTabIndicatorColor(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_secondary_hex));
        // setupDataResource();

        HomeFragmentAdapter homeFragmentAdapter = new HomeFragmentAdapter(getFragmentManager(), getActivity());
        viewPager.setAdapter(homeFragmentAdapter);
        viewPager.setOffscreenPageLimit(1);
        tabLayout.setupWithViewPager(viewPager);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
    }


}
