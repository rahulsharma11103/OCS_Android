package com.wagmob.golearningbus.feature.quizreportcard;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.AssignmentItems;
import com.wagmob.golearningbus.util.JavaUtil;
import com.wagmob.golearningbus.view.BaseActivity;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * @author Rahul Sharma
 *         Activty  For showing Quiz Result
 */

public class QuizReportCardActivity extends BaseActivity {

    @BindView(R.id.toolbar)
    Toolbar mToolBar;

    @Inject
    SalesUApplication mGlobalApp;
    @BindString(R.string.interstitial_add_id)
    String mInterstitialId;
    @Inject
    SharedPreferences mSharedPreference;
    private InterstitialAd mInterstitialAd;
    boolean mIsAlreadyPurchase;


    Context mContext;
    private Unbinder mUnBinder;
    private QuizReportCardFragment mQuizReportCardFragment;
    private String mQuizPercentage;
    private String mAssignmentId;
    private List<AssignmentItems> mCollectionAssignmentItems;
    private int defaultTabPosition;

    /**
     * @param context current activity context
     * @return intent of activity
     */
    public static Intent callingIntent(Context context) {
        return new Intent(context, QuizReportCardActivity.class);
    }

    /**
     * Use to initialize layout and App bar
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_common);
        mUnBinder = ButterKnife.bind(this);
        initializeComponent();
        setSupportActionBar(mToolBar);
        ActionBar actionBar = getSupportActionBar();
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.color_primary_hex != null) {
            actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex)));
        }
        actionBar.setDisplayHomeAsUpEnabled(true);
        mAssignmentId = getIntent().getStringExtra(SalesUConstants.ASSIGNMENT_ID);
        mQuizPercentage = getIntent().getStringExtra(SalesUConstants.QUIZ_PERCENTAGE);
        mCollectionAssignmentItems = (ArrayList<AssignmentItems>) getIntent().getSerializableExtra(SalesUConstants.ASSIGNMENT_DETAILS);
        defaultTabPosition = getIntent().getIntExtra(SalesUConstants.ASSIGNMENT_DEFAULT_TAB, 0);
        if(mSharedPreference!=null) {
            mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

            if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                mInterstitialAd = new InterstitialAd(this);
                mInterstitialAd.setAdUnitId(mInterstitialId);
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
                mInterstitialAd.setAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();
                    }

                    @Override
                    public void onAdFailedToLoad(int i) {
                        super.onAdFailedToLoad(i);
                    }

                    @Override
                    public void onAdLeftApplication() {
                        super.onAdLeftApplication();
                    }

                    @Override
                    public void onAdOpened() {
                        super.onAdOpened();
                    }

                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                        mInterstitialAd.show();
                    }
                });
            }
        }
        initializeFragment();
    }

    /**
     * initializing dagger components
     */
    private void initializeComponent() {
        ((SalesUApplication) this.getApplication()).getApplicationModule().inject(this);
    }

    /**
     * Add fragment to activity
     */
    private void initializeFragment() {
        if (mAssignmentId != null && mQuizPercentage != null) {
            mQuizReportCardFragment = QuizReportCardFragment.newInstance(mContext, mAssignmentId, mQuizPercentage, mCollectionAssignmentItems, defaultTabPosition);
            addFragment(R.id.fragment_common_container, mQuizReportCardFragment);
        }
    }

    /**
     * unbind butter knife object
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mUnBinder.unbind();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.quiz_report_menu, menu);
        return true;
    }

    /**
     * menu option selection
     *
     * @param item
     * @return menu item
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home: {
                finish();
                overridePendingTransition(R.anim.activity_transition_stay_still, R.anim.activity_transition_out);
                break;
            }
            case R.id.close_report_card: {
                finish();
                overridePendingTransition(R.anim.activity_transition_stay_still, R.anim.activity_transition_out);
                break;
            }
        }

        return super.onOptionsItemSelected(item);
    }
}
