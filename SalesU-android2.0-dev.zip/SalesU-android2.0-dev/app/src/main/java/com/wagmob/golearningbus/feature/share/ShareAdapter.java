package com.wagmob.golearningbus.feature.share;


import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wagmob.golearningbus.R;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ShareAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context mContext;
    private List<ResolveInfo> mListApp;
    private PackageManager mPackageManager;
    private ShareAdapterInterface mShareAdapterInterface;

    public ShareAdapter(Context context, List<ResolveInfo> listApp) {
        this.mContext = context;
        this.mListApp = listApp;
        mPackageManager = mContext.getPackageManager();
    }

    /**
     * interface for share
     */
    public interface ShareAdapterInterface {
        void shareOptionSelectEvent(ResolveInfo appInfo);
    }

    public void setOnItemClickListener(ShareAdapterInterface shareAdapterInterface) {
        mShareAdapterInterface = shareAdapterInterface;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.share_app_layout, parent, false);
        viewHolder = new ShareAdapter.ShareAdapterViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ShareAdapterViewHolder quizAdapterViewHolder = (ShareAdapterViewHolder) holder;
        configureShareViewHolder(quizAdapterViewHolder, position);
    }

    private void configureShareViewHolder(ShareAdapterViewHolder quizAdapterViewHolder, final int position) {
        final ResolveInfo appInfo = mListApp.get(position);
        quizAdapterViewHolder.appCompatImageView.setImageDrawable(appInfo.loadIcon(mPackageManager));
        quizAdapterViewHolder.appCompatTextView.setText(appInfo.loadLabel(mPackageManager));
        quizAdapterViewHolder.appCompatTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mShareAdapterInterface.shareOptionSelectEvent(appInfo);
            }
        });
    }

    @Override
    public int getItemCount() {
        return (mListApp != null) ? mListApp.size() : 0;
    }

    static class ShareAdapterViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.share_logo)
        AppCompatImageView appCompatImageView;
        @BindView(R.id.app_name)
        AppCompatTextView appCompatTextView;

        public ShareAdapterViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
