package com.wagmob.golearningbus.feature.sections;


import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.wagmob.golearningbus.R;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * To bind item in butter knife
 *
 * @author Rahul sharma
 */
public class SectionsViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.section_title_name)
    public AppCompatTextView mVerticalName;

    @BindView(R.id.item_arrow)
    public AppCompatImageView mArrow;

    @BindView(R.id.subsection_item_list)
    public RecyclerView mContentItemRecyclerView;


    public SectionsViewHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
    }


}
