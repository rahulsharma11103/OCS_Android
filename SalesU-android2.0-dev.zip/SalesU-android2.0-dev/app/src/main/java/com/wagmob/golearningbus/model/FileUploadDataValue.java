package com.wagmob.golearningbus.model;

public class FileUploadDataValue {
    public String image_id;
    public String image_url;
}
