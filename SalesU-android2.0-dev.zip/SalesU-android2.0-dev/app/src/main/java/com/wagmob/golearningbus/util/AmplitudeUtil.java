package com.wagmob.golearningbus.util;

import com.amplitude.api.Amplitude;
import com.amplitude.api.Identify;
import com.amplitude.api.Revenue;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.UserDetails;

import org.json.JSONObject;

/**
 * Common class For Amplitude Event
 */

public class AmplitudeUtil {

    public static final String EVENT_USER_LOGOUT = "logout_tapped";
    public static final String EVENT_USER_SHARE = "share_tapped";
    public static final java.lang.String EVENT_SEARCH_TAPPED = "search_tapped";
    public static final String TAB_NAME = "tab_name";
    public static final String EVENT_TAB_SWITCH = "bottom_tab_changed";
    public static final String EVENT_USER_SIGNED_UP_SUCCESSFULLY = "user_signed_up";
    public static final String ID = "id";
    public static final String FIRST_NAME = "fname";
    public static final String LAST_NAME = "lname";
    public static final String SIGNED_IN = "signed_in";
    public static final String CATEGORY_NAME = "category_name";
    public static final java.lang.String EVENT_COURSE_TAPPED = "course_tapped";
    public static final String SUBSECTION_NAME = "subsection_name ";
    public static final String ASSIGNMENT_NAME = "assignment_name ";
    public static final java.lang.String EVENT_SUBSECTION_ITEM_TAPPED = "subsection_item_tapped";
    public static final String ASSIGNMENT_TYPE = "assignment_type";
    public static final String EVENT_PLAY_ASSIGNMENT = "play_assignment";
    public static String EVENT_LAUNCH_SUCCESSFULLY = "app_launched";
    public static String EVENT_SIGN_IN_SUCCESSFULLY = "user_signed_in";
    public static String EVENT_CATEGORY_TAP = "category_tapped";
    public static String COURSE_NAME = "course_name";
    public static String APPLICATION_NAME = "app_name";
    public static String IS_COURSE_FREE = "is_course_free";
    public static String FROM_SCREEN = "from_screen";
    public static String EVENT_COURSE_SUBSCRIBE_CLICK = "course_subscribe";
    public static String EVENT_COURSE_SUBSCRIBED_SUCCESSFULLY = "course_successfully_subscribed";
    public static String EVENT_NAME_FOR_APPLICATION_NAME = "app_name";
    public static String EVENT_NAME_SETTING_CLICKED = "settings_tapped";
    public static String EVENT_NAME_MY_ACHIEVEMENT_COURSE_CLICK = "my_achievement_course_tapped";
    public static String EVENT_NAME_SHARED_CERTIFICATE = "certificateShared";
    public static String EVENT_NAME_DOWNLOAD_CERTIFICATE = "download_certificate";
    public static String EVENT_NAME_FOR_PAYMENT_STATUS = "payment_status";
    public static String PAYMENT_ORDER_ID = "order_id";
    public static String PAYMENT_IS_DONE = "is_payment_done";


    public static void initialize() {
        Amplitude.getInstance().initialize(SalesUApplication.getApplication(), SalesUConstants.AMPLITUDE_KEY).enableForegroundTracking(SalesUApplication.getApplication());
    }

    public static void logAmplitudeEvent(String eventName) {
        Amplitude.getInstance().logEvent(eventName);
    }

    public static void logAmplitudeEvent(String eventName, JSONObject eventProperties) {
        Amplitude.getInstance().logEvent(eventName, eventProperties);
    }

    public static void logAmplitudeRevenue(String productId, int quantity, String amount) {
        /*Revenue revenue = new Revenue().setProductId(productId).setQuantity(quantity);
        revenue.setPrice(Integer.parseInt(amount)).setReceipt(receiptId, receiptSignature);
        Amplitude.getInstance().logRevenueV2(revenue);*/
        Revenue revenue = new Revenue().setProductId(productId).setPrice(Double.parseDouble(amount)).setQuantity(quantity);
        Amplitude.getInstance().logRevenueV2(revenue);
    }

    public static void userLogIn(UserDetails user) {
        Identify identify = new Identify();

        identify.set(ID, user.user_id)
                .set(FIRST_NAME, user.first_name)
                .set(LAST_NAME, user.last_name)
                .set(SIGNED_IN, true);

        Amplitude.getInstance().identify(identify);
    }

    public static void userLogout() {
        Amplitude.getInstance().setUserId(null);
        Identify identify = new Identify();

        identify.unset(ID)
                .unset(FIRST_NAME)
                .unset(LAST_NAME)
                .unset(SIGNED_IN);

        Amplitude.getInstance().identify(identify);
    }


}
