package com.wagmob.golearningbus.model;


public class CheckPaymentStatusModel {
    public boolean error;
    public int response_code;
    public CheckPaymentStatusModelMessage message;
}
