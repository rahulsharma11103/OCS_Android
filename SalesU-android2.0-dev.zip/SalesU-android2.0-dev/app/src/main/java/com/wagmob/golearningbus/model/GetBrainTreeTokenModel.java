package com.wagmob.golearningbus.model;


public class GetBrainTreeTokenModel {
    public boolean error;
    public int response_code;
    public String[] message;
    public GetBrainTreeTokenModelData data;
}
