package com.wagmob.golearningbus.model;


import java.io.Serializable;

public class NotificationModelInfo implements Serializable{
    public String relation_id;
    public String title;
    public String data;
    public String is_read;
    public String creation_date;
    public String notification_type;
}
