package com.wagmob.golearningbus.feature.sections;


import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.assignments.UpdateProgressForSectionEvent;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.Sections;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

/**
 * Fragment for  showing section list
 *
 * @author Rahul Sharma
 */
public class SectionsFragment extends LoadDataFragment {

    private static Context mContext;
    private static String mCourseId;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.section_list_item)
    RecyclerView mRecyclerView;
    @BindView(R.id.swipe_to_refresh)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @BindString(R.string.web_service_section)
    String mSectionWebServiceUrl;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @Inject
    Gson mGson;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    EventBus mEventBus;
    View view;
    private String mParamName, mSlugUrl, mMethodType;
    private int mNumberOfMore = 0;
    private Unbinder mUnBinder;
    private boolean isAccessTokenExpire, isGetMoreData;
    private SectionAdapter mSectionAdapter;
    private static boolean mIsDefaultScreen;


    public static SectionsFragment newInstance(Context context, String courseId, boolean isDefaultCourse) {
        mContext = context;
        mCourseId = courseId;
        mIsDefaultScreen = isDefaultCourse;
        return new SectionsFragment();
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.sections_fragment, null);
        mUnBinder = ButterKnife.bind(this, view);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadCategoriesList(0);
            }
        });
        return view;
    }

    /**
     * Load UI and call webService for section
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (mContext != null) {
            initializeComponent();
            setUpUi();
            loadCategoriesList(0);
        }
    }

    /**
     * Call WebService for load section
     *
     * @param offset
     */
    private void loadCategoriesList(int offset) {
        if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
            // mGlobalApp.sectionsItems = null;
        } else {
            showLoading();
        }
        callCategoryListWebService("na", mSectionWebServiceUrl + "?course_id=" + mCourseId, SalesUConstants.GET_METHOD_TYPE);
    }

    /**
     * setup UI and recycler Adapter
     */
    private void setUpUi() {


        // final List<SectionsItems> sectionsItems = Arrays.asList(mGlobalApp.sectionsItems.get(0),mGlobalApp.sectionsItems.get(1));
        try {
            if (mSharedPreference != null) {
                boolean isAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
                mSectionAdapter = new SectionAdapter(mContext, mGlobalApp.sectionsItems, isAlreadyPurchase, mIsDefaultScreen);
                //  mMyCourseAdapter.setOnItemClickListener(categoryAdapterListener);
                mRecyclerView.setAdapter(mSectionAdapter);
                mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
            }
        } catch (Exception ex) {

        }

    }

    /**
     * response of section web service
     *
     * @param response response of section web service
     */
    public void categoryWebServiceResponse(String response) {
        if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
            mSwipeRefreshLayout.setRefreshing(false);
        }
        hideLoading();
        boolean isLoadMore = false;
        try {
            Sections section = mGson.fromJson(response, Sections.class);
            mGlobalApp.sectionsItems = section.data.sections;
            boolean isAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
            mSectionAdapter.setSectionCollection(mGlobalApp.sectionsItems, isAlreadyPurchase);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        }

    /*    mMyCourseAdapter.setCategoryCollection(mGlobalApp.myCoursesItem, isLoadMore);*/

    }

    /**
     * To initialize Dagger component
     */
    private void initializeComponent() {
        if (mContext != null)
            ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    /**
     * Call section web service
     *
     * @param paramName  parameter name
     * @param path       webservice path
     * @param methodType method type
     */
    public void callCategoryListWebService(String paramName, String path, String methodType) {
        if (mGlobalApp != null) {
            if (mGlobalApp.isNetworkAvailable()) {
                mParamName = paramName;
                mSlugUrl = path;
                mMethodType = methodType;
                new GetCategoryListItem().execute();
            } else {
                if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                    mSwipeRefreshLayout.setRefreshing(false);
                }
                hideLoading();
                Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * unBind butter knife
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnBinder.unbind();
        if (mEventBus != null) {
            mEventBus.unregister(this);
        }
    }


    public void onEvent(UpdateProgressForSectionEvent updateProgressForSectionEvent) {
        if (updateProgressForSectionEvent.isUpdateProgress) {
            loadCategoriesList(0);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if (mEventBus != null && !mEventBus.isRegistered(this)) {
            mEventBus.register(this);
        }
    }

    /**
     * Call Section webservice
     */
    class GetCategoryListItem extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new GetCategoryListItem().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new GetCategoryListItem().execute();
                    } else {
                        categoryWebServiceResponse(s);
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }
    }
}
