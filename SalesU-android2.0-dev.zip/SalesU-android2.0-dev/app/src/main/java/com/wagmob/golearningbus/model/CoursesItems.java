package com.wagmob.golearningbus.model;


public class CoursesItems {
    public String course_id;
    public String title;
    public String description;
    public String image_url;
    public String category_id;
    public String duration;
    public String is_paid;
    public String price;
    public String currency;
    public String subscription_id;
    public String course_rating;
    public String is_default;
}
