package com.wagmob.golearningbus.model;


public class PaidPromotionalImageModel {
    public String androidphone_url;
    public String androidtablet_url;
}
