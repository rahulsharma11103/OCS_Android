package com.wagmob.golearningbus.feature.phrasebook;

import android.graphics.drawable.Drawable;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.wagmob.golearningbus.R;

import butterknife.BindDrawable;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by anjali on 12/20/2017.
 */

public class PhrasebookExpandableViewHolder extends RecyclerView.ViewHolder{


    @BindView(R.id.word_meaning_view)
    public AppCompatTextView mWordMeaningView;

    @BindView(R.id.word_pronunciation_view)
    public AppCompatTextView mWordPronunciationView;


    @BindView(R.id.sound_icon_list)
    public AppCompatImageView mSoundFileIconList;

    @BindDrawable(R.drawable.sound_flashcard)
    public Drawable mSoundIcon;

    @BindDrawable(R.drawable.sound_flashcard_blue)
    public Drawable mSoundIconBlue;

    public PhrasebookExpandableViewHolder(View items) {
        super(items);
        ButterKnife.bind(this, items);
    }
}
