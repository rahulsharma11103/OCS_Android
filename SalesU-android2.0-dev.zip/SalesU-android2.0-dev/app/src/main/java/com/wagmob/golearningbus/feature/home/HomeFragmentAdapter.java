package com.wagmob.golearningbus.feature.home;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.feature.allcategories.AllCategoriesFragment;
import com.wagmob.golearningbus.feature.mycourses.MyCoursesFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * Adapter for  Home Page
 */
public class HomeFragmentAdapter extends FragmentPagerAdapter {


    List<String> tabTittle;
    private Context mContext;

    public HomeFragmentAdapter(FragmentManager fm, Context context) {
        super(fm);
        mContext = context;
        tabTittle = new ArrayList<>();
        tabTittle.add(context.getString(R.string.all_courses));
        tabTittle.add(context.getString(R.string.my_course));
        // tabTittle.add(context.getString(R.string.video_role_play));
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0: {
                return AllCategoriesFragment.newInstance(mContext);
            }
            case 1: {
                return MyCoursesFragment.newInstance(mContext);
            }
            /*case 2: {
                return new VideoRolePlayFragment();
            }*/

        }
        return null;
    }

    @Override
    public int getCount() {
        return tabTittle.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return tabTittle.get(position);
    }
}
