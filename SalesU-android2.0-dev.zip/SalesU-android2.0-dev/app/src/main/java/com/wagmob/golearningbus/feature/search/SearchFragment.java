package com.wagmob.golearningbus.feature.search;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.allcourses.CoursesAdapter;
import com.wagmob.golearningbus.feature.allcourses.UpdateMyCourseListEvent;
import com.wagmob.golearningbus.model.AllCourses;
import com.wagmob.golearningbus.model.CoursesItems;
import com.wagmob.golearningbus.model.CoursesSubscription;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.requestModel.CoursesSubscriptionRequest;
import com.wagmob.golearningbus.model.requestModel.PaymentSubscriptionRequestModel;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

public class SearchFragment extends LoadDataFragment {

    private static Context mContext;
    private static String mCategoryId;
    private static View view;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.courses_list)
    RecyclerView mRecyclerView;
    @BindView(R.id.no_course_view)
    AppCompatTextView mNoCourseView;
    @BindView(R.id.adView)
    AdView mAdView;
    @BindString(R.string.web_service_for_search)
    String mSearchWebServiceUrl;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.web_service_subscribe_courses)
    String mSubscribeSlugUrl;
    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.courses_successfully_subscribed)
    String mCourseSuccessfullySubscribed;
    @BindString(R.string.dialogLoadingTitle)
    String mProgressDialogTitle;
    @BindString(R.string.dialogLoadingMessage)
    String mProgressDialogMessage;
    @BindString(R.string.web_service_for_get_brain_tree_token)
    String mGetBrainTreeTokenUrl;
    @BindString(R.string.something__went_wrong)
    String mSomethingWentWrong;
    @BindString(R.string.payment_canceled_message)
    String mPaymentCanceled;
    @BindString(R.string.submit_button_text)
    String mPaymentSubmitButtonMessage;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @Inject
    Gson mGson;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    EventBus mEventBus;
    boolean isSuccessfullPaymentService;
    CoursesItems mCourseItem;
    CoursesAdapter.CategoryViewHolder mCategoryViewHolder;
    List<CoursesItems> mCategoriesCollection;
    String mDefaultSubscriptionId = "10";
    ProgressDialog mProgressDialog;
    private String mParamName, mSlugUrl, mMethodType;
    private int mNumberOfMore = 0;
    private boolean isAccessTokenExpire, isGetMoreData;
    private CoursesAdapter mCoursesAdapter;
    private boolean mIsCourseSubscribe;
    private String mQuery;
    private boolean isAlreadyQuerySearchRunning;
    private String mAllCharacters;
    private boolean mIsGuestLogin;

    /*
     * Listener for All Courses
     */
    private CoursesAdapter.CategoryAdapterInterface categoryAdapterListener = new CoursesAdapter.CategoryAdapterInterface() {

        @Override
        public void getMoreCategory(int offset) {
            isGetMoreData = true;
            loadCategoriesList(offset);
        }

        @Override
        public void subscribeClick(CoursesItems categoriesItem, CoursesAdapter.CategoryViewHolder categoryViewHolder) {
            mCourseItem = categoriesItem;
            mCategoryViewHolder = categoryViewHolder;
            CoursesSubscriptionRequest coursesSubscriptionRequest = new CoursesSubscriptionRequest();
            coursesSubscriptionRequest.course_id = mCourseItem.course_id;
            String coursesJson = mGson.toJson(coursesSubscriptionRequest);
            callSubjectSubscriptionWebService(coursesJson, mSubscribeSlugUrl, SalesUConstants.POST_METHOD_TYPE);
        }


    };
    private Unbinder mUnBinder;
    private SearchView mSearchView;
    public SearchActivity.SearchActivityListener mSearchActivityListener = new SearchActivity.SearchActivityListener() {

        @Override
        public void onMenuInitialized(SearchView searchView) {
            mSearchView = searchView;
            setSearchViewOnQueryTextListener(mSearchView);
            mSearchView.setIconified(false);
        }

        @Override
        public boolean onBackPressed() {
            return onBackButtonPressed();
        }

        @Override
        public void doSearch(String query) {
            performSearch(query);

        }

    };
    private SearchListener mSearchListener;

    /**
     * @param context Activity reference
     * @return instance of AllCoursesFragment
     */
    public static SearchFragment newInstance(Context context) {
        mContext = context;
        return new SearchFragment();
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.search_fragment_layout, container, false);
        if (getActivity() instanceof SearchListener) {
            mSearchListener = (SearchListener) getActivity();
        }
        mUnBinder = ButterKnife.bind(this, view);
        mSearchListener.setSearchActivityListener(mSearchActivityListener);
        return view;
    }

    /**
     * Load UI and call webService for all courses
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(mContext!=null) {
            initializeComponent();
            setupProgressDialog();
            setUpUi();
            setUpBannerImage();
        }
    }

    private void setUpBannerImage() {
        if (mSharedPreference != null) {
            boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

            if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                AdRequest adRequest = new AdRequest.Builder().build();
                mAdView.loadAd(adRequest);
            } else {
                mAdView.setVisibility(View.GONE);
            }
        }
    }

    private void setupProgressDialog() {
        mProgressDialog = new ProgressDialog(mContext);
        mProgressDialog.setTitle(mProgressDialogTitle);
        mProgressDialog.setMessage(mProgressDialogMessage);
        mProgressDialog.setCancelable(false);
    }

    /**
     * setup UI and recycler Adapter
     */
    private void setUpUi() {
        mIsGuestLogin=mSharedPreference.getBoolean(SalesUConstants.SHARED_IS_GUEST_USER,false);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mCoursesAdapter = new CoursesAdapter(mContext, new ArrayList<CoursesItems>(), mRecyclerView, mGlobalApp,mIsGuestLogin);
        mCoursesAdapter.setOnItemClickListener(categoryAdapterListener);
        mRecyclerView.setAdapter(mCoursesAdapter);
    }

    /**
     * Initialize Dagger
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    public void setSearchViewOnQueryTextListener(SearchView searchView) {
        try {
            if (searchView != null) {
                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        onQueryTextSubmitListener(query);
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        onQueryTextChangeListener(newText);
                        return false;
                    }
                });
            }
        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e("Exception Caught ==>> " + e.getMessage());
            }
        }
    }

    public void onQueryTextSubmitListener(String query) {
        mQuery = query;
        if (mQuery != null && !mQuery.isEmpty() && !isAlreadyQuerySearchRunning) {
            isAlreadyQuerySearchRunning = true;
            mGlobalApp.coursesItem = null;
            loadCategoriesList(0);
        }

        mSearchView.clearFocus();
    }

    public void onQueryTextChangeListener(String query) {
        mQuery = query;
        if (mQuery != null && !mQuery.isEmpty()) {
            //   isAlreadyQuerySearchRunning = true;
            mGlobalApp.coursesItem = null;
            loadCategoriesList(0);
        }else {
            mRecyclerView.setVisibility(View.GONE);
            mNoCourseView.setVisibility(View.VISIBLE);
        }

    }

    public void performSearch(String query) {
        if (mSearchView != null) {
            mSearchView.setQuery(query, true);
        }
    }

    public boolean onBackButtonPressed() {
        if (mSearchView != null) {
            if (!mSearchView.isIconified()) {
                mSearchView.onActionViewCollapsed();
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    /**
     * Call WebService for load all Courses
     *
     * @param offset
     */
    private void loadCategoriesList(int offset) {
        showLoading();
        try {
            callCategoryListWebService("na", mSearchWebServiceUrl + "?offset=" + offset + "&limit=" + SalesUConstants.REQUEST_MAX_LIMIT_DATA + "&query=" + URLEncoder.encode(mQuery, SalesUConstants.ENCODED_CHARACTER_SET_NAME), SalesUConstants.GET_METHOD_TYPE);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    /**
     * Call subject  Subscription Web Service
     *
     * @param courseId
     * @param mSubscribeSlugUrl
     * @param postMethodType
     */
    private void callSubjectSubscriptionWebService(String courseId, String mSubscribeSlugUrl, String postMethodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mProgressDialog.show();
            mSlugUrl = mSubscribeSlugUrl;
            mParamName = courseId;
            mMethodType = postMethodType;
            new CourseSubscriptionService().execute();
        } else {
            isSuccessfullPaymentService = false;
            hideLoading();
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * response of all courses web service
     *
     * @param response
     */
    public void categoryWebServiceResponse(String response) {

        hideLoading();
        boolean isLoadMore = false;
        AllCourses allCourses = mGson.fromJson(response, AllCourses.class);
        //   isAlreadyQuerySearchRunning = false;
        if (allCourses != null && allCourses.data != null && allCourses.data.courses != null && (allCourses.data.courses.size() > 0 || isGetMoreData)) {

            mNoCourseView.setVisibility(View.GONE);
            mRecyclerView.setVisibility(View.VISIBLE);
            if (mGlobalApp.coursesItem == null) {
                mGlobalApp.coursesItem = allCourses.data.courses;
            } else {
                isLoadMore = true;
                isGetMoreData = false;
                mGlobalApp.coursesItem.addAll(allCourses.data.courses);
            }
            mCategoriesCollection = removeDuplicatesItems(mGlobalApp.coursesItem);
            mCoursesAdapter.setCategoryCollection(mCategoriesCollection, isLoadMore);
        } else {
            if (!isGetMoreData) {
                mRecyclerView.setVisibility(View.GONE);
                mNoCourseView.setVisibility(View.VISIBLE);
            }
        }


    }

    private List<CoursesItems> removeDuplicatesItems(List<CoursesItems> coursesItems) {
        List<CoursesItems> result = new ArrayList<CoursesItems>();
        Set<String> titles = new HashSet<String>();

        for (CoursesItems item : coursesItems) {
            if (titles.add(item.title)) {
                result.add(item);
            }
        }
        return result;
    }

    /**
     * call All Courses Web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callCategoryListWebService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new GetCategoryListItem().execute();
        } else {
            isSuccessfullPaymentService = false;
            hideLoading();
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * @param courseResponse
     */
    private void coursesSubscriptionResponse(String courseResponse) {
        mProgressDialog.dismiss();
        try {
            CoursesSubscription coursesSubscription = mGson.fromJson(courseResponse, CoursesSubscription.class);
            mIsCourseSubscribe = true;
            if (coursesSubscription != null) {
                courseSuccessfullyubSubscribeOrNot(true);
            } else {
                courseSuccessfullyubSubscribeOrNot(false);
            }

        } catch (Exception ex) {
            Toast.makeText(mContext, mSomethingWentWrong, Toast.LENGTH_SHORT).show();
        }
    }

    public void courseSuccessfullyubSubscribeOrNot(boolean isCourseSubscribe) {
        if (mCategoryViewHolder != null && mCourseItem != null) {
            if (isCourseSubscribe) {
                mCategoryViewHolder.mSubscribe.setText(mCategoryViewHolder.mSubscribedLabel);
                mCategoryViewHolder.mSubscribe.setBackgroundColor(mCategoryViewHolder.mSubscribedButtonBackgroundColor);
                mCourseItem.subscription_id = mDefaultSubscriptionId;
                mCategoriesCollection.set(mCategoryViewHolder.getAdapterPosition(), mCourseItem);
                mRecyclerView.getAdapter().notifyItemChanged(mCategoryViewHolder.getAdapterPosition(), mCategoriesCollection);
                Toast.makeText(mContext, mCategoryViewHolder.mCourseSuccessfullySubscribed, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(mContext, mCategoryViewHolder.mSomethingWentWrong, Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(mContext, mCategoryViewHolder.mSomethingWentWrong, Toast.LENGTH_SHORT).show();
        }
    }


    private void callPaymentSubscriptionService(String paymentNonce, String courseId) {
        isSuccessfullPaymentService = true;
        PaymentSubscriptionRequestModel paymentSubscriptionRequestModel = new PaymentSubscriptionRequestModel();
        paymentSubscriptionRequestModel.course_id = courseId;
        paymentSubscriptionRequestModel.nonce = paymentNonce;
        String jsonForm = mGson.toJson(paymentSubscriptionRequestModel);
        callSubjectSubscriptionWebService(jsonForm, mGetBrainTreeTokenUrl, SalesUConstants.POST_METHOD_TYPE);
    }

    /**
     * Post a Event Bus
     */
    @Override
    public void onPause() {
        super.onPause();
        mEventBus.post(new UpdateMyCourseListEvent(mIsCourseSubscribe));
    }

    /**
     * unBind Butter knife
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mGlobalApp.coursesItem = null;
        mUnBinder.unbind();
    }

    /**
     * Interface for listening Search events.
     */
    public interface SearchListener {
        void setSearchActivityListener(SearchActivity.SearchActivityListener searchActivityListener);
    }

    /**
     * All Courses Web service
     */
    class GetCategoryListItem extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new GetCategoryListItem().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new GetCategoryListItem().execute();
                    } else {
                        categoryWebServiceResponse(s);
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                Toast.makeText(mContext, mSomethingWentWrong, Toast.LENGTH_SHORT).show();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.getMessage());
            }

        }
    }

    /**
     * Course Subscription Web Service
     */
    class CourseSubscriptionService extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new CourseSubscriptionService().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new CourseSubscriptionService().execute();
                    } else {
                        if (isSuccessfullPaymentService) {
                            isSuccessfullPaymentService = false;
                            coursesSubscriptionResponse(s);
                        } else {
                            coursesSubscriptionResponse(s);
                        }
                    }
                } else {
                    isSuccessfullPaymentService = false;
                    mProgressDialog.dismiss();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                isSuccessfullPaymentService = false;
                mProgressDialog.dismiss();
                Toast.makeText(mContext, mSomethingWentWrong, Toast.LENGTH_SHORT).show();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.getMessage());
            }
        }
    }


}
