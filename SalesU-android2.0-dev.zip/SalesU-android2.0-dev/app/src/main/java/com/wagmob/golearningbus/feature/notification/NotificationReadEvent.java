package com.wagmob.golearningbus.feature.notification;

/**
 * Created by rahul sharma.
 */

public class NotificationReadEvent {

}
