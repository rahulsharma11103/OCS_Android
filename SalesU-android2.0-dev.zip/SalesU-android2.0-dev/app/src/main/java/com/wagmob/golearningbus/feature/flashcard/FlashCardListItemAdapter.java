package com.wagmob.golearningbus.feature.flashcard;

import android.content.Context;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.RelativeLayout;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.model.FlashCardModelLetters;
import com.wagmob.golearningbus.util.ImageUtil;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Rahul on 8/25/2017.
 */

public class FlashCardListItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context mContext;
    List<FlashCardModelLetters> mFlashCardModelLetters;
    FlashCardAssignmentView mFlashCardAssignmentView;
    FlashCardListItemAdapterInterface mFlashCardListItemAdapterInterfaceListner;
    int mRowIndex = -1;

    public FlashCardListItemAdapter(Context context, List<FlashCardModelLetters> flashCardModelLetters) {
        mContext = context;
        mFlashCardModelLetters = flashCardModelLetters;
    }


    public void initialteInterfaceListner(FlashCardListItemAdapterInterface flashCardListItemAdapterInterface) {
        mFlashCardListItemAdapterInterfaceListner = flashCardListItemAdapterInterface;
    }

    /**
     * Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.
     * This new ViewHolder should be constructed with a new View that can represent the items of the given type.
     * You can either create a new View manually or inflate it from an XML layout file.
     *
     * @param parent
     * @param viewType
     * @return Recycler view holder
     */
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder mRecyclerView;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.flash_card_items_list, parent, false);
        mRecyclerView = new FlashCardAssignmentView(view);
        return mRecyclerView;
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     * This method should update the contents of the itemView to reflect the item at the given position.
     *
     * @param holder   Recycler view holder
     * @param position position of current item
     */
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        mFlashCardAssignmentView = (FlashCardAssignmentView) holder;
        if (mFlashCardModelLetters != null && mFlashCardModelLetters.get(position).character_sideimage_url != null) {
            ImageUtil.getInstance().loadImage(mContext, mFlashCardModelLetters.get(position).character_sideimage_url, mFlashCardAssignmentView.mFlashItemView,R.drawable.placeholder_default_rectangular, false,true);
        }
        mFlashCardAssignmentView.mListCardItems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mFlashCardListItemAdapterInterfaceListner != null) {
                   setBorderColorInItems(position);
                    mFlashCardListItemAdapterInterfaceListner.cardItemClick(position);
                }

            }
        });
        if (mRowIndex == position) {
            mFlashCardAssignmentView.mListCardItems.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.card_corner_color));
        } else {
            mFlashCardAssignmentView.mListCardItems.setBackgroundColor(mContext.getResources().getColor(R.color.white));
        }
    }

    /**
     * To set FlashCard list
     *
     * @param flashCardModelLetters assignment list item
     */
    public void setFlashCardItems(List<FlashCardModelLetters> flashCardModelLetters) {
        mFlashCardModelLetters = flashCardModelLetters;
        notifyDataSetChanged();
    }

    public void setBorderColorInItems(int position)
    {
        mRowIndex = position;
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    /**
     * Returns the total number of items in the data set held by the adapter.
     *
     * @return The total number of items in this adapter.
     */
    @Override
    public int getItemCount() {
        return mFlashCardModelLetters != null ? mFlashCardModelLetters.size() : 0;
    }

    public interface FlashCardListItemAdapterInterface {
        public void cardItemClick(int cardPosition);
    }

    static class FlashCardAssignmentView extends RecyclerView.ViewHolder {
        @BindView(R.id.flash_items_image)
        AppCompatImageView mFlashItemView;

        @BindView(R.id.list_card_items)
        RelativeLayout mListCardItems;

        public FlashCardAssignmentView(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
