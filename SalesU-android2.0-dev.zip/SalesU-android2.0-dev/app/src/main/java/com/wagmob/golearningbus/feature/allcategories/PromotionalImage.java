package com.wagmob.golearningbus.feature.allcategories;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatImageView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.util.ImageUtil;
import com.wagmob.golearningbus.view.BaseFragment;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by wagmob on 8/1/2017.
 */

public class PromotionalImage extends BaseFragment {
    private static Context mContext;
    public PromotionalImage mPromotionalImage;
    @BindView(R.id.tour_image)
    AppCompatImageView mTourImageView;
    @Inject
    SalesUApplication mGlobalApp;
    private Unbinder mUnBinder;
    private String mImageUrl;

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.image_tour_fragment, container, false);
        mUnBinder = ButterKnife.bind(this, view);
        mContext = getContext();
        initializeComponent();
        return view;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setUpImageUrl();
    }

    public void setImageUrl(String imageUrl) {
        mImageUrl = imageUrl;
    }


    private void setUpImageUrl() {
        if (mImageUrl != null) {
            ImageUtil.getInstance().loadImage(mContext, mImageUrl, mTourImageView, R.drawable.slider_deafult_image, false, true);
        }
    }

    /*
     * initialize dagger component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }
}
