package com.wagmob.golearningbus.feature.signup;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.AppSettingModelSetting;
import com.wagmob.golearningbus.model.SignUpUser;
import com.wagmob.golearningbus.model.UserInfo;
import com.wagmob.golearningbus.model.requestModel.SignInRequest;
import com.wagmob.golearningbus.model.requestModel.SignUpRequest;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import javax.inject.Inject;

import butterknife.BindColor;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import timber.log.Timber;

/**
 * Fragment for sign up
 *
 * @author Rahul Sharma
 */
public class SignUpFragment extends LoadDataFragment {


    private static Context mContext;
    @BindView(R.id.sign_up_first_name)
    AutoCompleteTextView mFirstName;
    @BindView(R.id.sign_up_last_name)
    AutoCompleteTextView mLastName;
    @BindView(R.id.sign_up_email)
    AutoCompleteTextView mEmail;
    @BindView(R.id.sign_up_password)
    AutoCompleteTextView mPassword;
    @BindView(R.id.sales_logo_image)
    AppCompatTextView mSaleUIconView;
    @BindString(R.string.empty_field_message)
    String mEmptyMessage;
    @BindString(R.string.something__went_wrong)
    String mSomethingWentWrong;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.sign_up_submit)
    AppCompatButton mSignUpButtonView;
    @BindView(R.id.terms_and_condition)
    AppCompatTextView mTermsAndConditionView;
    @BindView(R.id.sign_up_all_ready_account)
    AppCompatTextView mAlreadySignUpView;
    @BindColor(R.color.white)
    int mWhiteColor;
    @Inject
    Gson mGson;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    private Unbinder mUnBinder;
    private SignUpFragmentInterface mSignUpFragmentInterface;

    public static SignUpFragment newInstance(Context ctx) {
        mContext = ctx;
        return new SignUpFragment();
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View signUpView = inflater.inflate(R.layout.sign_up_fragment, container, false);
        mUnBinder = ButterKnife.bind(this, signUpView);
        setRetainInstance(true);
        mSignUpFragmentInterface = (SignUpFragmentInterface) getActivity();
        return signUpView;
    }

    /**
     * Load UI
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(mContext!=null) {
            initializeComponent();
            setupUI();
        }
    }

    private void setupUI() {

        Drawable mFirstNameDrawable = mFirstName.getBackground();
        if (mFirstNameDrawable != null && mWhiteColor != 0) {
            mFirstNameDrawable.setColorFilter(mWhiteColor, PorterDuff.Mode.SRC_ATOP);
            mFirstName.setBackgroundDrawable(mFirstNameDrawable);
        }

        Drawable mLastNameDrawable = mLastName.getBackground();
        if (mLastNameDrawable != null && mWhiteColor != 0) {
            mLastNameDrawable.setColorFilter(mWhiteColor, PorterDuff.Mode.SRC_ATOP);
            mLastName.setBackgroundDrawable(mLastNameDrawable);
        }

        Drawable emailDrawable = mEmail.getBackground();
        if (emailDrawable != null && mWhiteColor != 0) {
            emailDrawable.setColorFilter(mWhiteColor, PorterDuff.Mode.SRC_ATOP);
            mEmail.setBackgroundDrawable(emailDrawable);
        }

        Drawable passwordDrawable = mPassword.getBackground();
        if (passwordDrawable != null && mWhiteColor != 0) {
            passwordDrawable.setColorFilter(mWhiteColor, PorterDuff.Mode.SRC_ATOP);
            mPassword.setBackgroundDrawable(passwordDrawable);
        }
        //mFirstName.getBackground().mutate().setColorFilter(mWhiteColor, PorterDuff.Mode.SRC_ATOP);
        //mLastName.getBackground().mutate().setColorFilter(mWhiteColor, PorterDuff.Mode.SRC_ATOP);
        //mEmail.getBackground().mutate().setColorFilter(mWhiteColor, PorterDuff.Mode.SRC_ATOP);
        //mPassword.getBackground().mutate().setColorFilter(mWhiteColor, PorterDuff.Mode.SRC_ATOP);
       /* String messageForTermsAndPolicy = "<font color=#FFFFFF>By signing up, you agree to our </font> <font color=#000000>Terms of Use</font>" +
                "<font color=#FFFFFF> and </font><font color=#000000>Privacy Policy</font>";
        String messageForSignUp = "<font color=#FFFFFF>Already have an account  ? </font><font color=#000000>Sign in</font>";
        mTermsAndConditionView.setText(Html.fromHtml(messageForTermsAndPolicy), TextView.BufferType.SPANNABLE);
        mAlreadySignUpView.setText(Html.fromHtml(messageForSignUp), TextView.BufferType.SPANNABLE);*/
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null) {
           /* Drawable signInBackground = mSignUpButtonView.getBackground();
            ((GradientDrawable) signInBackground).setColorFilter(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex), PorterDuff.Mode.SRC_ATOP);*/
            AppSettingModelSetting appSetting = mGlobalApp.appSettingModel.data.settings;
            mSaleUIconView.setText(appSetting.application_name);
        }
    }

    /**
     * initialize Dagger Component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    /**
     * navigate to sign in page when already have account
     */
    @OnClick(R.id.sign_up_all_ready_account)
    public void allReadyAccount() {
        new BaseNavigator().navigateToLoginActivity(mContext);
    }

    /**
     * call web service when sign up button clicked
     */
    @OnClick(R.id.sign_up_submit)
    public void signUpSubmit() {
        if (mFirstName.getText().toString() == null || mFirstName.getText().toString().isEmpty() || mFirstName.length() < 1) {
            mFirstName.setError(SalesUConstants.FIRST_NAME_ERROR_MESSAGE);
        } else if (mLastName.getText().toString() == null || mLastName.getText().toString().isEmpty() || mLastName.length() < 1) {
            mLastName.setError(SalesUConstants.LAST_NAME_ERROR_MESSAGE);
        } else if (mEmail.getText().toString() == null || mEmail.getText().toString().isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(mEmail.getText().toString()).matches()) {
            mEmail.setError(SalesUConstants.EMAIL_ERROR_MESSAGE);
        } else if (mPassword.getText().toString() == null || mPassword.getText().toString().isEmpty() || mPassword.length() < 6) {
            mPassword.setError(SalesUConstants.PASSWORD_ERROR_MESSAGE);
        } else {
            callSignUpWebService();
        }

    }

    @OnClick(R.id.terms_and_condition)
    public void termsAndConditionLabel() {
        String url = mGlobalApp.appSettingModel.data.settings.policy;
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }

    /**
     * call sign up web service
     */
    private void callSignUpWebService() {
        showLoading();
        SignUpRequest signUpModel = new SignUpRequest();
        signUpModel.first_name = mFirstName.getText().toString();
        signUpModel.last_name = mLastName.getText().toString();
        signUpModel.email_id = mEmail.getText().toString();
        signUpModel.password = mPassword.getText().toString();
        String paramNameString = mGson.toJson(signUpModel);
        String loginUrlPath = mContext.getString(R.string.web_service_sign_up_by_saleu);
        mSignUpFragmentInterface.callWebService(paramNameString, loginUrlPath, SalesUConstants.POST_METHOD_TYPE, false);
    }

    /**
     * Call  web service for login
     */
    private void callLoginWebService() {
        try {
            showLoading();
            SignInRequest signInRequest = new SignInRequest();
            signInRequest.email_id = mEmail.getText().toString();
            ;
            signInRequest.password = mPassword.getText().toString();
            ;
            signInRequest.keep_login = String.valueOf(SalesUConstants.KEEP_LOGIN);
            String jobj = mGson.toJson(signInRequest);
            String loginUrlPath = mContext.getString(R.string.web_service_login_by_saleu);
            mSignUpFragmentInterface.callWebService(jobj, loginUrlPath, SalesUConstants.POST_METHOD_TYPE, true);
        } catch (Exception ex) {
            Timber.e(ex.toString());
        }
    }

    /**
     * sign up web service response
     *
     * @param response sign up web service response
     */
    public void asyncSignUpResponse(String response, boolean isLoginCall) {
        try {
            if (isLoginCall) {
                hideLoading();
                UserInfo userInfo = mGson.fromJson(response, UserInfo.class);
                if (userInfo.error) {
                    Toast.makeText(mContext, userInfo.message[0], Toast.LENGTH_SHORT).show();
                } else {
                    mGlobalApp.userDetails = userInfo.data.user;
                    SharedPreferences.Editor editor = mSharedPreference.edit();
                    editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, mGlobalApp.userDetails.accesstoken);
                    editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, mGlobalApp.userDetails.refreshtoken);
                    editor.putString(SalesUConstants.USER_FIRST_NAME, mGlobalApp.userDetails.first_name);
                    editor.putString(SalesUConstants.USER_LAST_NAME, mGlobalApp.userDetails.last_name);
                    editor.putString(SalesUConstants.USER_IMAGE_URL, mGlobalApp.userDetails.image_url);
                    editor.putString(SalesUConstants.USER_ID, mGlobalApp.userDetails.user_id);
                    editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                    editor.putBoolean(SalesUConstants.SHARED_IS_GUEST_USER,false);
                    editor.commit();
                    AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_SIGN_IN_SUCCESSFULLY);
                    AmplitudeUtil.userLogIn(mGlobalApp.userDetails);
                    new BaseNavigator().navigateToHomeActivity(mContext);

                }
            } else {
                hideLoading();
                SignUpUser signUpUserModel = mGson.fromJson(response, SignUpUser.class);
                if (signUpUserModel.error) {
                    Toast.makeText(mContext, signUpUserModel.message[0], Toast.LENGTH_SHORT).show();
                } else {
                    AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_USER_SIGNED_UP_SUCCESSFULLY);
                    callLoginWebService();
               /* Toast.makeText(mContext, signUpUserModel.message[0], Toast.LENGTH_SHORT).show();
                new BaseNavigator().navigateToLoginActivity(mContext);*/
                }
            }
        } catch (Exception ex) {
            Toast.makeText(mContext, mSomethingWentWrong, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Unbind Butter knife
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnBinder.unbind();
    }

    public interface SignUpFragmentInterface {
        void callWebService(String paramName, String url, String methodType, boolean isLoginCall);
    }
}
