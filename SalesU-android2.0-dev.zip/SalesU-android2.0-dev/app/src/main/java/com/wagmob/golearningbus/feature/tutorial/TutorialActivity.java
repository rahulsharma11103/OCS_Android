/*
package com.wagmob.golearningbus.feature.tutorial;


import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.view.BaseActivity;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class TutorialActivity extends BaseActivity{
    @BindView(R.id.toolbar)
    Toolbar mToolBar;
    @Inject
    SalesUApplication mGlobalApp;

    Context mContext;
    private Unbinder mUnBinder;
    private TutorialFragment mTutorialFragment;
    private String mAssignmentId;

    */
/**
     * @param context current activity context
     * @return intent of activity
     *//*

    public static Intent callingIntent(Context context) {
        return new Intent(context, TutorialActivity.class);
    }

    */
/**
     * Use to initialize layout and App bar
     *
     * @param savedInstanceState
     *//*

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_common);
        mUnBinder = ButterKnife.bind(this);
        initializeComponent();
        setSupportActionBar(mToolBar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex)));
        actionBar.setDisplayHomeAsUpEnabled(true);
        mAssignmentId = getIntent().getStringExtra(SalesUConstants.ASSIGNMENT_ID);
        initializeFragment();
    }
    */
/**
     * initializing dagger components
     *//*

    private void initializeComponent() {
        ((SalesUApplication) this.getApplication()).getApplicationModule().inject(this);
    }
    */
/**
     * Add fragment to activity
     *//*

    private void initializeFragment() {
        mTutorialFragment =new  TutorialFragment().newInstance(mContext, mAssignmentId);
        addFragment(R.id.fragment_common_container, mTutorialFragment);
    }

    */
/**
     * unbind butter knife object
     *//*

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mUnBinder.unbind();
    }

    */
/**
     * menu option selection
     *
     * @param item
     * @return menu item
     *//*

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home: {
                finish();
                overridePendingTransition(R.anim.activity_transition_stay_still, R.anim.activity_transition_out);
                break;

            }
        }

        return super.onOptionsItemSelected(item);
    }
}
*/
