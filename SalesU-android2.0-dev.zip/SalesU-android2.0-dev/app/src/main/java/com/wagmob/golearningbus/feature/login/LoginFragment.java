package com.wagmob.golearningbus.feature.login;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatImageButton;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.Profile;
import com.facebook.ProfileTracker;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.Status;
import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.Tour.GuestTour;
import com.wagmob.golearningbus.model.AppSettingModelSetting;
import com.wagmob.golearningbus.model.FacebookResponseModel;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.UserInfo;
import com.wagmob.golearningbus.model.requestModel.SignInRequest;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.util.JavaUtil;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import java.util.Arrays;

import javax.inject.Inject;

import butterknife.BindColor;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import timber.log.Timber;

/**
 * Fragment for login
 *
 * @author Rahul Sharma
 */
public class LoginFragment extends LoadDataFragment {

    private static Context mContext;
    public String mGoogleEmailAddress;
    @Nullable
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.email)
    AppCompatEditText email;
    @BindView(R.id.password)
    AppCompatEditText password;
    @Nullable
    @BindView(R.id.sign_up_now)
    AppCompatTextView mSignUpView;
    @BindView(R.id.google_login)
    AppCompatImageButton mGoogleLoginView;
    @BindView(R.id.facebook_login_button)
    LoginButton mFacebookLogin;
    @BindView(R.id.link_in)
    AppCompatImageButton mLinkDinView;
    @BindView(R.id.sales_u_icon)
    AppCompatTextView mSaleUIconView;
    @BindView(R.id.login_view)
    RelativeLayout mLoginLayout;
    @BindView(R.id.sign_in_label_view)
    AppCompatTextView mSignInLabelView;
    @BindView(R.id.submit)
    AppCompatButton mLoginButtonView;
    @BindView(R.id.terms_and_condition)
    AppCompatTextView mTermsAndConditionView;
    @BindColor(R.color.white)
    int mWhiteColor;
    @BindString(R.string.terms_and_condition_message)
    String mTermsAndConditionMessage;
    @BindString(R.string.empty_field_message)
    String mEmptyMessage;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.google_client_id)
    String mGoogleLoginClientToken;
    @BindString(R.string.email_address)
    String mEmailAddress;
    @BindString(R.string.email_us_feedback_for)
    String mEmailFeedbackFor;
    @BindString(R.string.app_name)
    String mAppName;
    @BindString(R.string.email_us_application_android)
    String mApplicationOnAndroid;
    @Inject
    Gson mGson;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @BindString(R.string.web_service_for_google_sign_in)
    String mGoogleSignInServiceUrl;
    @BindString(R.string.web_service_for_facebook_sign_in)
    String mFacebookSignInServiceUrl;
    @BindString(R.string.something__went_wrong)
    String mSomethingWentWrong;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.deafaultPictureUrl)
    String mDefaultPictureUrl;
    @BindString(R.string.dialogLoadingTitle)
    String mProgressDialogTitle;
    @BindString(R.string.dialogLoadingMessage)
    String mProgressDialogMessage;
    @BindString(R.string.help_mail_subject)
    String mHelpSubject;
    String mGoogleLoginParamBodyString;
    String mFacebookLoginParamBodyString;
    String mNetworkMessage;
    LoginFragmentInterface mloginFragmentInterface;
    ProgressDialog mProgressDialog;
    Profile mFacebookProfile;
    GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener = new GoogleApiClient.OnConnectionFailedListener() {
        @Override
        public void onConnectionFailed(ConnectionResult connectionResult) {
            Toast.makeText(mContext, "User Cancel", Toast.LENGTH_SHORT).show();
        }
    };
    private Unbinder mUnBinder;
    private String mEmailId;
    private String mPassword;
    private int mNumberOfSignIN = 0;
    private int mTotalSignInOption = 3;
    private String mVersionName;
    private int mVersionCode;
    //Signing Options
    private GoogleSignInOptions gso;
    //google api client
    private GoogleApiClient mGoogleApiClient;
    private String mParamName, mSlugUrl, mMethodType;
    private boolean isAccessTokenExpire;
    //Signin constant to check the activity result
    private int RC_SIGN_IN = 100;
    //For FacebookLogin
    private CallbackManager callbackManager;
    private AccessTokenTracker accessTokenTracker;
    private ProfileTracker mProfileTracker;
    private FacebookCallback<LoginResult> callback = new FacebookCallback<LoginResult>() {
        @Override
        public void onSuccess(LoginResult loginResult) {
            try {
                final AccessToken accessToken = loginResult.getAccessToken();
                String token = accessToken.getToken();
                mFacebookProfile = Profile.getCurrentProfile();
                if (mFacebookProfile == null) {
                    mProfileTracker = new ProfileTracker() {
                        @Override
                        protected void onCurrentProfileChanged(Profile oldProfile, Profile newProfile) {
                            //displayMessage(newProfile);
                            mFacebookProfile = newProfile;
                            mProfileTracker.stopTracking();
                        }
                    };
                    mProfileTracker.startTracking();
                }
                GraphRequest request = GraphRequest.newMeRequest(loginResult.getAccessToken(), new GraphRequest.GraphJSONObjectCallback() {

                    @Override
                    public void onCompleted(JSONObject object, GraphResponse response) {
                        // Get facebook data from login
                        if (object != null) {
                            FacebookResponseModel facebookResponseModel = mGson.fromJson(object.toString(), FacebookResponseModel.class);
                            facebookResponseModel.email_id = facebookResponseModel.email;
                            if (mFacebookProfile != null) {
                                facebookResponseModel.image_url = mFacebookProfile.getProfilePictureUri(300, 300).toString();
                            } else {
                                facebookResponseModel.image_url = mDefaultPictureUrl;
                            }
                            callFacebookLoginWebService(facebookResponseModel, accessToken.getToken());
                        }
                    }
                });
                Bundle parameters = new Bundle();
                parameters.putString("fields", "id, first_name, last_name, email,gender, birthday, location"); // Parámetros que pedimos a facebook
                request.setParameters(parameters);
                request.executeAsync();
                if (mProgressDialog != null) {
                    mProgressDialog.show();
                }
            } catch (Exception ex) {
                Toast.makeText(mContext, mSomethingWentWrong, Toast.LENGTH_SHORT).show();
                if (SalesUConstants.ISLogVisible) {
                    Timber.e(ex.getMessage());
                }
            }

        }

        @Override
        public void onCancel() {
            Toast.makeText(mContext, "User Cancel", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onError(FacebookException e) {
            Toast.makeText(mContext, "Facebook error", Toast.LENGTH_SHORT).show();
        }
    };

    /**
     * @param ctx Context of Activity
     * @return Current Class Instance
     */
    public static LoginFragment newInstance(Context ctx) {
        mContext = ctx;
        return new LoginFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initializeFacebookSignIn();
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View loginView = inflater.inflate(R.layout.login_fragment, container, false);
        mUnBinder = ButterKnife.bind(this, loginView);
        setRetainInstance(true);
        mloginFragmentInterface = (LoginFragmentInterface) getActivity();
        initializeGoogleSignIn();
        mFacebookLogin.setReadPermissions(Arrays.asList(
                "public_profile", "email", "user_birthday"));
        ;
        mFacebookLogin.setFragment(this);
        mFacebookLogin.registerCallback(callbackManager, callback);
        setupProgressDialog();
        return loginView;
    }

    private void setupProgressDialog() {
        mProgressDialog = new ProgressDialog(mContext);
        mProgressDialog.setTitle(mProgressDialogTitle);
        mProgressDialog.setMessage(mProgressDialogMessage);
        mProgressDialog.setCancelable(false);
    }

    private void initializeGoogleSignIn() {
        //Initializing google signin option
        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestScopes(new Scope(Scopes.PROFILE), new Scope(Scopes.EMAIL))
                .requestIdToken(mGoogleLoginClientToken)
                .build();
        //Initializing google api client
        try {
            mGoogleApiClient = new GoogleApiClient.Builder(mContext)
                    .enableAutoManage(getActivity(), onConnectionFailedListener)
                    .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                    .build();
        } catch (Exception ex) {
            Timber.d(ex.getMessage());
        }

    }

    private void initializeFacebookSignIn() {
        FacebookSdk.sdkInitialize(getActivity().getApplicationContext());

        callbackManager = CallbackManager.Factory.create();

        accessTokenTracker = new AccessTokenTracker() {
            @Override
            protected void onCurrentAccessTokenChanged(AccessToken oldToken, AccessToken newToken) {

            }
        };

        mProfileTracker = new ProfileTracker() {
            @Override
            protected void onCurrentProfileChanged(Profile oldProfile, Profile newProfile) {
                mFacebookProfile = newProfile;
                mProfileTracker.stopTracking();
            }
        };
        accessTokenTracker.startTracking();
        mProfileTracker.startTracking();
    }

    private void setUpUi() {
        Drawable emailDrawable = email.getBackground();
        if (emailDrawable != null && mWhiteColor != 0) {
            emailDrawable.setColorFilter(mWhiteColor, PorterDuff.Mode.SRC_ATOP);
            email.setBackgroundDrawable(emailDrawable);
        }
        Drawable passwordDrawable = password.getBackground();
        if (passwordDrawable != null && mWhiteColor != 0) {
            passwordDrawable.setColorFilter(mWhiteColor, PorterDuff.Mode.SRC_ATOP);
            password.setBackgroundDrawable(passwordDrawable);
        }
        /*String messageForTermsAndPolicy = "<font color=#FFFFFF>By signing up, you agree to our </font> <font color=#000000>Terms of Use</font>" +
                "<font color=#FFFFFF> and </font><font color=#000000>Privacy Policy</font>";
        String messageForSignUp = "<font color=#FFFFFF>Don't have an account ? </font><font color=#000000>Sign up</font>";
        mTermsAndConditionView.setText(Html.fromHtml(messageForTermsAndPolicy), TextView.BufferType.SPANNABLE);
        mSignUpView.setText(Html.fromHtml(messageForSignUp), TextView.BufferType.SPANNABLE);*/
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null) {
            /*Drawable signInBackground = mLoginButtonView.getBackground();
            ((GradientDrawable) signInBackground).setColorFilter(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex), PorterDuff.Mode.SRC_ATOP);*/
          /*  Drawable signUpBackground = mSignUpView.getBackground();
            ((GradientDrawable) signUpBackground).setStroke(2, Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex));*/
            AppSettingModelSetting appSetting = mGlobalApp.appSettingModel.data.settings;
            mSaleUIconView.setText(appSetting.application_name);
            if (!appSetting.signup_allowed.equalsIgnoreCase(SalesUConstants.TRUE_RESPONSE_BY_SERVICE)) {
                mSignUpView.setVisibility(View.GONE);
            }
            if (!appSetting.google_signin.equalsIgnoreCase(SalesUConstants.TRUE_RESPONSE_BY_SERVICE)) {
                mGoogleLoginView.setVisibility(View.GONE);
                ++mNumberOfSignIN;
            }
            if (!appSetting.facebook_signin.equalsIgnoreCase(SalesUConstants.TRUE_RESPONSE_BY_SERVICE)) {
                mFacebookLogin.setVisibility(View.GONE);
                ++mNumberOfSignIN;
            }
            if (!appSetting.linkedin_signin.equalsIgnoreCase(SalesUConstants.TRUE_RESPONSE_BY_SERVICE)) {
                mLinkDinView.setVisibility(View.GONE);
                ++mNumberOfSignIN;
            }

            if (mNumberOfSignIN == mTotalSignInOption) {
                mSignInLabelView.setVisibility(View.GONE);
            }
        }
    }

    @OnClick(R.id.google_login)
    public void googleLoginClick() {
        //Creating an intent
        if (mGoogleApiClient != null) {
            try {
                Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
                //Starting intent for result
                startActivityForResult(signInIntent, RC_SIGN_IN);
            } catch (Exception ex) {

            }

        }
    }

    @OnClick(R.id.sign_in_help_icon)
    public void getHelpSupport() {
        try {
            PackageInfo pInfo = mContext.getPackageManager().getPackageInfo(mContext.getPackageName(), 0);
            if (pInfo != null) {
                mVersionName = pInfo.versionName;
                mVersionCode = pInfo.versionCode;
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        String versionCode = android.os.Build.VERSION.RELEASE;
        String emailBody = "";
        if (mVersionName != null && mAppName != null) {
            emailBody = "Hi\n" + "\n App Name: " + mAppName + "\nMy Device Specification\nVersion Name: " + mVersionName + "\nVersion Code: " + mVersionCode + "\n"
                    + "OS Version: " + versionCode + "\nPhone Manufacture: " + JavaUtil.getDeviceName() + "\n";
        } else {

        }
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.email_id != null && mHelpSubject != null && emailBody != null) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("mailto:" + mGlobalApp.appSettingModel.data.settings.email_id));
            intent.putExtra(Intent.EXTRA_SUBJECT, mHelpSubject);
            intent.putExtra(Intent.EXTRA_TEXT, emailBody);
            try {
                startActivity(intent);
            } catch (Exception ex) {
                Toast.makeText(mContext, "There are no email applications installed.", Toast.LENGTH_SHORT).show();

            }

        }
    }

    //To generate hashKey for facebook
   /* public void printHashKey() {
        // Add code to print out the key hash
        try {
            PackageInfo info = mContext.getPackageManager().getPackageInfo(
                    "com.quizmine.gosalestrain",
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (PackageManager.NameNotFoundException e) {

        } catch (NoSuchAlgorithmException e) {

        }
    }*/

    private void signOut() {
        if (SalesUConstants.ISLogVisible) {
            Timber.d("called  signOut !");
            Timber.d("Google Signout");
        }
        if (mGoogleApiClient != null && mGoogleApiClient.isConnected()) {
            Auth.GoogleSignInApi.signOut(mGoogleApiClient).setResultCallback(
                    new ResultCallback<Status>() {
                        @Override
                        public void onResult(Status status) {
                            // [START_EXCLUDE]
                            // updateUI(false);
                            if (SalesUConstants.ISLogVisible) {
                                Timber.d("signOut:onResult: " + status);
                            }
                            // [END_EXCLUDE]
                        }
                    });
            mGoogleApiClient.stopAutoManage(getActivity());
            mGoogleApiClient.disconnect();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        try {
            signOut();
            LoginManager.getInstance().logOut();
            if (accessTokenTracker != null)
                accessTokenTracker.stopTracking();
            if (mProfileTracker != null)
                mProfileTracker.stopTracking();
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    /**
     * Load UI
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (mContext != null) {
            initializeComponent();
            setUpUi();
        }
    }

    /**
     * initialize Dagger Component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //If signin
        if (requestCode == RC_SIGN_IN) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            //Calling a new function to handle signin
            handleSignInResult(result);
        } else {
            callbackManager.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void handleSignInResult(GoogleSignInResult result) {
        if (result.isSuccess()) {
            //Getting google account
            GoogleSignInAccount acct = result.getSignInAccount();
            callGoogleLoginWebService(acct);

        } else {
            //Toast.makeText(mContext, "Login failed" + result.getStatus(), Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Sign up method call when sign up button pressed
     */
    @OnClick(R.id.sign_up_now)
    public void signUpPage() {
        new BaseNavigator().navigateToSignUp(mContext);
    }

    /**
     * navigato to forgot password
     */
    @OnClick(R.id.forgotPassword)
    public void forgotPassword() {
        new BaseNavigator().navigateToForgotPasswordScreen(mContext);
    }

    /**
     * this method call when login button click
     */
    @OnClick(R.id.submit)
    public void loginSubmit() {
        mEmailId = email.getText().toString();
        mPassword = password.getText().toString();
        if (mEmailId == null || mEmailId.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(mEmailId).matches()) {
            email.setError(SalesUConstants.EMAIL_ERROR_MESSAGE);
        } else if (mPassword == null || mPassword.isEmpty() || mPassword.length() < 4) {
            password.setError(SalesUConstants.PASSWORD_ERROR_MESSAGE_FOR_LOGIN);
        } else {
            callLoginWebService();
        }
    }

    /**
     * Call  web service for login
     */
    private void callLoginWebService() {
        try {
            if (mProgressDialog != null) {
                mProgressDialog.show();
            }
            SignInRequest signInRequest = new SignInRequest();
            signInRequest.email_id = mEmailId;
            signInRequest.password = mPassword;
            signInRequest.keep_login = String.valueOf(SalesUConstants.KEEP_LOGIN);
            String jobj = mGson.toJson(signInRequest);
            String loginUrlPath = mContext.getString(R.string.web_service_login_by_saleu);
            mloginFragmentInterface.callWebService(jobj, loginUrlPath, SalesUConstants.POST_METHOD_TYPE, null, null);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.toString());
            }
        }
    }

    private void callGoogleLoginWebService(GoogleSignInAccount accountInfo) {
        try {
            if (mProgressDialog != null) {
                mProgressDialog.show();
            }
            SignInRequest signInRequest = new SignInRequest();
            signInRequest.first_name = accountInfo.getGivenName();
            signInRequest.last_name = accountInfo.getFamilyName();
            signInRequest.email_id = accountInfo.getEmail();
            signInRequest.image_url = accountInfo.getPhotoUrl().toString();
            mGoogleEmailAddress = accountInfo.getEmail();
            mGoogleLoginParamBodyString = mGson.toJson(signInRequest);
            mloginFragmentInterface.callWebService(mGoogleLoginParamBodyString, mGoogleSignInServiceUrl, SalesUConstants.POST_METHOD_TYPE, accountInfo.getIdToken(), null);
        } catch (Exception ex) {
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.toString());
            }
        }
    }

    private void callFacebookLoginWebService(FacebookResponseModel facebookResponseModel, String accessToken) {
        try {

            if (mProgressDialog != null) {
                mProgressDialog.show();
            }
            mFacebookLoginParamBodyString = mGson.toJson(facebookResponseModel);
            mloginFragmentInterface.callWebService(mFacebookLoginParamBodyString, mFacebookSignInServiceUrl, SalesUConstants.POST_METHOD_TYPE, null, accessToken);
        } catch (Exception ex) {
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.toString());
            }
        }
    }

    /**
     * Login web service response
     *
     * @param response
     */
    public void asyncLoginResponse(String response) {

        try {
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            UserInfo userInfo = mGson.fromJson(response, UserInfo.class);
            if (userInfo.error) {
                Toast.makeText(mContext, userInfo.message[0], Toast.LENGTH_SHORT).show();
            } else {
                mGlobalApp.userDetails = userInfo.data.user;
                SharedPreferences.Editor editor = mSharedPreference.edit();
                editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, mGlobalApp.userDetails.accesstoken);
                editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, mGlobalApp.userDetails.refreshtoken);
                editor.putString(SalesUConstants.USER_FIRST_NAME, mGlobalApp.userDetails.first_name);
                editor.putString(SalesUConstants.USER_LAST_NAME, mGlobalApp.userDetails.last_name);
                editor.putString(SalesUConstants.USER_IMAGE_URL, mGlobalApp.userDetails.image_url);
                editor.putString(SalesUConstants.USER_ID, mGlobalApp.userDetails.user_id);
                editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                editor.putBoolean(SalesUConstants.SHARED_IS_GUEST_USER, false);
                editor.commit();
                AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_SIGN_IN_SUCCESSFULLY);
                AmplitudeUtil.userLogIn(mGlobalApp.userDetails);
                new BaseNavigator().navigateToHomeActivity(mContext);
            }
        } catch (Exception ex) {
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    @OnClick(R.id.terms_and_condition)
    public void termsAndConditionLabel() {
        String url = mGlobalApp.appSettingModel.data.settings.policy;
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }

    @OnClick(R.id.facebook_login)
    public void facebookLoginButton() {
        mFacebookLogin.performClick();
    }

    /**
     * Unbind Butter knife object
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        try {
            signOut();
            LoginManager.getInstance().logOut();
            if (accessTokenTracker != null)
                accessTokenTracker.stopTracking();
            if (mProfileTracker != null)
                mProfileTracker.stopTracking();
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
        mUnBinder.unbind();

    }

    /**
     * Interface for fragment
     */
    public interface LoginFragmentInterface {
        void callWebService(String paramName, String url, String methodType, String googleToken, String facebookLogin);
    }

    /////-----  Guest user functionally started -------/////

    /**
     * this method call when guest login button click
     */
    @OnClick(R.id.continue_as_guest)
    public void guestLoginClick() {
        callGuestLoginWebService();

    }

    /**
     * Call  web service for guest login
     */
    public void callGuestLoginWebService() {
        try {
            if (mProgressDialog != null) {
                mProgressDialog.show();
            }
            SignInRequest signInRequest = new SignInRequest();
            signInRequest.email_id = SalesUConstants.GUEST_EMAIL_ID;
            signInRequest.password = SalesUConstants.GUEST_PASSWORD;
            signInRequest.keep_login = String.valueOf(SalesUConstants.KEEP_LOGIN);
            String jobj = mGson.toJson(signInRequest);
            String loginUrlPath = mContext.getString(R.string.web_service_login_by_saleu);
            callguestLogin(jobj, loginUrlPath, SalesUConstants.POST_METHOD_TYPE);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.toString());
            }
        }
    }

    /**
     * call Guest Login Web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callguestLogin(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new CallLoginAsnc().execute();
        } else {
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * call Guest Login Web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callLogin(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new CallLoginAsnc().execute();
        } else {
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * calling of Guest Assignment Web service
     */
    class CallLoginAsnc extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new CallLoginAsnc().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new CallLoginAsnc().execute();
                    } else {
                        asyncGuestLoginResponse(s);
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.getMessage());
            }

        }
    }

    /**
     * Guest Login web service response
     *
     * @param response
     */
    public void asyncGuestLoginResponse(String response) {

        try {
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            UserInfo userInfo = mGson.fromJson(response, UserInfo.class);
            if (userInfo.error) {
                Toast.makeText(mContext, userInfo.message[0], Toast.LENGTH_SHORT).show();
            } else {
                mGlobalApp.userDetails = userInfo.data.user;
                SharedPreferences.Editor editor = mSharedPreference.edit();
                editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, mGlobalApp.userDetails.accesstoken);
                editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, mGlobalApp.userDetails.refreshtoken);
                editor.putString(SalesUConstants.USER_FIRST_NAME, mGlobalApp.userDetails.first_name);
                editor.putString(SalesUConstants.USER_LAST_NAME, mGlobalApp.userDetails.last_name);
                editor.putString(SalesUConstants.USER_IMAGE_URL, mGlobalApp.userDetails.image_url);
                editor.putString(SalesUConstants.USER_ID, mGlobalApp.userDetails.user_id);
                editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                editor.putBoolean(SalesUConstants.SHARED_IS_GUEST_USER,true);
                editor.commit();
                AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_SIGN_IN_SUCCESSFULLY);
                AmplitudeUtil.userLogIn(mGlobalApp.userDetails);
                new BaseNavigator().navigateToHomeActivity(mContext);
            }
        } catch (Exception ex) {
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

/////-----  Guest user functionally finished -------/////

}
