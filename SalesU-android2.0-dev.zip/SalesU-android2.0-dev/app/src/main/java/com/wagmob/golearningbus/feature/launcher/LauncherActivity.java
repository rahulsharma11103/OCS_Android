package com.wagmob.golearningbus.feature.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.view.BaseActivity;

import org.json.JSONObject;

import javax.inject.Inject;

import butterknife.BindString;
import timber.log.Timber;

/**
 * Activity for launcher
 *
 * @author Rahul Sharma
 */
public class LauncherActivity extends BaseActivity {

    Context mContext;

    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.web_service_for_change_user_password)
    String mChangePasswordServiceUrl;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;


    @Inject
    SalesUApplication mGlobalApp;

    @Inject
    SharedPreferences mSharedPreference;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.launcher);
        initializeInjector();
        initializeFragment();
    }

    /**
     * Add fragment to activity
     */
    private void initializeFragment() {
        LauncherFragment launcherFragment = LauncherFragment.newInstance(mContext);
        addFragment(R.id.fragment_common_container, launcherFragment);
    }

    private void initializeInjector() {
        ((SalesUApplication) getApplication()).getApplicationModule().inject(this);
    }




}
