package com.wagmob.golearningbus.feature.phrasebook;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.model.FlashCardModelLetters;

import java.util.List;

import butterknife.BindDrawable;
import butterknife.BindView;
import butterknife.ButterKnife;


public class PhrasebookCardViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


    List<FlashCardModelLetters> mPhrasebookModelLetters;

    PhrasebookItemDetailView mPhrasebookItemDetailView;

    PhrasebookListItemAdapterInterface mPhrasebookListItemAdapterInterface;

    Context mContext;

    int mCurrentFocusItem = -1;

    public PhrasebookCardViewAdapter(Context context, List<FlashCardModelLetters> mFlashCardModelLetters) {
        mContext = context;
        mPhrasebookModelLetters = mFlashCardModelLetters;
    }

    public void initialteInterfaceListner(PhrasebookListItemAdapterInterface phrasebookListItemAdapterInterface) {
        mPhrasebookListItemAdapterInterface = phrasebookListItemAdapterInterface;
    }

    /**
     * Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.
     * This new ViewHolder should be constructed with a new View that can represent the items of the given type.
     * You can either create a new View manually or inflate it from an XML layout file.
     *
     * @param parent
     * @param viewType
     * @return Recycler view holder
     */
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflate the layout,  initialize the view Holder
        RecyclerView.ViewHolder mRecyclerView;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.phrasebook_items_details_list, parent, false);
        mRecyclerView = new PhrasebookItemDetailView(view);
        return mRecyclerView;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {

        mPhrasebookItemDetailView = (PhrasebookItemDetailView) holder;

        final FlashCardModelLetters phraseBookModelLetters = mPhrasebookModelLetters.get(position);
        mPhrasebookItemDetailView.mWordNameView.setText(phraseBookModelLetters.word);
        mPhrasebookItemDetailView.mWordPronunciationView.setText(phraseBookModelLetters.pronunciation);
        mPhrasebookItemDetailView.mWordMeaningView.setText(phraseBookModelLetters.meaning);

        mPhrasebookItemDetailView.mSoundFileIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentFocusItem = position;
                notifyItemChanged(position);
                MediaPlayer mp = new MediaPlayer();
                try {
                    FlashCardModelLetters flashCardModelLettersSoundUrl = mPhrasebookModelLetters.get(position);
                    mp.setDataSource(flashCardModelLettersSoundUrl.soundfile_url);//Write your location here
                    mp.prepare();
                    mp.start();
                    mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mp) {
                            mCurrentFocusItem = -1;
                            notifyDataSetChanged();
                        }
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        if (mCurrentFocusItem == position) {
            mPhrasebookItemDetailView.mSoundFileIcon.setImageDrawable(mPhrasebookItemDetailView.mSoundIconBlue);
        } else {
            mPhrasebookItemDetailView.mSoundFileIcon.setImageDrawable(mPhrasebookItemDetailView.mSoundIcon);
        }
    }

    /**
     * To set FlashCard list
     *
     * @param flashCardModelLetters assignment list item
     */
    public void setFlashCardItems(List<FlashCardModelLetters> flashCardModelLetters) {
        mPhrasebookModelLetters = flashCardModelLetters;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return mPhrasebookModelLetters != null ? mPhrasebookModelLetters.size() : 0;
    }

    public interface PhrasebookListItemAdapterInterface {
        public void cardItemClick(int cardPosition);
    }


    public class PhrasebookItemDetailView extends RecyclerView.ViewHolder {

        @BindView(R.id.word_name_view)
        AppCompatTextView mWordNameView;

        @BindView(R.id.word_meaning_view)
        AppCompatTextView mWordMeaningView;

        @BindView(R.id.word_pronunciation_view)
        AppCompatTextView mWordPronunciationView;

        @BindView(R.id.word_name_separator)
        RelativeLayout mWordNameSeparatorLayout;

        @BindView(R.id.word_meaning_separator)
        RelativeLayout mWordMeaningSeparator;

        @BindView(R.id.sound_icon)
        AppCompatImageView mSoundFileIcon;

        @BindDrawable(R.drawable.sound_flashcard)
        Drawable mSoundIcon;

        @BindDrawable(R.drawable.sound_flashcard_blue)
        Drawable mSoundIconBlue;

        public PhrasebookItemDetailView(View items) {
            super(items);
            ButterKnife.bind(this, items);
        }
    }
}
