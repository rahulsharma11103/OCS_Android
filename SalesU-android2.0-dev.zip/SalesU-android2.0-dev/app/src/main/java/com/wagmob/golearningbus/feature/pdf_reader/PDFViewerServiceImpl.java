package com.wagmob.golearningbus.feature.pdf_reader;


import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.OpenableColumns;

import com.github.barteksc.pdfviewer.PDFView;
import com.github.barteksc.pdfviewer.listener.OnLoadCompleteListener;
import com.github.barteksc.pdfviewer.listener.OnPageChangeListener;
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle;

import java.io.File;

import javax.inject.Inject;

public class PDFViewerServiceImpl implements PDFViewerService, OnPageChangeListener, OnLoadCompleteListener {
    private PDFView mPDFView;
    private String mPdfUrl;
    private String pdfFileName;
    String mPdfShowLocalProgressTitle;
    String mPdfShowLocalProgressContent;
    private Integer pageNumber = 0;
    private Context mContext;

    @Inject
    public PDFViewerServiceImpl() {

    }

    @Override
    public void initialize(Context context, String pdfUrl, PDFView pdfView, String pdfShowLocalProgressTitle, String pdfShowLocalProgressContent) {
        mContext = context;
        mPdfUrl = pdfUrl;
        mPDFView = pdfView;
        mPdfShowLocalProgressTitle = pdfShowLocalProgressTitle;
        mPdfShowLocalProgressContent = pdfShowLocalProgressContent;

        downloadAndOpenPDF();
    }

    public void downloadAndOpenPDF() {
        // Get filename
        final String filename = mPdfUrl.substring(mPdfUrl.lastIndexOf("/") + 1);
        // The place where the downloaded PDF file will be put
        final File tempFile = new File(mContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), filename);
        if (tempFile.exists()) {
            // If we have downloaded the file before, just go ahead and show it.
            displayFromUri(Uri.fromFile(tempFile));
            return;
        }

        // Show progress dialog while downloading
        final ProgressDialog progress = ProgressDialog.show(mContext, mPdfShowLocalProgressTitle, mPdfShowLocalProgressContent, true);

        // Create the download request
        DownloadManager.Request r = new DownloadManager.Request(Uri.parse(mPdfUrl));
        r.setDestinationInExternalFilesDir(mContext, Environment.DIRECTORY_DOWNLOADS, filename);
        final DownloadManager dm = (DownloadManager) mContext.getSystemService(Context.DOWNLOAD_SERVICE);
        BroadcastReceiver onComplete = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!progress.isShowing()) {
                    return;
                }
                context.unregisterReceiver(this);

                progress.dismiss();
                long downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                Cursor c = dm.query(new DownloadManager.Query().setFilterById(downloadId));

                if (c.moveToFirst()) {
                    int status = c.getInt(c.getColumnIndex(DownloadManager.COLUMN_STATUS));
                    if (status == DownloadManager.STATUS_SUCCESSFUL) {
                        displayFromUri(Uri.fromFile(tempFile));
                    }
                }
                c.close();
            }
        };
        mContext.registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));

        // Enqueue the request
        dm.enqueue(r);
    }

    public void displayFromUri(Uri uri) {
        pdfFileName = getFileName(uri);

        mPDFView.fromUri(uri)
                .defaultPage(pageNumber)
                .onPageChange(this)
                .enableAnnotationRendering(true)
                .onLoad(this)
                .scrollHandle(new DefaultScrollHandle(mContext))
                .load();
    }

    public String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            Cursor cursor = mContext.getContentResolver().query(uri, null, null, null, null);
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        if (result == null) {
            result = uri.getLastPathSegment();
        }
        return result;
    }


    @Override
    public void loadComplete(int nbPages) {

    }

    @Override
    public void onPageChanged(int page, int pageCount) {
        pageNumber = page;
        //setTitle(String.format("%s %s / %s", pdfFileName, page + 1, pageCount));
    }
}
