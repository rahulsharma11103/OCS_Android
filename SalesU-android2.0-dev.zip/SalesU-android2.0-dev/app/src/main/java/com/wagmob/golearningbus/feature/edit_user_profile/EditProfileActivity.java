package com.wagmob.golearningbus.feature.edit_user_profile;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.JavaUtilClass;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.FileUploadModel;
import com.wagmob.golearningbus.model.requestModel.CropingOption;
import com.wagmob.golearningbus.util.ImageUtil;
import com.wagmob.golearningbus.util.JavaUtil;
import com.wagmob.golearningbus.view.BaseActivity;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import timber.log.Timber;

/**
 * Activity for edit profile
 *
 * @author Rahul Sharma
 */

public class EditProfileActivity extends BaseActivity implements EditProfileFragment.EditProfileInterface {

    private static final int EXTERNAL_STORAGE_PERMISSION_REQUEST_CODE = 2;
    private final static int REQUEST_PERMISSION_REQ_CODE = 34;
    public static boolean isUserPicNeedToUpdate;
    @BindView(R.id.toolbar)
    Toolbar mToolBar;
    @BindString(R.string.web_service_end_point)
    String mEndUrl;
    @BindString(R.string.web_service_upload_user_image)
    String mUserUploadServiceUrl;
    @BindString(R.string.web_service_api_key)
    String mApiKey;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    Gson mGson;
    Context mContext;
    String compressedImagePath;
    private Unbinder mUnBinder;
    private AppCompatImageView mImageView;
    private EditProfileFragment mEditProfileFragment;
    private Uri mCapturedImageUri;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1, CROP_FILE = 3;
    private File outPutFile = null;

    public static Intent callingIntent(Context context) {
        return new Intent(context, EditProfileActivity.class);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_common);
        mUnBinder = ButterKnife.bind(this);
        initializeComponent();

        setSupportActionBar(mToolBar);
        ActionBar actionBar = getSupportActionBar();
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.color_primary_hex != null) {
            actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex)));
        }
        actionBar.setDisplayHomeAsUpEnabled(true);
        initializeComponent();
        initializeFragment();
        getOutPutFile();

    }

    private void initializeFragment() {
        mEditProfileFragment = EditProfileFragment.newInstance(mContext);
        addFragment(R.id.fragment_common_container, mEditProfileFragment);
    }


    private void initializeComponent() {
        ((SalesUApplication) this.getApplication()).getApplicationModule().inject(this);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        mUnBinder.unbind();
        mGlobalApp.assignmentItems = null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.edit_profile, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home: {
                finish();
                overridePendingTransition(R.anim.activity_transition_stay_still, R.anim.activity_transition_out);
                break;
            }
            case R.id.save_info: {
                mEditProfileFragment.saveButtonClicked();
                break;
            }
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void selectImageOption(AppCompatImageView appCompatImageView) {
        mImageView = appCompatImageView;
        selectImageOption();
    }

    @Override
    public void callUploadToServerImage() {
        new UploadVideoToServer().execute(compressedImagePath);
    }

    private void selectImageOption() {
        final CharSequence[] items = {SalesUConstants.AD_TAKE_PHOTO, SalesUConstants.AD_CHOOSE_FROM_LIBRARY,
                SalesUConstants.AD_CANCEL};

        AlertDialog.Builder builder = new AlertDialog.Builder(EditProfileActivity.this);
        builder.setTitle(SalesUConstants.AD_ADD_PHOTO);
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals(SalesUConstants.AD_TAKE_PHOTO)) {

                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1) {
                        if (!JavaUtilClass.checkPermissionForCamera(EditProfileActivity.this)) {
                            JavaUtilClass.requestPermissionForCamera(EditProfileActivity.this);
                        } else {
                            if (!JavaUtilClass.checkPermissionForExternalStorage(EditProfileActivity.this)) {
                                JavaUtilClass.requestPermissionForExternalStorage(EditProfileActivity.this);
                            } else {
                                openCamera();
                            }
                        }
                    } else {
                        openCamera();
                    }

                } else if (items[item].equals(SalesUConstants.AD_CHOOSE_FROM_LIBRARY)) {

                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1) {
                        if (!JavaUtilClass.checkPermissionForExternalStorage(EditProfileActivity.this)) {
                            JavaUtilClass.requestPermissionForExternalStorage(EditProfileActivity.this);
                        } else {
                            openGallery();
                        }
                    } else {
                        openGallery();
                    }

                } else if (items[item].equals(SalesUConstants.AD_CANCEL)) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp1.jpg");
        mCapturedImageUri = Uri.fromFile(f);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, mCapturedImageUri);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    private void openGallery() {
        Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i, SELECT_FILE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (ContextCompat.checkSelfPermission(EditProfileActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_PERMISSION_REQ_CODE);
            return;
        }
    }

    @Override
    public void onRequestPermissionsResult(final int requestCode, final @NonNull String[] permissions, final @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_PERMISSION_REQ_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Permission granted.", Toast.LENGTH_SHORT).show();
                    selectImageOption();
                } else {
                    Toast.makeText(this, "Permission denied.", Toast.LENGTH_SHORT).show();
                }
                break;
            }
            case EXTERNAL_STORAGE_PERMISSION_REQUEST_CODE: {
                try {
                    if (grantResults.length > 0
                            && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        selectImageOption();
                    }
                } catch (Exception e) {
                    if (SalesUConstants.ISLogVisible) {
                        Timber.e("Exception Caught Permission request ==>> " + e.getMessage());
                    }
                }
                break;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == SELECT_FILE && resultCode == RESULT_OK && null != data) {
            isUserPicNeedToUpdate = true;
            mCapturedImageUri = data.getData();
            CropingIMG();

        } else if (requestCode == REQUEST_CAMERA && resultCode == Activity.RESULT_OK) {
            isUserPicNeedToUpdate = true;
            CropingIMG();
            onCaptureImageResult();
        } else if (requestCode == CROP_FILE) {
            try {

                if (outPutFile.exists()) {
                    Bitmap bitmap = decodeFile(outPutFile);
                    String filePath = ImageUtil.saveImageUsingBitMap(bitmap);
                    handleBeforeUploadToServer(filePath);
                } else {
                    Toast.makeText(getApplicationContext(), "Error while save image", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                if (SalesUConstants.ISLogVisible) {
                    Timber.e("Exception Caught while Crop file ==>> " + e.getMessage());
                }
            }
        }
    }

    private void CropingIMG() {

        final ArrayList<CropingOption> cropOptions = new ArrayList<CropingOption>();

        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setType(SalesUConstants.SELECT_IMAGE_TYPE);

        List<ResolveInfo> list = getPackageManager().queryIntentActivities(intent, 0);
        int size = list.size();
        if (size == 0) {
            Toast.makeText(this, "Cann't find image croping app", Toast.LENGTH_SHORT).show();
            return;
        } else {
            intent.setData(mCapturedImageUri);
            intent.putExtra(SalesUConstants.OUTPUT_X, 180);
            intent.putExtra(SalesUConstants.OUTPUT_Y, 180);
            intent.putExtra(SalesUConstants.ASPECT_X, 4);
            intent.putExtra(SalesUConstants.ASPECT_Y, 4);
            intent.putExtra(SalesUConstants.SCALE, true);

            //Create output file here
            intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(outPutFile));

            if (size == 1) {
                Intent i = new Intent(intent);
                ResolveInfo res = (ResolveInfo) list.get(0);

                i.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));

                startActivityForResult(i, CROP_FILE);
            } else {
                for (ResolveInfo res : list) {
                    final CropingOption co = new CropingOption();

                    co.title = getPackageManager().getApplicationLabel(res.activityInfo.applicationInfo);
                    co.icon = getPackageManager().getApplicationIcon(res.activityInfo.applicationInfo);
                    co.appIntent = new Intent(intent);
                    co.appIntent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
                    cropOptions.add(co);
                }

                CropingOptionAdapter adapter = new CropingOptionAdapter(getApplicationContext(), cropOptions);

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(SalesUConstants.CHOOSE_CROPING_APP);
                builder.setCancelable(false);
                builder.setAdapter(adapter, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int item) {
                        startActivityForResult(cropOptions.get(item).appIntent, CROP_FILE);
                    }
                });

                builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {

                        if (mCapturedImageUri != null) {
                            getContentResolver().delete(mCapturedImageUri, null, null);
                            mCapturedImageUri = null;
                        }
                    }
                });

                AlertDialog alert = builder.create();
                alert.show();
            }
        }
    }

    private Bitmap decodeFile(File f) {
        try {
            // decode image size
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(new FileInputStream(f), null, o);

            // Find the correct scale value. It should be the power of 2.
            final int REQUIRED_SIZE = 512;
            int width_tmp = o.outWidth, height_tmp = o.outHeight;
            int scale = 1;
            while (true) {
                if (width_tmp / 2 < REQUIRED_SIZE || height_tmp / 2 < REQUIRED_SIZE)
                    break;
                width_tmp /= 2;
                height_tmp /= 2;
                scale *= 2;
            }

            // decode with inSampleSize
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            return BitmapFactory.decodeStream(new FileInputStream(f), null, o2);
        } catch (FileNotFoundException e) {
        }
        return null;
    }

    void getOutPutFile() {
        outPutFile = new File(android.os.Environment.getExternalStorageDirectory(), "temp.jpg");
    }

    /**
     * To show selected image in image view and compressed image
     *
     * @param filePath local path of image
     */
    private void handleBeforeUploadToServer(String filePath) {
        Bitmap bmImg = BitmapFactory.decodeFile(filePath);
        mImageView.setImageBitmap(bmImg);
        compressedImagePath = ImageUtil.compressGalleryImage(filePath);
        if (compressedImagePath == null) {
            compressedImagePath = filePath;
        }

    }


    private void onCaptureImageResult() {
        try {
            final String filePath = mCapturedImageUri.getPath();
            handleBeforeUploadToServer(filePath);
            Timber.d("file_path" + filePath);
        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e("Exception Caught while Capturing picture From Camera ==>> " + e.getMessage());
            }
        }
    }


    /**
     * For uploading user pick to server
     */
    class UploadVideoToServer extends AsyncTask<String, Void, String> {

        HttpURLConnection conn = null;
        DataOutputStream dos = null;
        String lineEnd = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";
        int bytesRead, bytesAvailable, bufferSize;
        byte[] buffer;
        int maxBufferSize = 2000000;
        String serverResponseMessage = "";
        String token = mSharedPreference.getString(SalesUConstants.SHARED_ACCESS_TOKEN, "na");
        String refreshToken = mSharedPreference.getString(SalesUConstants.SHARED_REFRESH_TOKEN, "na");
        File myFile;
        FileInputStream fileInputStream;
        String serverResponse = "";

        @Override
        protected String doInBackground(String... params) {


            try {

                String sourceFilePath = params[0];
                myFile = new File(sourceFilePath);
                fileInputStream = new FileInputStream(myFile);

                String uelForUploadService = mEndUrl + mUserUploadServiceUrl;
                URL url = null;
                url = new URL(uelForUploadService);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoInput(true); // Allow Inputs
                conn.setDoOutput(true); // Allow Outputs
                conn.setUseCaches(false); // Don't use a Cached Copy
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Connection", "Keep-Alive");
                conn.setRequestProperty("AccessToken", token);
                conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);

                dos = new DataOutputStream(conn.getOutputStream());
                dos.writeBytes(twoHyphens + boundary + lineEnd);
                dos.writeBytes("Content-Disposition: form-data; name=\"image\";filename=\"" + sourceFilePath + "\"" + lineEnd);
                dos.writeBytes("Content-Type: " + "image/png" + lineEnd);
                dos.writeBytes(lineEnd);

                bytesAvailable = fileInputStream.available();
                bufferSize = Math.min(bytesAvailable, maxBufferSize);
                buffer = new byte[bufferSize];
                bytesRead = fileInputStream.read(buffer, 0, bufferSize);
                while (bytesRead > 0) {
                    dos.write(buffer, 0, bufferSize);
                    bytesAvailable = fileInputStream.available();
                    bufferSize = Math.min(bytesAvailable, maxBufferSize);
                    bytesRead = fileInputStream.read(buffer, 0, bufferSize);
                }
                // send multipart form data necessary after file data...
                dos.writeBytes(lineEnd);


                dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

                //getting response from server
                InputStream in = conn.getInputStream();
                byte data[] = new byte[1024];
                int counter = -1;
                while ((counter = in.read(data)) != -1) {
                    serverResponse += new String(data, 0, counter);
                }
                fileInputStream.close();
                dos.flush();
                dos.close();

            } catch (Exception iioe) {
                serverResponse = null;
            }
            return serverResponse;


        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                FileUploadModel fileUploadModel = mGson.fromJson(result, FileUploadModel.class);
                if (fileUploadModel != null && !fileUploadModel.error && fileUploadModel.data.image.image_id != null && fileUploadModel.data.image.image_url != null) {
                    mEditProfileFragment.updateUserPicId(fileUploadModel.data.image.image_id, fileUploadModel.data.image.image_url);
                } else {
                    mEditProfileFragment.updateUserPicId(null, null);
                }
            }

        }
    }


}
