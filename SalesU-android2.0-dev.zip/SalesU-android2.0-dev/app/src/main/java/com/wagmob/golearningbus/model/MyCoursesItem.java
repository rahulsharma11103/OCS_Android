package com.wagmob.golearningbus.model;


import java.io.Serializable;

public class MyCoursesItem implements Serializable{
    public int subscription_id;
    public String course_id;
    public String title;
    public String description;
    public String image_url;
    public String category_id;
    public String duration;
    public String is_paid;
    public String price;
    public String currency;
    public String total_assignments;
    public String completed_assignments;
    public String is_default;
}
