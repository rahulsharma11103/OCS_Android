package com.wagmob.golearningbus.feature.assignments;


import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.AssignmentItems;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.util.ImageUtil;

import org.json.JSONObject;

import java.util.List;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import timber.log.Timber;

/**
 * RecyclerView Adapter For showing list of Assignment
 *
 * @author Rahul Sharma
 */
public class AssignmentAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


    AssignmentRecyclerView assignmentRecyclerView;
    private Context mContext;
    private List<AssignmentItems> mCollectionAssignmentItems;
    boolean mIsGuestUser;

    /**
     * Constructor for Adapter
     *
     * @param context
     * @param assignmentItemsList
     */
    public AssignmentAdapter(Context context, List<AssignmentItems> assignmentItemsList, boolean isGuestUser) {
        mContext = context;
        mCollectionAssignmentItems = assignmentItemsList;
        mIsGuestUser = isGuestUser;
    }

    /**
     * Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.
     * This new ViewHolder should be constructed with a new View that can represent the items of the given type.
     * You can either create a new View manually or inflate it from an XML layout file.
     *
     * @param parent
     * @param viewType
     * @return Recycler view holder
     */
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder mRecyclerView;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.assignment_items, parent, false);
        mRecyclerView = new AssignmentRecyclerView(view);
        return mRecyclerView;
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     * This method should update the contents of the itemView to reflect the item at the given position.
     *
     * @param holder   Recycler view holder
     * @param position position of current item
     */
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        AssignmentRecyclerView viewHolder = (AssignmentRecyclerView) holder;
        configureAssignmentTask(viewHolder, position);
    }

    public void configureAssignmentTask(final AssignmentRecyclerView viewHolder, int position) {
        final AssignmentItems assignmentItems = mCollectionAssignmentItems.get(position);

        ImageUtil.getInstance().loadImage(mContext, assignmentItems.image_url, viewHolder.mAssignmentImageView, R.drawable.placeholder_default_rectangular, false, true);
        viewHolder.mAssignmentNameView.setText(assignmentItems.title);

        if (assignmentItems.is_complete.equalsIgnoreCase(SalesUConstants.COURSE_READ)) {
            if (mIsGuestUser) {
                viewHolder.mCourseReadView.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.checkicon_gray));

            } else {
                viewHolder.mCourseReadView.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.checkicon));
            }
        } else {
            viewHolder.mCourseReadView.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.checkicon_gray));
        }

        if (assignmentItems.assignment_type.equalsIgnoreCase(viewHolder.mAssignmentTypeVideo)) {
            viewHolder.mVideoPlayIcon.setVisibility(View.VISIBLE);
            viewHolder.mVideoPlayIcon.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.playicon_assignment));
        } else if (assignmentItems.assignment_type.equalsIgnoreCase(viewHolder.mAssignmentTypeQuiz)) {
            viewHolder.mVideoPlayIcon.setVisibility(View.GONE);
        } else if (assignmentItems.assignment_type.equalsIgnoreCase(viewHolder.mAssignmentTypeTutorial)) {
            viewHolder.mVideoPlayIcon.setVisibility(View.GONE);
        }

        viewHolder.mAssignmentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (assignmentItems.assignment_type.equalsIgnoreCase(viewHolder.mAssignmentTypeVideo)) {
                    triggerAmplitudeForCourseSelection(assignmentItems.title, viewHolder.mAssignmentTypeVideo);
                    //new BaseNavigator().navigateToVideoPlayerScreen(mContext, assignmentItems.assignment_id);
                    new BaseNavigator().navigateToSwipeAssignmentScreen(mContext, mCollectionAssignmentItems, viewHolder.getAdapterPosition());
                } else if (assignmentItems.assignment_type.equalsIgnoreCase(viewHolder.mAssignmentTypeQuiz)) {
                    triggerAmplitudeForCourseSelection(assignmentItems.title, viewHolder.mAssignmentTypeQuiz);
                    //  new BaseNavigator().navigateToQuizScreen(mContext, assignmentItems.assignment_id);
                    new BaseNavigator().navigateToSwipeAssignmentScreen(mContext, mCollectionAssignmentItems, viewHolder.getAdapterPosition());
                } else if (assignmentItems.assignment_type.equalsIgnoreCase(viewHolder.mAssignmentTypeTutorial)) {
                    triggerAmplitudeForCourseSelection(assignmentItems.title, viewHolder.mAssignmentTypeTutorial);
                    //new BaseNavigator().navigateToTutorialScreen(mContext, assignmentItems.assignment_id,assignmentItems.title);
                    new BaseNavigator().navigateToSwipeAssignmentScreen(mContext, mCollectionAssignmentItems, viewHolder.getAdapterPosition());
                } else if (assignmentItems.assignment_type.equalsIgnoreCase(viewHolder.mAssignmentTypeFlashCard)) {
                    triggerAmplitudeForCourseSelection(assignmentItems.title, viewHolder.mAssignmentTypeFlashCard);
                    //new BaseNavigator().navigateToTutorialScreen(mContext, assignmentItems.assignment_id,assignmentItems.title);
                    new BaseNavigator().navigateToSwipeAssignmentScreen(mContext, mCollectionAssignmentItems, viewHolder.getAdapterPosition());
                } else if (assignmentItems.assignment_type.equalsIgnoreCase(viewHolder.mAssignmentTypeWriter)) {
                    triggerAmplitudeForCourseSelection(assignmentItems.title, viewHolder.mAssignmentTypeWriter);
                    //new BaseNavigator().navigateToTutorialScreen(mContext, assignmentItems.assignment_id,assignmentItems.title);
                    new BaseNavigator().navigateToSwipeAssignmentScreen(mContext, mCollectionAssignmentItems, viewHolder.getAdapterPosition());
                } else if (assignmentItems.assignment_type.equalsIgnoreCase(viewHolder.mAssignmentTypePhraseCard)) {
                    triggerAmplitudeForCourseSelection(assignmentItems.title, viewHolder.mAssignmentTypePhraseCard);
                    new BaseNavigator().navigateToSwipeAssignmentScreen(mContext, mCollectionAssignmentItems, viewHolder.getAdapterPosition());
                } else {
                    Toast.makeText(mContext, viewHolder.mCommingSoon, Toast.LENGTH_SHORT).show();
                }

            }
        });


    }

    private void triggerAmplitudeForCourseSelection(String assignmentName, String assignmentType) {
        JSONObject jElement;
        try {
            jElement = new JSONObject();
            jElement.put(AmplitudeUtil.ASSIGNMENT_NAME, assignmentName);
            jElement.put(AmplitudeUtil.ASSIGNMENT_TYPE, assignmentType);
            AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_PLAY_ASSIGNMENT, jElement);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    /**
     * To set Assignment list
     *
     * @param assignmentItemsList assignment list item
     */
    public void setAssignmentItems(List<AssignmentItems> assignmentItemsList) {
        mCollectionAssignmentItems = assignmentItemsList;
        notifyDataSetChanged();
    }

    /**
     * This method return number of item, if list is null then it return 0
     *
     * @return if list is not null then it return number of list items otherwise it return 0
     */
    @Override
    public int getItemCount() {
        return mCollectionAssignmentItems != null ? mCollectionAssignmentItems.size() : 0;
    }

    /**
     * For binding view item
     */
    static class AssignmentRecyclerView extends RecyclerView.ViewHolder {
        @BindView(R.id.assignment_image)
        AppCompatImageView mAssignmentImageView;

        @BindView(R.id.assignment_name)
        AppCompatTextView mAssignmentNameView;

        @BindView(R.id.assignment_items_layout)
        RelativeLayout mAssignmentLayout;

        @BindView(R.id.course_read_view)
        AppCompatImageView mCourseReadView;

        @BindView(R.id.video_play_icon)
        AppCompatImageView mVideoPlayIcon;

        @BindString(R.string.assignment_type_video)
        String mAssignmentTypeVideo;

        @BindString(R.string.assignment_type_quiz)
        String mAssignmentTypeQuiz;

        @BindString(R.string.assignment_type_tutorial)
        String mAssignmentTypeTutorial;

        @BindString(R.string.assignment_type_flashcard)
        String mAssignmentTypeFlashCard;

        @BindString(R.string.assignment_type_writing)
        String mAssignmentTypeWriter;

        @BindString(R.string.assignment_type_phrase_card)
        String mAssignmentTypePhraseCard;

        @BindString(R.string.comming_soon_text)
        String mCommingSoon;

        public AssignmentRecyclerView(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
