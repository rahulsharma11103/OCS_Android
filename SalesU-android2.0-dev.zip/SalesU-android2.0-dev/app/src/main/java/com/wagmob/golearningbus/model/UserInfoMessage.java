package com.wagmob.golearningbus.model;


public class UserInfoMessage {

    public UserDetails user;

}
