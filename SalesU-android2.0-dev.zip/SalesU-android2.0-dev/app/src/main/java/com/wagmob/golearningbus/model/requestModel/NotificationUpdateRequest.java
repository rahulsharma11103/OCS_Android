package com.wagmob.golearningbus.model.requestModel;



public class NotificationUpdateRequest {
    public int relation_id;
}
