package com.wagmob.golearningbus.feature.allcourses;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatRatingBar;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.CoursesItems;
import com.wagmob.golearningbus.model.MyCoursesItem;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.util.ImageUtil;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import java.util.List;

import javax.inject.Inject;

import butterknife.BindColor;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import timber.log.Timber;

/**
 * RecyclerView Adapter For showing list of All Courses
 *
 * @author Rahul Sharma
 */
public class CoursesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context mContext;
    List<CoursesItems> mCategoriesCollection;
    LinearLayoutManager mLinearLayoutManager;
    int mNumberOfLoadMore = 1;
    boolean isCurrentWebServiceCalling;
    String mDefaultSubscriptionId = "10";
    CategoryViewHolder mCategoryViewHolder;
    CoursesItems mCategoriesItem;
    CategoryAdapterInterface mCategoryAdapterInterface;
    CoursesItems mCourseItem;
    @Inject
    Gson mGson;

    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    View view;
    SalesUApplication mGlobalApp;
    private RecyclerView mRecyclerView;
    private int mVisibleThreshold = 2;
    private int mLastVisibleItem, mTotalItemCount;
    private boolean mLoading;
    private boolean isAccessTokenExpire;
    private String mParamName, mSlugUrl, mMethodType;
    private boolean isGetClintIdTokenService;
    ProgressDialog mProgressDialog;
    private boolean mIsGuestLogin;


    public CoursesAdapter() {
    }

    /**
     * Constructor for Adapter, here we also call listener for pagination
     *
     * @param context         activity reference
     * @param categoriesItems list of items
     * @param recyclerView    Recycler view object
     */
    public CoursesAdapter(Context context, List<CoursesItems> categoriesItems, RecyclerView recyclerView, SalesUApplication globalApp,boolean isGuestLogin) {
        mRecyclerView = recyclerView;
        mContext = context;
        mGlobalApp = globalApp;
        mIsGuestLogin=isGuestLogin;
        mCategoriesCollection = categoriesItems;
        if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {
            mLinearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        }
        setScrollListener();
    }

    /**
     * Logic of pagination
     * if total list item is 10 and current focus item is 8 then we call web service for load more items
     */
    private void setScrollListener() {
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                mTotalItemCount = mLinearLayoutManager.getItemCount();
                mLastVisibleItem = mLinearLayoutManager.findLastVisibleItemPosition();
                if (mCategoriesCollection.size() < 10 * mNumberOfLoadMore) {
                    mLoading = true;
                }
                if (!isCurrentWebServiceCalling && !mLoading && (mTotalItemCount <= mLastVisibleItem + mVisibleThreshold)) {
                    isCurrentWebServiceCalling = true;
                    mCategoryAdapterInterface.getMoreCategory(mCategoriesCollection.size());
                }

            }
        });
    }

    public void setOnItemClickListener(CategoryAdapterInterface categoryAdapterInterface) {
        mCategoryAdapterInterface = categoryAdapterInterface;
    }

    /**
     * Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.
     * This new ViewHolder should be constructed with a new View that can represent the items of the given type.
     * You can either create a new View manually or inflate it from an XML layout file.
     *
     * @param parent
     * @param viewType
     * @return Recycler view holder
     */
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        view = inflater.inflate(R.layout.courses_list_item, parent, false);
        viewHolder = new CategoryViewHolder(view);
        return viewHolder;
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     * This method should update the contents of the itemView to reflect the item at the given position.
     *
     * @param holder   Recycler view holder
     * @param position position of current item
     */
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        CategoryViewHolder categoryViewHolder = (CategoryViewHolder) holder;
        configureCategoryViewHolder(categoryViewHolder, position);
        LayerDrawable stars = (LayerDrawable) categoryViewHolder.mCourseRating.getProgressDrawable();
        stars.getDrawable(2).setColorFilter(categoryViewHolder.mRatingColor, PorterDuff.Mode.SRC_ATOP);
    }

    private void configureCategoryViewHolder(final CategoryViewHolder categoryViewHolder, final int position) {
        try {


            final CoursesItems categoriesItem = mCategoriesCollection.get(position);
            categoryViewHolder.mCategoryTitleName.setText(categoriesItem.title);
            if (categoriesItem.course_rating != null) {
                categoryViewHolder.mCourseRating.setRating(Float.parseFloat(categoriesItem.course_rating));
            } else {
                categoryViewHolder.mCourseRating.setRating(SalesUConstants.DEFAULT_COURSE_RATING);
            }

            if (categoriesItem.is_paid != null && categoriesItem.is_paid.equalsIgnoreCase(SalesUConstants.TRUE_RESPONSE_BY_SERVICE)) {
                categoryViewHolder.mPriceView.setText(SalesUConstants.DOLLAR_SYMBOL_LABEL + categoriesItem.price);
            } else {
                categoryViewHolder.mPriceView.setText(SalesUConstants.FREE_COURSE_LABEL);
            }

            String imageUrl = null;
            ImageUtil.getInstance().loadImage(mContext, categoriesItem.image_url, categoryViewHolder.mCategoryItemImage, R.drawable.placeholder_default_rectangular, false, true);

            if (Integer.parseInt(categoriesItem.subscription_id) > 0) {
                categoryViewHolder.mSubscribe.setText(categoryViewHolder.mSubscribedLabel);
                categoryViewHolder.mSubscribe.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.enroll_button));
                //  categoryViewHolder.mSubscribe.setBackgroundColor(categoryViewHolder.mSubscribedButtonBackgroundColor);

            } else {
                categoryViewHolder.mSubscribe.setText(categoryViewHolder.mSubscribeLabel);
                //categoryViewHolder.mSubscribe.setBackgroundColor(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex));
                Drawable background = categoryViewHolder.mSubscribe.getBackground();
                ((GradientDrawable) background).setColorFilter(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex), PorterDuff.Mode.SRC_ATOP);

            }

            categoryViewHolder.mSubscribe.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (Integer.parseInt(categoriesItem.subscription_id) == 0) {
                        if(mIsGuestLogin)
                        {
                            showAlertForGuestLogin();
                        }else {
                            mCategoryViewHolder = categoryViewHolder;
                            mCategoriesItem = categoriesItem;
                            mCategoryAdapterInterface.subscribeClick(categoriesItem, categoryViewHolder);
                        }
                    }

                }
            });

            categoryViewHolder.mCourseView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MyCoursesItem myCoursesItem = new MyCoursesItem();
                    myCoursesItem.title = categoriesItem.title;
                    myCoursesItem.image_url = categoriesItem.image_url;
                    myCoursesItem.course_id = categoriesItem.course_id;
                    myCoursesItem.subscription_id = Integer.parseInt(categoriesItem.subscription_id);
                    myCoursesItem.is_default=categoriesItem.is_default;
                    triggerAmplitudeForCourseSelection(categoriesItem.title, mContext.getString(R.string.all_courses_label));
                    new BaseNavigator().navigateToCourseDetailsScreen(mContext, myCoursesItem);
               /* if (Integer.parseInt(categoriesItem.subscription_id) == 0) {
                    new BaseNavigator().navigateToCourseDetailsScreen(mContext, myCoursesItem);
                   // Toast.makeText(mContext, categoryViewHolder.mPleaseSubscribeCourseMessage, Toast.LENGTH_SHORT).show();
                } else {
                    new BaseNavigator().navigateToCourseDetailsScreen(mContext, myCoursesItem);
                }*/

                }
            });

        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    private void triggerAmplitudeForCourseSelection(String courseName, String fromWhichScreen) {
        JSONObject jElement;
        try {
            jElement = new JSONObject();
            jElement.put(AmplitudeUtil.COURSE_NAME, courseName);
            jElement.put(AmplitudeUtil.FROM_SCREEN, fromWhichScreen);
            AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_COURSE_TAPPED, jElement);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    private void showAlertForGuestLogin() {
        AlertDialog.Builder alert = new AlertDialog.Builder(mContext);
        alert.setTitle(mContext.getString(R.string.guest_login_alert_title));
        alert.setMessage(mContext.getString(R.string.guest_login_alert_message));
        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                new BaseNavigator().navigateToLoginActivity(mContext);
            }
        });
        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alert.show();
    }

    /**
     * Called when load more and pagination will needed
     *
     * @param categoryCollection list of category items
     * @param isLoadMoreData     if load more than return true otherwise return false
     */
    public void setCategoryCollection(List<CoursesItems> categoryCollection, boolean isLoadMoreData) {
        mCategoriesCollection = categoryCollection;
        if (!isLoadMoreData) {
            mNumberOfLoadMore = 1;
            mLoading = false;
            notifyDataSetChanged();
        } else {
            mNumberOfLoadMore = mNumberOfLoadMore + 1;
            isCurrentWebServiceCalling = false;
            // notifyDataSetChanged();
            notifyItemInserted(mCategoriesCollection.size());
        }
    }

    /**
     * @return list of Course  list
     */
    public List<CoursesItems> getCategoryCollection() {
        return mCategoriesCollection;
    }

    /**
     * This method return number of item, if list is null then it return 0
     *
     * @return if list is not null then it return number of list items otherwise it return 0
     */
    @Override
    public int getItemCount() {
        return (mCategoriesCollection != null) ? mCategoriesCollection.size() : 0;
    }


    /**
     * Interface for Adapter
     */
    public interface CategoryAdapterInterface {
        void getMoreCategory(int offset);

        void subscribeClick(CoursesItems categoriesItem, CategoryViewHolder categoryViewHolder);
    }

    /**
     * For binding view item
     */
    public static class CategoryViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.subscribe_button)
        public
        AppCompatButton mSubscribe;
        @BindString(R.string.all_courses_subscribed)
        public
        String mSubscribedLabel;
        @BindColor(R.color.subscribed_button_background)
        public int mSubscribedButtonBackgroundColor;
        @BindString(R.string.something__went_wrong)
        public String mSomethingWentWrong;
        @BindString(R.string.courses_successfully_subscribed)
        public String mCourseSuccessfullySubscribed;
        @BindView(R.id.category_item_image)
        AppCompatImageView mCategoryItemImage;
        @BindView(R.id.category_item_tittle_name)
        AppCompatTextView mCategoryTitleName;
        @BindView(R.id.courses_rating)
        AppCompatRatingBar mCourseRating;
        @BindView(R.id.category_list_layout)
        RelativeLayout mCategoryLayout;
        @BindView(R.id.price_view)
        AppCompatTextView mPriceView;
        @BindString(R.string.all_courses_subscribe)
        String mSubscribeLabel;
        @BindColor(R.color.subscribe_button_background)
        int mSubscribeButtonBackgroundColor;
        @BindColor(R.color.rating_color)
        int mRatingColor;
        @BindView(R.id.course_view)
        RelativeLayout mCourseView;
        @BindString(R.string.all_category_courses_label)
        String mCourseLabel;
        @BindString(R.string.please_subscribe_course)
        String mPleaseSubscribeCourseMessage;
        @BindString(R.string.guest_login_alert_title)
        String mProgressDialogTitle;
        @BindString(R.string.guest_login_alert_message)
        String mProgressDialogMessage;

        public CategoryViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }


}
