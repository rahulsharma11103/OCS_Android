package com.wagmob.golearningbus.feature.launcher;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.AppSettingModel;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import timber.log.Timber;

/**
 * Fragment for launcher.
 *
 * @author Rahul Sharma
 */

public class LauncherFragment extends LoadDataFragment {

    static Context mContext;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.parent_layout)
    CoordinatorLayout mParentLayout;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.web_service_for_get_app_setting)
    String mSettingServiceUrl;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @BindString(R.string.retry_label)
    String mRetryLabel;
    @BindString(R.string.app_name)
    String mAppName;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    Gson mGson;
    private Unbinder mUnbinder;
    private String mParamName, mSlugUrl, mMethodType;
    private boolean isAccessTokenExpire;

    /**
     * To initialize and return current fragment instance
     *
     * @param context
     * @return current fragment instance
     */
    public static LauncherFragment newInstance(Context context) {
        mContext = context;
        return new LauncherFragment();
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.launcher_fragment, container, false);
        mUnbinder = ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(mContext!=null) {
            initializeComponent();
            mGlobalApp.refreshAllObject();
            initializeAmplitude();
            loadSetting();
        }
    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    /**
     * To load Assignment list
     */
    private void loadSetting() {

        callSettingService("na", mSettingServiceUrl, SalesUConstants.GET_METHOD_TYPE);
    }

    /**
     * call Change password web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callSettingService(String paramName, String path, String methodType) {
        showLoading();
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new GetSettingService().execute();
        } else {
            hideLoading();
            Snackbar.make(mParentLayout, mNetworkMessage, Snackbar.LENGTH_INDEFINITE).setAction(mRetryLabel, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mGlobalApp.refreshAllObject();
                    loadSetting();
                }
            }).show();
            //  Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Response of Tutorial webservice
     *
     * @param response response of web service
     */
    public void changeSettingWebServiceResponse(String response) {

        try {
            AppSettingModel appSettingModel = mGson.fromJson(response, AppSettingModel.class);
            if (appSettingModel != null && appSettingModel.message != null) {
                mGlobalApp.appSettingModel = appSettingModel;
                if (!(mSharedPreference.getBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, false))) {
                    if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null
                            && mGlobalApp.appSettingModel.data.splash != null && mGlobalApp.appSettingModel.data.splash.size() > 0) {
                        new BaseNavigator().navigateToTourScreen(mContext);
                    } else {
                        if (mSharedPreference.getBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, false)) {
                            new BaseNavigator().navigateToHomeActivity(mContext);
                        } else {
                            new BaseNavigator().navigateToLoginActivity(mContext);
                        }
                    }
                } else {
                    new BaseNavigator().navigateToHomeActivity(mContext);
                }

            } else {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ex) {
            Snackbar.make(mParentLayout, mSomeThingWentWrong, Snackbar.LENGTH_INDEFINITE).setAction(mRetryLabel, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mGlobalApp.refreshAllObject();
                    loadSetting();
                }
            }).show();
            // Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }


    }

    private void initializeAmplitude() {
        JSONObject jElement;
        try {
            jElement = new JSONObject();
            jElement.put(AmplitudeUtil.APPLICATION_NAME, mAppName);
            AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_LAUNCH_SUCCESSFULLY, jElement);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    /**
     * To Call Async Web Service
     */
    class GetSettingService extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new GetSettingService().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new GetSettingService().execute();
                    } else {
                        changeSettingWebServiceResponse(s);
                    }
                } else {
                    hideLoading();
                    // Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                    if (mParentLayout != null && mSomeThingWentWrong != null && mRetryLabel != null) {
                        Snackbar.make(mParentLayout, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Snackbar.LENGTH_INDEFINITE).setAction(mRetryLabel, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                mGlobalApp.refreshAllObject();
                                loadSetting();
                            }
                        }).show();
                    }
                }
            } catch (Exception e) {
                hideLoading();
                if (mParentLayout != null && mSomeThingWentWrong != null && mRetryLabel != null) {
                    Snackbar.make(mParentLayout, mSomeThingWentWrong, Snackbar.LENGTH_INDEFINITE).setAction(mRetryLabel, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mGlobalApp.refreshAllObject();
                            loadSetting();
                        }
                    }).show();
                }
                //  Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }
    }
}
