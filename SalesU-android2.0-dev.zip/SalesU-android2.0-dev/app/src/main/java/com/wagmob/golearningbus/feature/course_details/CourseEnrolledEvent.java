package com.wagmob.golearningbus.feature.course_details;



public class CourseEnrolledEvent {
    public boolean mIsCourseSubscribe;

    public CourseEnrolledEvent(boolean isCourseSubscribe) {
        mIsCourseSubscribe = isCourseSubscribe;
    }

    public boolean getCourseSubscribeUpdate() {
        return mIsCourseSubscribe;
    }
}
