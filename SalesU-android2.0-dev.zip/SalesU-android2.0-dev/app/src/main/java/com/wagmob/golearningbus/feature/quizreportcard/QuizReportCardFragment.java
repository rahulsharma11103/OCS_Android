package com.wagmob.golearningbus.feature.quizreportcard;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.gson.Gson;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.assignments.UpdateProgressForSectionEvent;
import com.wagmob.golearningbus.feature.edit_user_profile.EditProfileEvent;
import com.wagmob.golearningbus.model.AssignmentItems;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.requestModel.AssignmentRequest;
import com.wagmob.golearningbus.model.requestModel.QuizStatusRequest;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import java.util.List;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

/**
 * @author Rahul Sharma
 *         Fragment For showing Quiz Result
 */

public class QuizReportCardFragment extends LoadDataFragment {

    private static Context mContext;
    private static String mAssigmentId;
    private static int mQuizPercentage;
    private static List<AssignmentItems> mCollectionAssignmentItems;
    private static int mDefaultTabPosition;
    @BindView(R.id.user_percentage_count)
    AppCompatTextView mUserPercentageCountView;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.congratulation_message)
    AppCompatTextView mCongratulationMessageView;
    @BindView(R.id.retake_text_view)
    AppCompatTextView mRetakeTextVIew;
    @BindView(R.id.your_result)
    AppCompatTextView mYourResultView;
    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.web_service_to_get_quiz)
    String quizServiceUrl;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.web_service_set_assignment_progress)
    String mWebServiceURlForSetAssignmentProgress;
    @BindString(R.string.web_service_set_quiz_status_percentage)
    String mWebServiceURlForSetQuizStatusPercentage;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    Gson mGson;
    @Inject
    EventBus mEventBus;
    Unbinder mUnbinder;
    boolean isNeedToCallSetProgress;
    private View mView;
    private String mParamName, mSlugUrl, mMethodType;
    private boolean isAccessTokenExpire;
    private boolean isSetProgress;
    private CircularProgressBar mCircleProgress;

    /**
     * To initialize and return current fragment instance
     *
     * @param context
     * @param assignmentId
     * @param quizPercentage
     * @return current fragment instance
     */
    public static QuizReportCardFragment newInstance(Context context, String assignmentId, String quizPercentage, List<AssignmentItems> collectionAssignmentItems, int defaultTabPosition) {
        mContext = context;
        mAssigmentId = assignmentId;
        mQuizPercentage = Integer.parseInt(quizPercentage);
        mCollectionAssignmentItems = collectionAssignmentItems;
        mDefaultTabPosition = defaultTabPosition;
        return new QuizReportCardFragment();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.quiz_report_card, container, false);
        mUnbinder = ButterKnife.bind(this, mView);
        return mView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(mContext!=null) {
            initializeComponent();
            setupUI();
        }

    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    private void setupUI() {
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.color_primary_hex != null) {
            mYourResultView.setTextColor(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex));
        }
        mCircleProgress = (CircularProgressBar) mView.findViewById(R.id.progress_image);
        //mCircleProgress.setProgress(mQuizPercentage);
        mCircleProgress.setProgressWithAnimation(mQuizPercentage, 3000);
        mUserPercentageCountView.setText(mQuizPercentage + SalesUConstants.PERCENTAGE_SYMBOL);
        if (mQuizPercentage > 0) {
            setQuizStatus();
        }
        if (mQuizPercentage < SalesUConstants.MINIMUM_PERCENTAGE_TO_PASS) {
            mRetakeTextVIew.setText(getString(R.string.quiz_report_card_failed_message));
            mCircleProgress.setColor(ContextCompat.getColor(mContext, R.color.red));
            mCongratulationMessageView.setVisibility(View.INVISIBLE);
        } else {
            mRetakeTextVIew.setText(getString(R.string.quiz_report_card_passed_message));
            isNeedToCallSetProgress = true;
        }
    }


    @OnClick(R.id.quiz_report_card_retake_layout)
    public void RetakeQuiz() {
        new BaseNavigator().navigateToSwipeAssignmentScreen(mContext, mCollectionAssignmentItems, mDefaultTabPosition);
        getActivity().finish();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }

    private void setProgress() {
        isSetProgress = true;
        AssignmentRequest assignmentRequest = new AssignmentRequest();
        assignmentRequest.assignment_id = mAssigmentId;
        String paramName = mGson.toJson(assignmentRequest);
        callSetProgressDataService(paramName, mWebServiceURlForSetAssignmentProgress, SalesUConstants.POST_METHOD_TYPE);
    }

    private void setQuizStatus() {
        QuizStatusRequest quizStatusRequest = new QuizStatusRequest();
        quizStatusRequest.assignment_id = mAssigmentId;
        quizStatusRequest.percentage = mQuizPercentage;
        String paramName = mGson.toJson(quizStatusRequest);
        callSetProgressDataService(paramName, mWebServiceURlForSetQuizStatusPercentage, SalesUConstants.POST_METHOD_TYPE);
    }

    /**
     * call Tutorial web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callSetProgressDataService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new SetProgress().execute();
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    private void setQuizStatusResponse() {
        if (isNeedToCallSetProgress)
            setProgress();
    }

    /**
     * To Call Async Web Service
     */
    class SetProgress extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new SetProgress().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new SetProgress().execute();
                    } else {
                        if (isSetProgress) {
                            isSetProgress = false;
                            mEventBus.post(new EditProfileEvent(true));
                            mEventBus.post(new UpdateProgressForSectionEvent(true));
                        } else {
                            setQuizStatusResponse();
                        }
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }


        }
    }
}
