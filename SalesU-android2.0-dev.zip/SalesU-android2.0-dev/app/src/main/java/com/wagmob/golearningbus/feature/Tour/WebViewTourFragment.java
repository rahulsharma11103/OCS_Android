package com.wagmob.golearningbus.feature.Tour;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.view.LoadDataFragment;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Fragment for WebView.
 *
 * @author Rahul Sharma
 */

public class WebViewTourFragment extends LoadDataFragment {

     Context mContext;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.tutorial_web_view)
    WebView mTutorialWebView;

    @BindString(R.string.tutorial_mime_type_html)
    String mTutorialMimeTypeHtml;
    @BindString(R.string.tutorial_mime_type_pdf)
    String mTutorialMimeTypePdf;

    @Inject
    SalesUApplication mGlobalApp;

    private Unbinder mUnbinder;
    private int mPosition;



    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tour_web_view, container, false);
        mUnbinder = ButterKnife.bind(this, view);
        mContext=getContext();
        initializeComponent();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setupWebView();
    }

    public void setPosition(int position)
    {
        mPosition=position;
    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }


    private void setupWebView() {
        mTutorialWebView.getSettings().setJavaScriptEnabled(true);
        mTutorialWebView.getSettings().setLoadsImagesAutomatically(true);
        mTutorialWebView.getSettings().setUseWideViewPort(true);
        mTutorialWebView.getSettings().setLoadWithOverviewMode(true);
        mTutorialWebView.getSettings().setSupportZoom(true);
        mTutorialWebView.getSettings().setBuiltInZoomControls(true);
      //  mTutorialWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);


        //   mTutorialWebView.getSettings().setDomStorageEnabled(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mTutorialWebView.getSettings().setMixedContentMode(mTutorialWebView.getSettings().MIXED_CONTENT_ALWAYS_ALLOW);
        }
        showLoading();
        mTutorialWebView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

            public void onPageFinished(WebView view, String url) {
                hideLoading();
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {

                Toast.makeText(mContext, "Oh no! " + description, Toast.LENGTH_SHORT).show();
                hideLoading();

            }
        });

        mTutorialWebView.loadUrl(mGlobalApp.appSettingModel.data.splash.get(mPosition).html_url);

    }
}
