package com.wagmob.golearningbus.feature.assignment_swipe;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.feature.CommingSoon.ComingSoonFragment;
import com.wagmob.golearningbus.feature.flashcard.FlashCardFragment;
import com.wagmob.golearningbus.feature.phrasebook.PhrasebookFragment;
import com.wagmob.golearningbus.feature.quiz.QuizFragment;
import com.wagmob.golearningbus.feature.tutorial.TutorialFragment;
import com.wagmob.golearningbus.feature.video.VideoPlayerFragment;
import com.wagmob.golearningbus.feature.writer.WriterFragment;
import com.wagmob.golearningbus.model.AssignmentItems;

import java.util.List;

/**
 * Slider for Assignment
 *
 * @author Rahul Sharma
 */

public class AssignmentSliderPagerAdapter extends FragmentStatePagerAdapter {

    int mDefaultPosition;
    boolean isFirstTime;
    ViewPager mPager;
    private Context mContext;
    private List<AssignmentItems> mCollectionAssignmentItems;


    public AssignmentSliderPagerAdapter(FragmentManager fm, Context context, List<AssignmentItems> assignmentItems, int defaultPosition, ViewPager viewPager) {
        super(fm);
        mContext = context;
        mCollectionAssignmentItems = assignmentItems;
        mDefaultPosition = defaultPosition;
        mPager = viewPager;
    }

    @Override
    public Fragment getItem(int position) {
        if (mCollectionAssignmentItems != null) {
            AssignmentItems assignmentItem = mCollectionAssignmentItems.get(position);
            if (assignmentItem.assignment_type.equalsIgnoreCase(mContext.getString(R.string.assignment_type_video))) {
                if (!isFirstTime && position == mDefaultPosition) {
                    isFirstTime = true;
                    return new VideoPlayerFragment().newInstance(mContext, assignmentItem.assignment_id, true, mPager);
                } else {
                    return new VideoPlayerFragment().newInstance(mContext, assignmentItem.assignment_id, false, mPager);
                }
            } else if (assignmentItem.assignment_type.equalsIgnoreCase(mContext.getString(R.string.assignment_type_tutorial))) {
                return new TutorialFragment().newInstance(mContext, assignmentItem.assignment_id);
            } else if (assignmentItem.assignment_type.equalsIgnoreCase(mContext.getString(R.string.assignment_type_quiz))) {
                // int pp=mPager.getCurrentItem();
                if (!isFirstTime && position == mDefaultPosition) {
                    isFirstTime = true;
                    return new QuizFragment().newInstance(mContext, assignmentItem.assignment_id, true, mCollectionAssignmentItems, position);
                } else {
                    return new QuizFragment().newInstance(mContext, assignmentItem.assignment_id, false, mCollectionAssignmentItems, position);
                }
            } else if (assignmentItem.assignment_type.equalsIgnoreCase(mContext.getString(R.string.assignment_type_flashcard))) {
                //return new ComingSoonFragment().newInstance(mContext);
                return new FlashCardFragment().newInstance(mContext, assignmentItem.assignment_id);
            } else if (assignmentItem.assignment_type.equalsIgnoreCase(mContext.getString(R.string.assignment_type_writing))) {
                //return new ComingSoonFragment().newInstance(mContext);
                return new WriterFragment().newInstance(mContext, assignmentItem.assignment_id);
            } else if (assignmentItem.assignment_type.equalsIgnoreCase(mContext.getString(R.string.assignment_type_phrase_card))) {
                return new PhrasebookFragment().newInstance(mContext, assignmentItem.assignment_id);
            } else {
                return new ComingSoonFragment().newInstance(mContext);
            }
        } else {
            return null;
        }

    }

    @Override
    public int getCount() {
        return mCollectionAssignmentItems != null ? mCollectionAssignmentItems.size() : 0;
    }
}
