package com.wagmob.golearningbus.model;

/**
 * Created by Rahul Sharma on 6/29/2017.
 */

public class LibraryInfoModel {
    public String title;
    public String description;
    public String android_url;
    public String libraryimage_url;
    public String android_bundleurl;
}
