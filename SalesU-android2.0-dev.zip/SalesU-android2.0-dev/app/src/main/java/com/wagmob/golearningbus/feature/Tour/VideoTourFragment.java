package com.wagmob.golearningbus.feature.Tour;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.VideoView;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.view.LoadDataFragment;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import timber.log.Timber;

/**
 * Tour For Video
 *
 * @author Rahul Sharma
 */

public class VideoTourFragment extends LoadDataFragment {

    static Context mContext;
    MediaController mMediaController;
    @BindView(R.id.video_player_view)
    VideoView mVideoView;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;

    @Inject
    SalesUApplication mGlobalApp;

    private Unbinder mUnbinder;
    private Uri mVideoUri;
    private boolean isVideoPause;
    private int mPosition;


    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.video_player, container, false);
        mUnbinder = ButterKnife.bind(this, view);
        mContext = getContext();
        initializeComponent();
        return view;
    }

    public void setPosition(int position) {
        mPosition = position;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setupVideoPlayer(mGlobalApp.appSettingModel.data.splash.get(mPosition).video_url);
    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    /**
     * setup video player
     */
    private void setupVideoPlayer(String videoUrl) {
        showLoading();
        try {
            mMediaController = new MediaController(mContext);
            mVideoUri = Uri.parse(videoUrl);
            mVideoView.setMediaController(mMediaController);
            mVideoView.setVideoURI(mVideoUri);
            mVideoView.requestFocus();
            mVideoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    hideLoading();
                }
            });
        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(e.getMessage());
            }
        }

    }

    /**
     * resume video
     */
    @Override
    public void onResume() {

        super.onResume();
        if (mVideoView != null) {
            if (isVideoPause) {
                mVideoView.seekTo(mGlobalApp.videoCurrentTIme);
                mVideoView.resume();
            } else {
                //  mVideoView.start();
            }
        }
    }


    @Override
    public void onPause() {
        isVideoPause = true;
        mGlobalApp.videoCurrentTIme = mVideoView.getCurrentPosition();
        if (mVideoView != null)
            mVideoView.pause();
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            if (mVideoView != null)
                mVideoView.start();
        } else {
            if (mVideoView != null)
                mVideoView.pause();
        }
    }


}
