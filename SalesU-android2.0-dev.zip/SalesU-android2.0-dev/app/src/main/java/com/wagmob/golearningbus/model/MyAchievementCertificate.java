package com.wagmob.golearningbus.model;


public class MyAchievementCertificate {
    public String course_id;
    public String title;
    public String image_id;
    public String image_url;
    public String certificate_url;
}
