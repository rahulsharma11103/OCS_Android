package com.wagmob.golearningbus.feature.assignment_swipe;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.WindowManager;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.allcourses.UpdateMyCourseListEvent;
import com.wagmob.golearningbus.model.AssignmentItems;
import com.wagmob.golearningbus.util.JavaUtil;
import com.wagmob.golearningbus.view.BaseActivity;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;

/**
 * Activity For swipe assignment feature
 *
 * @author Rahul Sharma
 */

public class SwipeAssignmentActivity extends BaseActivity {


    @BindView(R.id.toolbar)
    Toolbar mToolBar;
    @BindString(R.string.interstitial_add_id)
    String mInterstitialId;
    private InterstitialAd mInterstitialAd;
    boolean mIsAlreadyPurchase;
    @Inject
    SalesUApplication mGlobalApp;

    @Inject
    SharedPreferences mSharedPreferences;

    @Inject
    EventBus mEventBus;


    Context mContext;
    ActionBar mActionBar;
    private Unbinder mUnBinder;
    private SwipeAssignmentFragment mSwipeAssignmentFragment;
    private List<AssignmentItems> mCollectionAssignmentItems;
    private int defaultTabPosition;

    /**
     * @param context current activity context
     * @return intent of activity
     */
    public static Intent callingIntent(Context context) {
        return new Intent(context, SwipeAssignmentActivity.class);
    }

    /**
     * Use to initialize layout and App bar
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_common);
        mContext = this;
        mCollectionAssignmentItems = (ArrayList<AssignmentItems>) getIntent().getSerializableExtra(SalesUConstants.ASSIGNMENT_DETAILS);
        defaultTabPosition = getIntent().getIntExtra(SalesUConstants.ASSIGNMENT_DEFAULT_TAB, 0);
        mUnBinder = ButterKnife.bind(this);
        initializeComponent();
        initializeToolBar();
        if(mSharedPreferences!=null) {
            mIsAlreadyPurchase = mSharedPreferences.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

            if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                mInterstitialAd = new InterstitialAd(this);
                mInterstitialAd.setAdUnitId(mInterstitialId);
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }
        }
        initializeFragment();
    }

    private void initializeToolBar() {
        setSupportActionBar(mToolBar);
        mActionBar = getSupportActionBar();
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.color_primary_hex != null) {
            mActionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex)));
        }
        mActionBar.setDisplayHomeAsUpEnabled(true);
    }

    /**
     * Add fragment to activity
     */
    private void initializeFragment() {
        mSwipeAssignmentFragment = new SwipeAssignmentFragment().newInstance(mContext, mCollectionAssignmentItems, defaultTabPosition, mSharedPreferences);
        addFragment(R.id.fragment_common_container, mSwipeAssignmentFragment);
    }

    /**
     * initializing dagger components
     */
    private void initializeComponent() {
        ((SalesUApplication) this.getApplication()).getApplicationModule().inject(this);
    }

    /**
     * unbind butter knife object
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mUnBinder.unbind();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mEventBus != null) {
            mEventBus.post(new UpdateMyCourseListEvent(true));
        }
    }

    /**
     * menu option selection
     *
     * @param item
     * @return menu item
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home: {
                if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                    if (mInterstitialAd!=null&&mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                    }}
                finish();
                overridePendingTransition(R.anim.activity_transition_stay_still, R.anim.activity_transition_out);
                break;

            }
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
            if (mInterstitialAd!=null&&mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            }}
        finish();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            mActionBar.hide();
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            mActionBar.show();
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
    }
}
