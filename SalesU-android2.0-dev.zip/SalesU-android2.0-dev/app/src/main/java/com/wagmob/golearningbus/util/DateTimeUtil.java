package com.wagmob.golearningbus.util;

import android.content.Context;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.constants.SalesUConstants;

import org.ocpsoft.prettytime.PrettyTime;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Helper class for Time
 *
 * @author Rahul Sharma.
 */

public class DateTimeUtil {

    public static final String SIMPLE_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

    // assumes UTC input
    public static String timeAgo(String timestamp, Context context) {
        return timeAgo(timestamp, SIMPLE_DATE_FORMAT, context);
    }

    // assumes UTC input
    public static String timeAgo(String timestamp, String format, Context mContext) {

        try {
            timestamp = timestamp.split(Pattern.quote("."))[0] + SalesUConstants.ZERO_MILISECONDS;
            SimpleDateFormat dateFormat = new SimpleDateFormat(format, Locale.getDefault());
            //dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date localTime = dateFormat.parse(timestamp);
            PrettyTime prettyTime = new PrettyTime();
            String timeStamp = prettyTime.format(localTime);

            String[] timeStampArr = timeStamp.split(" ");

            if (timeStamp.contains(mContext.getString(R.string.timestamp_moments))) {
               /* Date now = new Date();
                int sec = (int) (TimeUnit.MILLISECONDS.toMillis(now.getTime() - localTime.getTime())) / 1000;
                timeStamp = String.valueOf(sec) + mContext.getString(R.string.timestamp_second_format);*/
                timeStamp = mContext.getString(R.string.timestamp_moments_ago_format);
            } else if (timeStamp.contains(mContext.getString(R.string.timestamp_second))) {
                timeStamp = timeStampArr[0] + " " + mContext.getString(R.string.timestamp_second);
            } else if (timeStamp.contains(mContext.getString(R.string.timestamp_minute))) {
                timeStamp = timeStampArr[0] + " " + mContext.getString(R.string.timestamp_minute);
            } else if (timeStamp.contains(mContext.getString(R.string.timestamp_hour))) {
                timeStamp = timeStampArr[0] + " " + mContext.getString(R.string.timestamp_hour);
            } else if (timeStamp.contains(mContext.getString(R.string.timestamp_day))) {
                timeStamp = timeStampArr[0] + " " + mContext.getString(R.string.timestamp_day);
            } else if (timeStamp.contains(mContext.getString(R.string.timestamp_week))) {
                timeStamp = timeStampArr[0] + " " + mContext.getString(R.string.timestamp_week);
            } else if (timeStamp.contains(mContext.getString(R.string.timestamp_month))) {
                timeStamp = timeStampArr[0] + " " + mContext.getString(R.string.timestamp_month);
            } else if (timeStamp.contains(mContext.getString(R.string.timestamp_year))) {
                timeStamp = timeStampArr[0] + " " + mContext.getString(R.string.timestamp_year);
            }
            return timeStamp;
        } catch (Exception e) {
            return timestamp;
        }
    }

    public static String getTimeAgoFromUnix(String unixDate, Context context) {
        long unixSeconds = Long.parseLong(unixDate);
        Date date = new Date(unixSeconds * 1000L); // *1000 is to convert seconds to milliseconds
        SimpleDateFormat sdf = new SimpleDateFormat(SIMPLE_DATE_FORMAT, Locale.getDefault()); // the format of your date
        String formattedDate = sdf.format(date);
        return DateTimeUtil.timeAgo(formattedDate, context);
    }
}
