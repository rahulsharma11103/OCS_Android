package com.wagmob.golearningbus.feature.notification;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.DeleteWebServiceResponse;
import com.wagmob.golearningbus.model.NotificationModel;
import com.wagmob.golearningbus.model.NotificationModelInfo;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.requestModel.NotificationDeleteRequest;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.JavaUtil;
import com.wagmob.golearningbus.util.SwipeUtil;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import java.util.ArrayList;

import javax.inject.Inject;

import butterknife.BindDimen;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

/**
 * Fragment for show notification
 */
public class NotificationFragmentTab extends LoadDataFragment {

    private static Context mContext;
    private static View view;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.notification_list)
    RecyclerView mRecyclerView;
    @BindView(R.id.swipe_to_refresh)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @BindView(R.id.no_notification_view)
    AppCompatTextView mNoNotificationView;
    @BindView(R.id.fab)
    FloatingActionButton mFloatingButton;
    @BindView(R.id.adView)
    AdView mAdView;
    @BindString(R.string.web_service_for_get_notification)
    String mGetNotificationUrl;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.web_service_for_delete_notification)
    String deleteNotificationUrl;
    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @BindString(R.string.notification_only_for_paid)
    String mNotificationAvailableForPaid;
    @BindString(R.string.no_notification_label)
    String mNoNotificationLabel;
    @BindString(R.string.email_address)
    String mEmailAddress;
    @BindString(R.string.email_us_feedback_for)
    String mEmailFeedbackFor;
    @BindString(R.string.app_name)
    String mAppName;
    @BindString(R.string.email_us_application_android)
    String mApplicationOnAndroid;
    @BindString(R.string.notification_only_available_on_library_app)
    String mNotificationMessageForSingleApp;
    @BindString(R.string.coach_mail_string)
    String mCoachMailSubject;
    @BindString(R.string.write_to_coach)
    String mWriteToCoach;
    @BindDimen(R.dimen.ic_clear_margin)
    int xMarkMargin;

    @Inject
    Gson mGson;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    EventBus mEventBus;
    boolean mIsAlreadyPurchase;
    private String mParamName, mSlugUrl, mMethodType, mDeleteNotificationUrl;
    private int mNumberOfMore = 0;
    private NotificationAdapter mNotificationAdapter;
    private Unbinder mUnBinder;
    private boolean isAccessTokenExpire, isGetMoreData;
    private boolean isSwipeToReferesh;
    private int mTotalNumberOfUnReadNotification = 0;
    private boolean mIsEventBusCalling;
    private String mVersionName;
    private int mVersionCode;
    boolean mIsNotificationPaymentCheckComplete;
    /**
     * Adapter Listener
     */
    private NotificationAdapter.NotificationAdapterInterface notificationAdapterListener = new NotificationAdapter.NotificationAdapterInterface() {

        @Override
        public void getMoreCategory(int offset) {
            isGetMoreData = true;
            loadNotificationList(offset);
        }

        @Override
        public void categoryItemClick(String categoryId, String categoryTitle) {
            new BaseNavigator().navigateToAllCourses(mContext, categoryId, categoryTitle);
        }

        @Override
        public void deleteNotification(String relationId) {
            deleteNotificationListWebService(relationId, deleteNotificationUrl, SalesUConstants.POST_METHOD_TYPE);
        }
    };


    /**
     * For return AllCategoriesFragment object
     *
     * @param context activity context
     * @return instance of AllCategoriesFragment
     */
    public static NotificationFragmentTab newInstance(Context context) {
        mContext = context;
        return new NotificationFragmentTab();
    }

    private void setScrollListener() {

    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.notification_fragment, container, false);
        mUnBinder = ButterKnife.bind(this, view);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadNotificationList(0);
                isSwipeToReferesh = true;
            }
        });
        return view;
    }

    /**
     * For initialize component,setup UI and calling web service
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(mContext!=null) {
            initializeComponent();
            setUpUi();
            setSwipeForRecyclerView();
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item = menu.findItem(R.id.search_icon);
        item.setVisible(false);
        super.onPrepareOptionsMenu(menu);
    }

    /**
     * To call category web service
     *
     * @param offset offset number
     */
    private void loadNotificationList(int offset) {
        if (SalesUConstants.IS_INDIVIDUAL_APP) {
            mNoNotificationView.setText(mNotificationMessageForSingleApp);
            mNoNotificationView.setVisibility(View.VISIBLE);
            mRecyclerView.setVisibility(View.GONE);
            mFloatingButton.setVisibility(View.GONE);
            if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                mSwipeRefreshLayout.setRefreshing(false);
            }
        } else {
            mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
            if (mIsAlreadyPurchase) {
                mRecyclerView.setVisibility(View.VISIBLE);
                if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                    mGlobalApp.notificationItems = null;
                } else {
                    showLoading();
                }
                callNotificationListWebService("na", mGetNotificationUrl + "?limit=" + SalesUConstants.REQUEST_MAX_LIMIT_DATA + "&offset=" + offset + "&is_read=0", SalesUConstants.GET_METHOD_TYPE);
            } else {
                mNoNotificationView.setText(mNotificationAvailableForPaid);
                mNoNotificationView.setVisibility(View.VISIBLE);
                mRecyclerView.setVisibility(View.GONE);
                hideLoading();
                if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                    mSwipeRefreshLayout.setRefreshing(false);
                }

            }
        }
    }

    /**
     * SetUp Ui and Adapter
     */
    private void setUpUi() {
        showLoading();
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mNotificationAdapter = new NotificationAdapter(mContext, new ArrayList<NotificationModelInfo>(), mRecyclerView);
        mNotificationAdapter.setOnItemClickListener(notificationAdapterListener);
        mRecyclerView.setAdapter(mNotificationAdapter);
    }

    /**
     * Response of category webservice
     *
     * @param response response of web service
     */
    public void notificationWebServiceResponse(String response) {
        if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
            mSwipeRefreshLayout.setRefreshing(false);
        }
        hideLoading();
        boolean isLoadMore = false;
        try {
            NotificationModel notificationModel = mGson.fromJson(response, NotificationModel.class);
            if (mGlobalApp.notificationItems == null) {
                mGlobalApp.notificationItems = notificationModel.data.notifications;

                if (mGlobalApp.notificationItems.size() > 0) {
                    mNoNotificationView.setVisibility(View.GONE);
                    if (!isSwipeToReferesh) {

                        for (int i = 0; i < mGlobalApp.notificationItems.size(); i++) {
                            NotificationModelInfo notificationModelInfo = mGlobalApp.notificationItems.get(i);
                            if (notificationModelInfo.is_read.equalsIgnoreCase(SalesUConstants.NOTIFICATION_UNREAD_TAG)) {
                                ++mTotalNumberOfUnReadNotification;
                            }

                        }
                        if (!mIsEventBusCalling) {
                            mEventBus.post(new NotificationEvent(String.valueOf(mTotalNumberOfUnReadNotification)));
                        } else {
                            mIsEventBusCalling = false;
                        }
                    }

                } else {
                    mNoNotificationView.setText(mNoNotificationLabel);
                    mNoNotificationView.setVisibility(View.VISIBLE);
                }
            } else {
                isLoadMore = true;
                mGlobalApp.notificationItems.addAll(notificationModel.data.notifications);
            }

            mNotificationAdapter.setNotificationCollection(mGlobalApp.notificationItems, isLoadMore);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
            if (SalesUConstants.ISLogVisible)
                Timber.e(ex.getMessage());
        }


    }


    /**
     * Initialize Dagger Component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    /**
     * register event bus
     */
    @Override
    public void onStart() {
        super.onStart();
        if (!mEventBus.isRegistered(this)) {
            mEventBus.register(this);
        }

    }

    /**
     * call All Courses Web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callNotificationListWebService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new GetNotificationListItem().execute();
        } else {
            if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                mSwipeRefreshLayout.setRefreshing(false);
            }
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * delete notification Web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void deleteNotificationListWebService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            NotificationDeleteRequest notificationdeleteRequest = new NotificationDeleteRequest();
            notificationdeleteRequest.relation_id = paramName;
            String updateProfileJsonRequest = mGson.toJson(notificationdeleteRequest);
            mParamName = updateProfileJsonRequest;
            mDeleteNotificationUrl = path;
            mMethodType = methodType;
            new DeleteNotificationWebServices().execute();
        } else {
            if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                mSwipeRefreshLayout.setRefreshing(false);
            }
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnBinder.unbind();
        mEventBus.unregister(this);
        if (mGlobalApp.notificationItems != null) {
            mGlobalApp.notificationItems = null;
        }
    }

    /**
     * Event for section
     *
     * @param notificationReadEvent
     */
    public void onEvent(NotificationReadEvent notificationReadEvent) {
        mIsEventBusCalling = true;
        if (mGlobalApp.notificationItems != null) {
            mGlobalApp.notificationItems = null;
        }
        loadNotificationList(0);
    }

    public void onEvent(NotificationPaymentCheck notificationPaymentCheck) {
        mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
        hideLoading();
        if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);
        } else {
            mAdView.setVisibility(View.GONE);
        }
        mIsNotificationPaymentCheckComplete=true;
        if (SalesUConstants.IS_INDIVIDUAL_APP) {
            mNoNotificationView.setText(mNotificationMessageForSingleApp);
            mNoNotificationView.setVisibility(View.VISIBLE);
            mRecyclerView.setVisibility(View.GONE);
            mFloatingButton.setVisibility(View.GONE);
        } else {
            if (!mIsAlreadyPurchase) {
                mNoNotificationView.setText(mNotificationAvailableForPaid);
                mNoNotificationView.setVisibility(View.VISIBLE);
                mRecyclerView.setVisibility(View.GONE);
                mFloatingButton.setVisibility(View.GONE);
            } else {
                mRecyclerView.setVisibility(View.VISIBLE);
                mFloatingButton.setVisibility(View.VISIBLE);
                if (mGlobalApp.notificationItems != null) {
                    mGlobalApp.notificationItems = null;
                }
                loadNotificationList(0);
            }
        }
    }

    public void setSwipeForRecyclerView() {
        SwipeUtil swipeHelper = new SwipeUtil(0, ItemTouchHelper.LEFT, getActivity(), xMarkMargin) {
            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                int swipedPosition = viewHolder.getAdapterPosition();
                NotificationAdapter adapter = (NotificationAdapter) mRecyclerView.getAdapter();
                adapter.pendingRemoval(swipedPosition);
            }

            @Override
            public int getSwipeDirs(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
                int position = viewHolder.getAdapterPosition();
                NotificationAdapter adapter = (NotificationAdapter) mRecyclerView.getAdapter();
                if (adapter.isPendingRemoval(position)) {
                    return 0;
                }
                return super.getSwipeDirs(recyclerView, viewHolder);
            }
        };

        ItemTouchHelper mItemTouchHelper = new ItemTouchHelper(swipeHelper);
        mItemTouchHelper.attachToRecyclerView(mRecyclerView);

        //set swipe label
        swipeHelper.setLeftSwipeLable("Delete");
        //set swipe background-Color
        swipeHelper.setLeftcolorCode(ContextCompat.getColor(getActivity(), R.color.swipebg));

    }

    private void deleteNotificationWebServiceResponse(String s) {
        try {
            DeleteWebServiceResponse deleteWebServiceResponse = mGson.fromJson(s, DeleteWebServiceResponse.class);
            if (deleteWebServiceResponse != null) {
                Toast.makeText(mContext, deleteWebServiceResponse.message[0], Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ex) {
            Timber.e(ex.toString());
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        }

    }


    @OnClick(R.id.fab)
    public void floatingButtonClick() {
        try {
            Toast.makeText(mContext,mWriteToCoach,Toast.LENGTH_SHORT).show();
            PackageInfo pInfo = mContext.getPackageManager().getPackageInfo(mContext.getPackageName(), 0);
            if (pInfo != null) {
                mVersionName = pInfo.versionName;
                mVersionCode = pInfo.versionCode;
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        String versionCode = android.os.Build.VERSION.RELEASE;
        String emailBody = "";
        if (mVersionName != null) {
            emailBody = "Hi\n\nMy Device Specification\nVersion Name: " + mVersionName + "\nVersion Code: " + mVersionCode + "\n"
                    + "OS Version: " + versionCode + "\nPhone Manufacture: " + JavaUtil.getDeviceName() + "\n";
        } else {

        }
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.email_id!=null) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("mailto:" + mGlobalApp.appSettingModel.data.settings.email_id));
            intent.putExtra(Intent.EXTRA_SUBJECT, mCoachMailSubject);
            // intent.putExtra(Intent.EXTRA_TEXT, emailBody);
            startActivity(intent);
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {

            if (mAdView != null && mIsNotificationPaymentCheckComplete && mSharedPreference != null) {
                boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

                if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                    AdRequest adRequest = new AdRequest.Builder().build();
                    mAdView.loadAd(adRequest);
                } else {
                    mAdView.setVisibility(View.GONE);
                }
            }
        }
        if (getView() != null) {
          /*  mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
            if (!mIsAlreadyPurchase) {
                mNoNotificationView.setText(mNotificationAvailableForPaid);
                mNoNotificationView.setVisibility(View.VISIBLE);
                mRecyclerView.setVisibility(View.GONE);
            } else {
                mRecyclerView.setVisibility(View.VISIBLE);
                if (mGlobalApp.notificationItems != null) {
                    mGlobalApp.notificationItems = null;
                }
                loadNotificationList(0);
            }*/

        }
    }

    /**
     * To Call Async Web Service
     */
    class GetNotificationListItem extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new GetNotificationListItem().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new GetNotificationListItem().execute();
                    } else {
                        notificationWebServiceResponse(s);
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }
    }

    private class DeleteNotificationWebServices extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mDeleteNotificationUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new DeleteNotificationWebServices().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new DeleteNotificationWebServices().execute();
                    } else {
                        deleteNotificationWebServiceResponse(s);
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }

    }
}
