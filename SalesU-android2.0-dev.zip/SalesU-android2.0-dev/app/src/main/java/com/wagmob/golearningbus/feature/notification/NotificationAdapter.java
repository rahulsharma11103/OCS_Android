package com.wagmob.golearningbus.feature.notification;

import android.content.Context;
import android.os.Handler;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.NotificationModelInfo;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.DateTimeUtil;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindColor;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Adapter for notification.
 */

public class NotificationAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    Context mContext;
    List<NotificationModelInfo> mNotificationCollection;
    private List<NotificationModelInfo> itemsPendingRemoval;
    private RecyclerView mRecyclerView;
    LinearLayoutManager mLinearLayoutManager;
    private int mVisibleThreshold = 2;
    private int mLastVisibleItem, mTotalItemCount;
    private boolean mLoading;
    int mNumberOfLoadMore = 1;
    boolean isCurrentWebServiceCalling;
    private Handler handler = new Handler();
    HashMap<NotificationModelInfo, Runnable> pendingRunnables = new HashMap<>();
    NotificationAdapter.NotificationAdapterInterface mNotificationAdapterInterface;

    /**
     * Interface for Adapter
     */
    public interface NotificationAdapterInterface {
        void getMoreCategory(int offset);

        void categoryItemClick(String categoryId, String categoryTitle);

        void deleteNotification(String relationId);
    }

    /**
     * Constructor for Adapter, here we also call listener for pagination
     *
     * @param context               current activity context
     * @param notificationModelInfo list of notification item
     * @param recyclerView          reference of recycler view
     */
    public NotificationAdapter(Context context, List<NotificationModelInfo> notificationModelInfo, RecyclerView recyclerView) {
        mRecyclerView = recyclerView;
        mContext = context;
        mNotificationCollection = notificationModelInfo;
        if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {
            mLinearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        }
        itemsPendingRemoval = new ArrayList<>();
        setScrollListener();
    }

    /**
     * Logic of pagination
     * if total list item is 10 and current focus item is 8 then we call web service for load more items
     */
    private void setScrollListener() {
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                mTotalItemCount = mLinearLayoutManager.getItemCount();
                mLastVisibleItem = mLinearLayoutManager.findLastVisibleItemPosition();
                if (mNotificationCollection.size() < 10 * mNumberOfLoadMore) {
                    mLoading = true;
                }
                if (!isCurrentWebServiceCalling && !mLoading && (mTotalItemCount <= mLastVisibleItem + mVisibleThreshold)) {
                    isCurrentWebServiceCalling = true;
                    mNotificationAdapterInterface.getMoreCategory(mNotificationCollection.size());
                }

            }
        });
    }

    public void setOnItemClickListener(NotificationAdapter.NotificationAdapterInterface notificationAdapterInterface) {
        mNotificationAdapterInterface = notificationAdapterInterface;
    }

    /**
     * Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.
     * This new ViewHolder should be constructed with a new View that can represent the items of the given type.
     * You can either create a new View manually or inflate it from an XML layout file.
     *
     * @param parent
     * @param viewType
     * @return Recycler view holder
     */
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.notification_list_item_frame, parent, false);
        viewHolder = new NotificationViewHolder(view);
        return viewHolder;
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     * This method should update the contents of the itemView to reflect the item at the given position.
     *
     * @param holder   Recycler view holder
     * @param position position of current item
     */
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        NotificationViewHolder notificationViewHolder = (NotificationViewHolder) holder;
        configureNotificationViewHolder(notificationViewHolder, position);
    }

    private void configureNotificationViewHolder(NotificationViewHolder notificationViewHolder, int position) {
        final NotificationModelInfo notificationModelInfo = mNotificationCollection.get(position);

        if (itemsPendingRemoval != null && itemsPendingRemoval.contains(notificationModelInfo)) {
            /** {show swipe layout} and {hide regular layout} */
            notificationViewHolder.mNotificationItemLayout.setVisibility(View.GONE);
            notificationViewHolder.swipeLayout.setVisibility(View.VISIBLE);
            notificationViewHolder.undo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    undoOpt(notificationModelInfo);
                }
            });
            notificationViewHolder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    remove(mNotificationCollection.indexOf(notificationModelInfo));
                    mNotificationAdapterInterface.deleteNotification(notificationModelInfo.relation_id);
                }
            });
        } else {
            /** {show regular layout} and {hide swipe layout} */
            notificationViewHolder.mNotificationItemLayout.setVisibility(View.VISIBLE);
            notificationViewHolder.swipeLayout.setVisibility(View.GONE);
        }
        if (notificationModelInfo.is_read.equals("1")) {
            notificationViewHolder.mNotificationItemLayout.setBackgroundColor(notificationViewHolder.mWhiteColor);
        } else {
            notificationViewHolder.mNotificationItemLayout.setBackgroundColor(notificationViewHolder.mReadNotification);
        }
        notificationViewHolder.mNotificationTitle.setText(notificationModelInfo.title);
        if(notificationModelInfo.notification_type.equalsIgnoreCase(mContext.getString(R.string.quiz_html_type)))
        {
            notificationViewHolder.mNotificationData.setVisibility(View.INVISIBLE);

        }else {
            notificationViewHolder.mNotificationData.setText(notificationModelInfo.data);
        }
        //convert unix time to local date
        String time = DateTimeUtil.getTimeAgoFromUnix(notificationModelInfo.creation_date, mContext);
        notificationViewHolder.mNotificationTime.setText(time);

        notificationViewHolder.mNotificationCancelIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mContext, "cancel", Toast.LENGTH_SHORT).show();
                // mNotificationAdapterInterface.categoryItemClick(categoriesItem.category_id);
            }
        });

        notificationViewHolder.mNotificationItemLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new BaseNavigator().navigateToNotificationDetailsScreen(mContext, notificationModelInfo);
            }
        });
    }

    /**
     * Called when load more and pagination will needed
     *
     * @param notificationModelInfos list of notification items
     * @param isLoadMoreData         if load more than return true otherwise return false
     */
    public void setNotificationCollection(List<NotificationModelInfo> notificationModelInfos, boolean isLoadMoreData) {
        mNotificationCollection = notificationModelInfos;
        if (!isLoadMoreData) {
            mNumberOfLoadMore = 1;
            mLoading = false;
            notifyDataSetChanged();
        } else {
            mNumberOfLoadMore = mNumberOfLoadMore + 1;
            isCurrentWebServiceCalling = false;
            notifyItemInserted(mNotificationCollection.size());
        }
    }

    public void pendingRemoval(int position) {
        if (mNotificationCollection != null) {
            final NotificationModelInfo data = mNotificationCollection.get(position);
            if (!itemsPendingRemoval.contains(data)) {
                itemsPendingRemoval.add(data);
                // this will redraw row in "undo" state
                notifyItemChanged(position);
                // let's create, store and post a runnable to remove the data
                Runnable pendingRemovalRunnable = new Runnable() {
                    @Override
                    public void run() {
                        undoOpt(data);
                    }
                };
                handler.postDelayed(pendingRemovalRunnable, SalesUConstants.PENDING_REMOVAL_TIMEOUT);
                pendingRunnables.put(data, pendingRemovalRunnable);
            }
        }
    }

    public void remove(int position) {
        if (mNotificationCollection != null) {
            NotificationModelInfo notificationModelInfo = mNotificationCollection.get(position);
            if (itemsPendingRemoval != null && itemsPendingRemoval.contains(notificationModelInfo)) {
                itemsPendingRemoval.remove(notificationModelInfo);
            }
            if (mNotificationCollection != null && mNotificationCollection.contains(notificationModelInfo)) {
                mNotificationCollection.remove(position);
                notifyItemRemoved(position);
            }
        }
    }

    public boolean isPendingRemoval(int position) {
        if (mNotificationCollection != null) {
            NotificationModelInfo data = mNotificationCollection.get(position);
            return itemsPendingRemoval.contains(data);
        } else {
            return false;
        }
    }

    private void undoOpt(NotificationModelInfo notificationModelInfo) {
        if (pendingRunnables != null) {
            Runnable pendingRemovalRunnable = pendingRunnables.get(notificationModelInfo);
            pendingRunnables.remove(notificationModelInfo);
            if (pendingRemovalRunnable != null)
                handler.removeCallbacks(pendingRemovalRunnable);
            itemsPendingRemoval.remove(notificationModelInfo);
            // this will rebind the row in "normal" state
            notifyItemChanged(mNotificationCollection.indexOf(notificationModelInfo));
        }
    }

    /**
     * @return list of category list
     */
    public List<NotificationModelInfo> getNotificationCollection() {
        return mNotificationCollection;
    }

    /**
     * This method return number of item, if list is null then it return 0
     *
     * @return if list is not null then it return number of list items otherwise it return 0
     */
    @Override
    public int getItemCount() {
        return (mNotificationCollection != null) ? mNotificationCollection.size() : 0;
    }

    /**
     * For binding view item
     */
    static class NotificationViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.notification_remove_icon)
        AppCompatImageView mNotificationCancelIcon;

        @BindView(R.id.notification_title)
        AppCompatTextView mNotificationTitle;

        @BindView(R.id.notification_data)
        AppCompatTextView mNotificationData;

        @BindView(R.id.notification_time)
        AppCompatTextView mNotificationTime;

        @BindView(R.id.notification_list_layout)
        RelativeLayout mNotificationItemLayout;

        @BindView(R.id.swipeLayout)
        public RelativeLayout swipeLayout;

        @BindColor(R.color.read_notification)
        int mReadNotification;

        @BindColor(R.color.whiteColor)
        int mWhiteColor;

        @BindView(R.id.undo)
        public TextView undo;

        @BindView(R.id.delete)
        public TextView delete;

        public NotificationViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }
}
