package com.wagmob.golearningbus.feature.me;

import android.content.Context;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.RelativeLayout;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.model.CategoriesItem;
import com.wagmob.golearningbus.model.MyAchievementCertificate;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.util.ImageUtil;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by rahul sharma on 6/5/2017.
 */

public class MyAchievementsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    Context mContext;
    List<MyAchievementCertificate> mMyAchievementCertificates;
    LinearLayoutManager mLinearLayoutManager;
    int mNumberOfLoadMore = 1;
    boolean isCurrentWebServiceCalling;
    MyAchievementAdapterInterface mMyAchievementAdapterInterface;
    private RecyclerView mRecyclerView;
    private int mVisibleThreshold = 2;
    private int mLastVisibleItem, mTotalItemCount;
    private boolean mLoading;

    public MyAchievementsAdapter(Context context, List<MyAchievementCertificate> myAchievementCertificates, RecyclerView recyclerView) {
        mContext = context;
        mMyAchievementCertificates = myAchievementCertificates;
        mRecyclerView = recyclerView;
        if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {
            mLinearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        }
        setScrollListener();
    }

    /**
     * Logic of pagination
     * if total list item is 10 and current focus item is 8 then we call web service for load more items
     */
    private void setScrollListener() {
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                mTotalItemCount = mLinearLayoutManager.getItemCount();
                mLastVisibleItem = mLinearLayoutManager.findLastVisibleItemPosition();
                if (mMyAchievementCertificates.size() < 10 * mNumberOfLoadMore) {
                    mLoading = true;
                }
                if (!isCurrentWebServiceCalling && !mLoading && (mTotalItemCount <= mLastVisibleItem + mVisibleThreshold)) {
                    isCurrentWebServiceCalling = true;
                    mMyAchievementAdapterInterface.getMoreCategory(mMyAchievementCertificates.size());
                }

            }
        });
    }

    public void initializeAdapterInterface(MyAchievementAdapterInterface myAchievementAdapterInterface) {
        mMyAchievementAdapterInterface = myAchievementAdapterInterface;
    }

    /**
     * Called when RecyclerView needs a new { ViewHolder} of the given type to represent
     * an item.
     * <p>
     * This new ViewHolder should be constructed with a new View that can represent the items
     * of the given type. You can either create a new View manually or inflate it from an XML
     * layout file.
     * <p>
     * The new ViewHolder will be used to display items of the adapter using
     * { #onBindViewHolder(ViewHolder, int, List)}. Since it will be re-used to display
     * different items in the data set, it is a good idea to cache references to sub views of
     * the View to avoid unnecessary @link View#findViewById(int)} calls.
     *
     * @param parent   The ViewGroup into which the new View will be added after it is bound to
     *                 an adapter position.
     * @param viewType The view type of the new View.
     * @return A new ViewHolder that holds a View of the given view type.
     * @see #getItemViewType(int)
     * #onBindViewHolder(ViewHolder, int)
     */
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.my_achievement_list, parent, false);
        viewHolder = new MyAchievementViewHolder(view);
        return viewHolder;
    }

    /**
     * Called by RecyclerView to display the data at the specified position. This method should
     * update the contents of the { ViewHolder#itemView} to reflect the item at the given
     * position.
     * <p>
     * Note that unlike {@link ListView}, RecyclerView will not call this method
     * again if the position of the item changes in the data set unless the item itself is
     * invalidated or the new position cannot be determined. For this reason, you should only
     * use the <code>position</code> parameter while acquiring the related data item inside
     * this method and should not keep a copy of it. If you need the position of an item later
     * on (e.g. in a click listener), use { ViewHolder#getAdapterPosition()} which will
     * have the updated adapter position.
     * <p>
     * Override { #onBindViewHolder(ViewHolder, int, List)} instead if Adapter can
     * handle efficient partial bind.
     *
     * @param holder   The ViewHolder which should be updated to represent the contents of the
     *                 item at the given position in the data set.
     * @param position The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MyAchievementViewHolder myAchievementViewHolder = (MyAchievementViewHolder) holder;
        configureViewHolder(myAchievementViewHolder, position);
    }

    private void configureViewHolder(MyAchievementViewHolder myAchievementViewHolder, int position) {
        final MyAchievementCertificate myAchievementCertificate = mMyAchievementCertificates.get(position);
        myAchievementViewHolder.mMyAchievementCourseName.setText(myAchievementCertificate.title);
        ImageUtil.getInstance().loadImage(mContext, myAchievementCertificate.image_url, myAchievementViewHolder.mMyAchievementCourseImage, R.drawable.placeholder_default_rectangular, false, true);
        myAchievementViewHolder.mCertificateView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_NAME_MY_ACHIEVEMENT_COURSE_CLICK);
                new BaseNavigator().navigateToCertificateScreen(mContext,myAchievementCertificate.certificate_url);
            }
        });
    }

    /**
     * Returns the total number of items in the data set held by the adapter.
     *
     * @return The total number of items in this adapter.
     */
    @Override
    public int getItemCount() {
        return (mMyAchievementCertificates != null) ? mMyAchievementCertificates.size() : 0;
    }

    /**
     * Called when load more and pagination will needed
     *
     * @param categoryCollection list of category items
     * @param isLoadMoreData     if load more than return true otherwise return false
     */
    public void setAchievementCollection(List<MyAchievementCertificate> categoryCollection, boolean isLoadMoreData) {
        mMyAchievementCertificates = categoryCollection;
        if (!isLoadMoreData) {
            mNumberOfLoadMore = 1;
            mLoading = false;
            notifyDataSetChanged();
        } else {
            mNumberOfLoadMore = mNumberOfLoadMore + 1;
            isCurrentWebServiceCalling = false;
            notifyItemInserted(mMyAchievementCertificates.size());
        }
    }

    /**
     * Called when load more and pagination will needed
     * /
     * public void setAchievementCollection(List<MyAchievementCertificate> myAchievementCertificates,boolean isLoadMoreData)
     * {
     * mMyAchievementCertificates = myAchievementCertificates;
     * if (!isLoadMoreData) {
     * mNumberOfLoadMore = 1;
     * mLoading = false;
     * notifyDataSetChanged();
     * } else {
     * mNumberOfLoadMore = mNumberOfLoadMore + 1;
     * isCurrentWebServiceCalling = false;
     * notifyItemInserted(mMyAchievementCertificates.size());
     * }
     * }
     * <p>
     * /**
     *
     * @return list of category list
     */
    public List<MyAchievementCertificate> getCategoryCollection() {
        return mMyAchievementCertificates;
    }

    public interface MyAchievementAdapterInterface {
        void getMoreCategory(int offset);
    }

    static class MyAchievementViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.my_achievement_course_image)
        AppCompatImageView mMyAchievementCourseImage;

        @BindView(R.id.course_name)
        AppCompatTextView mMyAchievementCourseName;

        @BindView(R.id.certificate_layout)
        RelativeLayout mCertificateView;

        public MyAchievementViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
