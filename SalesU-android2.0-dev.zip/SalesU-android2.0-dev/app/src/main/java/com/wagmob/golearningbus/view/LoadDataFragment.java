package com.wagmob.golearningbus.view;


import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.RelativeLayout;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.constants.SalesUConstants;

import butterknife.BindView;
import timber.log.Timber;

/**
 * Common Fragment for all other fragment for showing progress bar
 */
public class LoadDataFragment extends BaseFragment implements LoadDataView {
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;

    @Override
    public void showLoading() {
        if (SalesUConstants.ISLogVisible) {
            Timber.d("called  showLoading  !");
        }
        try {
            mProgressBarLayout.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            Timber.e("Exception when trying to show loading: " + e);
        }
        FragmentActivity fragmentActivity = getActivity();
        if (fragmentActivity != null) {
            fragmentActivity.setProgressBarIndeterminateVisibility(true);
        }
    }

    @Override
    public void hideLoading() {
        if (SalesUConstants.ISLogVisible) {
            Timber.d("called  hideLoading  !");
        }
        try {
            mProgressBarLayout.setVisibility(View.GONE);
        } catch (Exception e) {
            Timber.e("Exception when trying to hide loading: " + e);
        }
        FragmentActivity fragmentActivity = getActivity();
        if (fragmentActivity != null) {
            fragmentActivity.setProgressBarIndeterminateVisibility(false);
        }
    }

    @Override
    public void showRetry() {

    }

    @Override
    public void hideRetry() {

    }

    @Override
    public void showError(String message) {

    }

    @Override
    public void showOfflineError() {

    }

    @Override
    public Context getViewContext() {
        return null;
    }
}
