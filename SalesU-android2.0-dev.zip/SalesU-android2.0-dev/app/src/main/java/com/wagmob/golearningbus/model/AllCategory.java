package com.wagmob.golearningbus.model;

public class AllCategory {
    public boolean error;
    public int response_code;
    public String message[];
    public Category data;

}
