/*
package com.wagmob.golearningbus.feature.quiz;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.view.BaseActivity;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

*/
/**
 * Activity class for show quiz
 *
 * @author Rahul Sharma
 *//*

public class QuizActivity extends BaseActivity {

    public AlertDialog myAlertDialog;
    @BindView(R.id.toolbar)
    Toolbar mToolBar;

    @Inject
    SalesUApplication mGlobalApp;

    @BindString(R.string.network_message)
    String mNetworkMessage;

    @BindString(R.string.quiz_exit_message)
    String mQuizExitMessage;

    @BindString(R.string.quiz_dialog_positive_button)
    String mQuizPositiveButton;

    @BindString(R.string.quiz_dialog_negative_button)
    String mQuizNegativeButton;

    Context mContext;
    QuizFragment mQuizFragment;
    boolean isQuizPause;
    boolean isDialogOpen;
    String mAssignmentId;
    private Unbinder mUnBinder;

    public static Intent callingIntent(Context context) {
        return new Intent(context, QuizActivity.class);
    }

    */
/**
     * Use to initialize layout and App bar
     *
     * @param savedInstanceState
     *//*

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_common);
        mUnBinder = ButterKnife.bind(this);
        initializeComponent();
        setSupportActionBar(mToolBar);
        ActionBar actionBar = getSupportActionBar();
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.color_primary_hex != null) {
            actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex)));
        }
        actionBar.setDisplayHomeAsUpEnabled(true);
        mAssignmentId = getIntent().getStringExtra(SalesUConstants.ASSIGNMENT_ID);
        initializeFragment();
    }

    */
/**
     * Add fragment to activity
     *//*

    private void initializeFragment() {
        //  mQuizFragment = new QuizFragment().newInstance(mContext, mAssignmentId,false);
        addFragment(R.id.fragment_common_container, mQuizFragment);
    }

    */
/**
     * Initialize Dagger Component
     *//*

    private void initializeComponent() {
        ((SalesUApplication) this.getApplication()).getApplicationModule().inject(this);
    }

    */
/**
     * To show dialog when user quit quiz
     *
     * @param item menu item
     * @return selected menu item
     *//*

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home: {
                showAlertDialog();
                //     overridePendingTransition(R.anim.activity_transition_stay_still, R.anim.activity_transition_out);
                break;

            }
        }

        return super.onOptionsItemSelected(item);
    }

    */
/**
     * To show dialog when user quit quiz
     *//*

    @Override
    public void onBackPressed() {
        showAlertDialog();
    }

    */
/**
     * display dialog box
     *//*

    public void showAlertDialog() {
        isDialogOpen = true;
        AlertDialog.Builder dialog = new AlertDialog.Builder(mContext);
        dialog.setMessage(mQuizExitMessage);
        dialog.setCancelable(false);
        dialog.setPositiveButton(mQuizPositiveButton, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });

        dialog.setNegativeButton(mQuizNegativeButton, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                isDialogOpen = false;
                dialog.dismiss();
                if (mQuizFragment != null)
                    mQuizFragment.setTimerHelper(mGlobalApp.quizCurrentTime);
            }
        });
        if (mQuizFragment != null && mQuizFragment.mCountDownTimer != null)
            mQuizFragment.mCountDownTimer.cancel();
        myAlertDialog = dialog.create();

        myAlertDialog.show();
    }

    */
/**
     * quiz resume(resume timer)
     *//*

    @Override
    public void onResume() {
        super.onResume();
        if (!isDialogOpen)
            if (isQuizPause) {
                mQuizFragment.setTimerHelper(mGlobalApp.quizCurrentTime);
                isQuizPause = false;
            }
    }

    */
/**
     * quiz pause(stop timer)
     *//*

    @Override
    public void onPause() {
        super.onPause();
        isQuizPause = true;
        if (mQuizFragment != null && mQuizFragment.mCountDownTimer != null)
            mQuizFragment.mCountDownTimer.cancel();

    }

}
*/
