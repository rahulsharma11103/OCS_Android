package com.wagmob.golearningbus.model;

public class CategoriesItem {
    public String category_id;
    public String title;
    public String description;
    public String image_url;
    public int course_count;
}
