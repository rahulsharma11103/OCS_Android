package com.wagmob.golearningbus.feature.forgot_password;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.ForgotPasswordModel;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.requestModel.ForgotPasswordRequestModel;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONException;
import org.json.JSONObject;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import timber.log.Timber;

/**
 * Fragment for forgot password
 *
 * @author Rahul Sharma.
 */

public class ForgotPasswordFragment extends LoadDataFragment {
    static Context mContext;
    @BindView(R.id.otp)
    AppCompatEditText mOtpView;
    @BindView(R.id.new_current_password)
    AppCompatEditText mNewPasswordView;
    @BindView(R.id.re_type_password)
    AppCompatEditText mRetypePasswordView;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.otp_password_layout)
    RelativeLayout mOtpScreenLayout;
    @BindView(R.id.user_email)
    AppCompatEditText mUserEmailView;
    @BindView(R.id.forgot_password_layout)
    RelativeLayout mForgotPasswordLayout;
    @BindView(R.id.reset_password_button_layout)
    AppCompatButton mResetPasswordButton;
    @BindView(R.id.change_password_button_layout)
    AppCompatButton mChangePasswordButton;


    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.web_service_for_forgot_password)
    String mWebServiceForForgotPassword;
    @BindString(R.string.web_service_update_password_using_otp)
    String mWebServiceForUpdatePasswordUsingOtp;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.empty_field_message)
    String mEmptyMessage;
    @BindString(R.string.minimum_password_length_message)
    String mMinimumPasswordLengthMessage;
    @BindString(R.string.new_password_and_re_type_password_not_match)
    String mPasswordNotMatchMessage;
    @BindString(R.string.network_message)
    String mNetworkMessage;

    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    Gson mGson;
    String mUserEmailString;
    private Unbinder mUnbinder;
    private String mParamName, mSlugUrl, mMethodType;
    private boolean isAccessTokenExpire;
    private boolean isForgotPassword;

    /**
     * To initialize and return current fragment instance
     *
     * @param context
     * @return current fragment instance
     */
    public static ForgotPasswordFragment newInstance(Context context) {

        mContext = context;
        return new ForgotPasswordFragment();
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.forgot_password_fragment_view, container, false);
        mUnbinder = ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initializeComponent();
        if(mGlobalApp!=null) {
            setUpUi();
        }
    }

    private void setUpUi() {
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.color_primary_hex != null) {
            Drawable backgroundOne = mResetPasswordButton.getBackground();
            ((GradientDrawable) backgroundOne).setColorFilter(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex), PorterDuff.Mode.SRC_ATOP);

            Drawable backgroundTwo = mChangePasswordButton.getBackground();
            ((GradientDrawable) backgroundTwo).setColorFilter(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex), PorterDuff.Mode.SRC_ATOP);
        }
    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        if(mContext!=null)
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    @OnClick(R.id.reset_password_button_layout)
    public void submitChangePassword() {
        changePassword();
    }

    @OnClick(R.id.change_password_button_layout)
    public void changePasswordUsingOtpSubmit() {
        changePasswordUsingOtp();
    }

    private void changePasswordUsingOtp() {
        String mOtp = mOtpView.getText().toString();
        String newPassword = mNewPasswordView.getText().toString();
        String reEnterPassword = mRetypePasswordView.getText().toString();
        ForgotPasswordRequestModel forgotPasswordRequestModel = new ForgotPasswordRequestModel();
        if ((mOtp != null && !mOtp.isEmpty()) && (newPassword != null && !newPassword.isEmpty()) &&
                (reEnterPassword != null && !reEnterPassword.isEmpty()) && (mUserEmailString != null)) {
            if ((newPassword.length() > SalesUConstants.MINIMUM_PASSWORD_LENGTH)
                    && (reEnterPassword.length() > SalesUConstants.MINIMUM_PASSWORD_LENGTH)) {
                if (newPassword.equalsIgnoreCase(reEnterPassword)) {
                    showLoading();
                    forgotPasswordRequestModel.password = newPassword;
                    forgotPasswordRequestModel.otp = mOtp;
                    forgotPasswordRequestModel.email_id = mUserEmailString;
                    String paramName = mGson.toJson(forgotPasswordRequestModel);
                    isForgotPassword = true;
                    callChangePasswordService(paramName, mWebServiceForUpdatePasswordUsingOtp, SalesUConstants.POST_METHOD_TYPE);
                } else {
                    Toast.makeText(mContext, mPasswordNotMatchMessage, Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(mContext, mMinimumPasswordLengthMessage, Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(mContext, mEmptyMessage, Toast.LENGTH_SHORT).show();
        }

    }

    private void changePassword() {
        mUserEmailString = mUserEmailView.getText().toString();
        ForgotPasswordRequestModel forgotPasswordRequestModel = new ForgotPasswordRequestModel();
        if (mUserEmailString != null && !mUserEmailString.isEmpty()) {
            showLoading();
            forgotPasswordRequestModel.email_id = mUserEmailString;
            String paramName = mGson.toJson(forgotPasswordRequestModel);
            callChangePasswordService(paramName, mWebServiceForForgotPassword, SalesUConstants.POST_METHOD_TYPE);
        } else {
            Toast.makeText(mContext, mEmptyMessage, Toast.LENGTH_SHORT).show();
        }
    }


    /**
     * call Change password web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callChangePasswordService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new ChangePasswordService().execute();
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Response of Password webservice
     *
     * @param response response of web service
     */
    public void changePasswordWebServiceResponse(String response) {

        hideLoading();

        try {
            ForgotPasswordModel forgotPasswordModel = mGson.fromJson(response, ForgotPasswordModel.class);
            if (forgotPasswordModel != null && forgotPasswordModel.message != null) {
                if (!forgotPasswordModel.error) {
                    mForgotPasswordLayout.setVisibility(View.GONE);
                    mOtpScreenLayout.setVisibility(View.VISIBLE);
                }
                Toast.makeText(mContext, forgotPasswordModel.message[0], Toast.LENGTH_LONG).show();

            } else {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ex) {
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }


    }

    private void changePasswordUsingOtpResponse(String response) {
        hideLoading();

        try {
            ForgotPasswordModel forgotPasswordModel = mGson.fromJson(response, ForgotPasswordModel.class);
            if (forgotPasswordModel != null && forgotPasswordModel.message != null) {
                if (!forgotPasswordModel.error) {
                    new BaseNavigator().navigateToLoginActivity(mContext);
                }
                Toast.makeText(mContext, forgotPasswordModel.message[0], Toast.LENGTH_LONG).show();

            } else {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ex) {
            Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }

    }


    /**
     * unbind butter knife
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }

    /**
     * To Call Async Web Service
     */
    class ChangePasswordService extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new ChangePasswordService().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new ChangePasswordService().execute();
                    } else {
                        if (!isForgotPassword) {
                            changePasswordWebServiceResponse(s);
                        } else {
                            changePasswordUsingOtpResponse(s);
                        }
                    }
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_INVALID_PASSWORD_CODE) {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_INVALID_USER_ID) {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                hideLoading();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }
    }


}
