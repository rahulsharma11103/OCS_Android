package com.wagmob.golearningbus.feature.notification_detail;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.NotificationModelInfo;
import com.wagmob.golearningbus.view.BaseActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Activity for Notification
 * @author Rahul Sharma.
 */

public class NotificationsDetailsActivity extends BaseActivity{
    @BindView(R.id.toolbar)
    Toolbar mToolBar;


    Context mContext;
    private Unbinder mUnBinder;
    private NotificationDetailsFragment mNotificationDetailsFragment;
    private NotificationModelInfo mNotificationModelInfo;


    /**
     * @param context current activity context
     * @return intent of activity
     */
    public static Intent callingIntent(Context context) {
        return new Intent(context, NotificationsDetailsActivity.class);
    }

    /**
     * Use to initialize layout and App bar
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_common);
        mUnBinder = ButterKnife.bind(this);
        mNotificationModelInfo=(NotificationModelInfo)getIntent().getSerializableExtra(SalesUConstants.NOTIFICATION_MODEL_INFO);
        setSupportActionBar(mToolBar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        if(mNotificationModelInfo!=null&&mNotificationModelInfo.title!=null) {
            actionBar.setTitle(mNotificationModelInfo.title);
        }
        initializeFragment();
    }

    /**
     * Add fragment to activity
     */
    private void initializeFragment() {
        mNotificationDetailsFragment = NotificationDetailsFragment.newInstance(mContext,mNotificationModelInfo);
        addFragment(R.id.fragment_common_container, mNotificationDetailsFragment);
    }

    /**
     * unbind butter knife object
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mUnBinder.unbind();
    }

    /**
     * menu option selection
     *
     * @param item
     * @return menu item
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home: {
                finish();
                overridePendingTransition(R.anim.activity_transition_stay_still, R.anim.activity_transition_out);
                break;

            }

        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_item, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem item=menu.findItem(R.id.search_icon);
        item.setVisible(false);
        return super.onPrepareOptionsMenu(menu);
    }
}
