package com.wagmob.golearningbus.feature.login;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.view.BaseActivity;
import com.wagmob.golearningbus.webservice_helper.AsyncRequest;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Activity for login activity
 *
 * @author Rahul Sharma
 */
public class LoginActivity extends BaseActivity implements LoginFragment.LoginFragmentInterface, AsyncRequest.OnAsyncRequestComplete {

    private final String CLASSNAME = this.getClass().getSimpleName();
    @BindView(R.id.toolbar)
    Toolbar mToolBar;

    @Inject
    SalesUApplication mGlobalApp;

    @BindString(R.string.network_message)
    String mNetworkMessage;

    Context mContext;
    LoginFragment mLoginFragment;
    private Unbinder mUnBinder;
    private String mEmailId;
    private String mPassword;

    public static Intent callingIntent(Context context) {
        return new Intent(context, LoginActivity.class);
    }

    /**
     * Use to initialize layout and App bar
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_common);
        mUnBinder = ButterKnife.bind(this);
        mToolBar.setVisibility(View.GONE);
        setSupportActionBar(mToolBar);
        initializeComponent();
        initializeFragment();
    }

    /**
     * Add fragment to activity
     */
    private void initializeFragment() {
        mLoginFragment = LoginFragment.newInstance(mContext);
        addFragment(R.id.fragment_common_container, mLoginFragment);
    }

    /**
     * Initialize Dagger Component
     */
    private void initializeComponent() {
        ((SalesUApplication) this.getApplication()).getApplicationModule().inject(this);
    }

    /**
     * unbind butter knife object
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mUnBinder.unbind();
    }

    /**
     * Call Login web service and check network connection
     *
     * @param paramName  parameter name with value
     * @param url        url of login web service
     * @param methodType method type
     */
    @Override
    public void callWebService(String paramName, String url, String methodType, String googleToken,String facebookToken) {

        if (mGlobalApp.isNetworkAvailable()) {
            new AsyncRequest(mContext, paramName, url, methodType, googleToken,facebookToken).execute();
        } else {
            mLoginFragment.hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }

    }

    /**
     * It have web service response
     *
     * @param response response of login web service
     */
    @Override
    public void asyncResponse(String response) {
        mLoginFragment.asyncLoginResponse(response);
    }
}
