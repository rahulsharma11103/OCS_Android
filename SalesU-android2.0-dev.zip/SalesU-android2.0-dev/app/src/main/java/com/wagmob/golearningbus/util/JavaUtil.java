package com.wagmob.golearningbus.util;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;
import android.view.View;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.wagmob.golearningbus.model.CoursesItems;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by Rahul on 6/20/2017.
 */

public class JavaUtil {

    public List<CoursesItems> removeAllCoursesDuplicatesItem(List<CoursesItems> coursesItem) {
        List<CoursesItems> result = new ArrayList<CoursesItems>();
        Set<CoursesItems> titles = new HashSet<CoursesItems>();

        for (CoursesItems item : coursesItem) {
            if (titles.add(item)) {
                result.add(item);
            }
        }
        return result;
    }

    public void openPlayStoreByPlayStoreUrl(Context context, String playStoreUrl) {
        try {
            context.startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(playStoreUrl)));
        } catch (Exception ex) {

        }

    }

    public boolean appInstalledOrNot(Context context, String uri) {
        PackageManager pm = context.getPackageManager();
        try {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
        }

        return false;
    }

    public int findOccurence(char a, String wholeString) {
        int position = 0;
        for (int i = 0; i < wholeString.length(); i++) {
            if (wholeString.charAt(i) == a) {
                position = i;
                break;
            }
        }
        return position;
    }

    public String getPackageName(String playStoreUrl) {
        String packageName = null;
        int location = findOccurence('=', playStoreUrl);
        packageName = playStoreUrl.substring(++location);
        return packageName;
    }

    /** Returns the consumer friendly device name */
    public static String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.startsWith(manufacturer)) {
            return capitalize(model);
        }
        return capitalize(manufacturer) + " " + model;
    }

    private static String capitalize(String str) {
        if (TextUtils.isEmpty(str)) {
            return str;
        }
        char[] arr = str.toCharArray();
        boolean capitalizeNext = true;

        StringBuilder phrase = new StringBuilder();
        for (char c : arr) {
            if (capitalizeNext && Character.isLetter(c)) {
                phrase.append(Character.toUpperCase(c));
                capitalizeNext = false;
                continue;
            } else if (Character.isWhitespace(c)) {
                capitalizeNext = true;
            }
            phrase.append(c);
        }

        return phrase.toString();
    }



}
