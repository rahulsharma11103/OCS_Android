package com.wagmob.golearningbus.feature.CommingSoon;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.view.BaseFragment;

/**
 * Created by rahul on 9/29/2017.
 */

public class ComingSoonFragment extends BaseFragment{

    ComingSoonFragment mComingSoonFragment;
    Context mContext;

    public ComingSoonFragment newInstance(Context context)
    {
        mContext=context;
        mComingSoonFragment=new ComingSoonFragment();
        return mComingSoonFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.coming_soon, container, false);
        return view;
    }

}
