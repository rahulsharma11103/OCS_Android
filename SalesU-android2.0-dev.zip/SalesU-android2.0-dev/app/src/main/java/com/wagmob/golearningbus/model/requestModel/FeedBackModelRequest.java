package com.wagmob.golearningbus.model.requestModel;



public class FeedBackModelRequest {
    public String course_id;
    public String message;
    public String points;
}
