package com.wagmob.golearningbus.feature.phrasebook;

import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.model.FlashCardModelLetters;
import com.wagmob.golearningbus.model.PhraseBookExpandableModelLetters;

import java.util.ArrayList;
import java.util.List;


public class PhrasebookListViewAdapter extends RecyclerView.Adapter<PhrasebookListViewHolder> {


    Context mContext;

    List<FlashCardModelLetters> mPhrasebookModelLetters;


    public PhrasebookListViewAdapter(Context context, List<FlashCardModelLetters> phrasebookModelLetters) {
        mContext = context;
        mPhrasebookModelLetters = phrasebookModelLetters;
    }

    @Override
    public PhrasebookListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.phrasebook_items_one_word_list, parent, false);
        return new PhrasebookListViewHolder(view);

    }

    @Override
    public void onBindViewHolder(final PhrasebookListViewHolder holder, int position) {

        final FlashCardModelLetters phraseBookModelLetters = mPhrasebookModelLetters.get(position);
        holder.mWordNameView.setText(phraseBookModelLetters.word);
        List<PhraseBookExpandableModelLetters> mPhraseBookExpandableModelLetters = new ArrayList<PhraseBookExpandableModelLetters>();
        PhraseBookExpandableModelLetters phraseBookExpandableModelLetters = new PhraseBookExpandableModelLetters();
        phraseBookExpandableModelLetters.pronunciation = phraseBookModelLetters.pronunciation;
        phraseBookExpandableModelLetters.meaning = phraseBookModelLetters.meaning;
        phraseBookExpandableModelLetters.soundfile_url = phraseBookModelLetters.soundfile_url;
        mPhraseBookExpandableModelLetters.add(phraseBookExpandableModelLetters);

        final PhrasebookExpandableListViewAdapter phrasebookExpandableListViewAdapter = new PhrasebookExpandableListViewAdapter(mContext, mPhraseBookExpandableModelLetters);
        holder.mSubSectionRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        holder.mSubSectionRecyclerView.setAdapter(phrasebookExpandableListViewAdapter);
        phrasebookExpandableListViewAdapter.collapse();
        holder.mCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (phrasebookExpandableListViewAdapter.getItemCount() > 0) {
                    phrasebookExpandableListViewAdapter.collapse();
                } else {
                    phrasebookExpandableListViewAdapter.expand();
                }
            }
        });


    }

    /**
     * To set FlashCard list
     *
     * @param flashCardModelLetters assignment list item
     */
    public void setFlashCardItems(List<FlashCardModelLetters> flashCardModelLetters) {
        mPhrasebookModelLetters = flashCardModelLetters;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return mPhrasebookModelLetters != null ? mPhrasebookModelLetters.size() : 0;
    }

}
