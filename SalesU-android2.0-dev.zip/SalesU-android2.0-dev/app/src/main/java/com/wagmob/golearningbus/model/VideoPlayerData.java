package com.wagmob.golearningbus.model;

public class VideoPlayerData {
   public VideoPlayerAssignment assignment;
}
