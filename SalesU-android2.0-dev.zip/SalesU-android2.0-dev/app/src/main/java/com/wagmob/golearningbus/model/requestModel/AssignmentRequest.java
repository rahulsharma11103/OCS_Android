package com.wagmob.golearningbus.model.requestModel;



public class AssignmentRequest {
    public String assignment_id;
}
