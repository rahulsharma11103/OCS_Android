package com.wagmob.golearningbus.feature.sections;


import android.content.Context;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.constants.JavaUtilClass;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.SectionsItems;
import com.wagmob.golearningbus.model.SubSectionsItems;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.util.PercentView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import timber.log.Timber;

/**
 * RecyclerView Adapter For showing list of All Courses
 *
 * @author Rahul Sharma
 */
public class SubsectionAdapter extends RecyclerView.Adapter<SubSectionsViewHolder> {

    private static final int ARROW_ROTATION_DURATION = 150;
    static SubsectionAdapterInterface mSubsectionAdapterInterface;
    private final List<SubSectionsItems> mTmpSubSectionItemCollection = new ArrayList<>();
    List<SectionsItems> mSectionItems;
    boolean mIsAlreadyPurchase;
    private Context mContext;
    private List<SubSectionsItems> mSubSectionItemCollection;
    private int mNumberCount;
    private PercentView mCircleProgress;
    private boolean mIsDefaultCourse;

    /**
     * To initialize context,list of subsection items
     *
     * @param context                     current activity context
     * @param courseContentItemCollection subsection list
     * @param numberCount                 number count
     */
    public SubsectionAdapter(Context context, List<SubSectionsItems> courseContentItemCollection, int numberCount, List<SectionsItems> sectionItems, boolean isAlreadyPurchase, boolean isDefaultCourse) {
        mContext = context;
        mNumberCount = numberCount;
        mSubSectionItemCollection = courseContentItemCollection;
        mSectionItems = sectionItems;
        mIsDefaultCourse = isDefaultCourse;
        mIsAlreadyPurchase = isAlreadyPurchase;
        if (courseContentItemCollection != null && courseContentItemCollection.size() > 0) {
            mTmpSubSectionItemCollection.addAll(courseContentItemCollection);
            mSubSectionItemCollection.clear();
        }
    }

    public SubsectionAdapter() {
    }

    public void initializeInterface(SubsectionAdapterInterface subsectionAdapterInterface) {
        mSubsectionAdapterInterface = subsectionAdapterInterface;
    }

    /**
     * list collapse
     *
     * @param mArrow position of arrow
     */
    public void collapse(AppCompatImageView mArrow) {
        mSubSectionItemCollection.clear();
        mNumberCount = 0;
        notifyDataSetChanged();
        if (mArrow != null) {
            mArrow.animate().setDuration(ARROW_ROTATION_DURATION).rotation(180);
        }
    }

    /**
     * List expand
     *
     * @param mArrow
     */
    public void expand(AppCompatImageView mArrow) {
        mNumberCount = 0;
        mSubSectionItemCollection.addAll(mTmpSubSectionItemCollection);
        notifyDataSetChanged();
        if (mArrow != null) {
            mArrow.animate().setDuration(ARROW_ROTATION_DURATION).rotation(0);
        }
    }

    /**
     * Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.
     * This new ViewHolder should be constructed with a new View that can represent the items of the given type.
     * You can either create a new View manually or inflate it from an XML layout file.
     *
     * @param parent
     * @param viewType
     * @return Recycler view holder
     */
    @Override
    public SubSectionsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.subsection_items, parent, false);
        mCircleProgress = (PercentView) view.findViewById(R.id.circle_progress);
        return new SubSectionsViewHolder(view);
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     * This method should update the contents of the itemView to reflect the item at the given position.
     *
     * @param holder   Recycler view holder
     * @param position position of current item
     */
    @Override
    public void onBindViewHolder(final SubSectionsViewHolder holder, int position) {
        final SubSectionsItems subSectionsItems = mSubSectionItemCollection.get(position);
        holder.mSubsectionItemName.setText(subSectionsItems.title);
        holder.mNumberCountView.setText(String.valueOf(++mNumberCount));
        String subsectionProgress = JavaUtilClass.calculatePercentage(subSectionsItems.total_assignments, subSectionsItems.completed_assignments);
        mCircleProgress.setPercentage(Integer.parseInt(subsectionProgress));
        boolean isFreeSubSection = isFreeSubsectionItems(subSectionsItems);

        if (isFreeSubSection && !mIsAlreadyPurchase) {
            holder.mTotalProgressNumberView.setTextSize(SalesUConstants.PREVIEW_TEXT_SIZE);
            if (mIsDefaultCourse) {
                holder.mTotalProgressNumberView.setText(holder.mSubFree);
            } else {
                holder.mTotalProgressNumberView.setText(holder.mSubSectionPreview);
            }
        } else if (isFreeSubSection && mIsAlreadyPurchase) {
            holder.mTotalProgressNumberView.setText(Integer.parseInt(subsectionProgress) + SalesUConstants.PERCENTAGE_SYMBOL);
        } else if (mIsAlreadyPurchase) {
            holder.mTotalProgressNumberView.setText(Integer.parseInt(subsectionProgress) + SalesUConstants.PERCENTAGE_SYMBOL);
        } else {
            if (mIsDefaultCourse) {
                holder.mTotalProgressNumberView.setTextSize(SalesUConstants.PREVIEW_TEXT_SIZE);
                holder.mTotalProgressNumberView.setText(holder.mSubFree);
            } else {
                holder.mLockImageView.setVisibility(View.VISIBLE);
            }
        }

        //For set Width Of Number of question
        ViewTreeObserver observer = holder.mSubsectionLayout.getViewTreeObserver();
        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

            @Override
            public void onGlobalLayout() {
                // TODO Auto-generated method stub
                int a = holder.mSubsectionLayout.getHeight();
                ViewGroup.LayoutParams params = holder.mSeparatorLayout.getLayoutParams();
                params.height = a;
                holder.mSeparatorLayout.setLayoutParams(params);

            }
        });

        holder.mSubsectionLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                triggerAmplitudeForSubsectionItemClicked(subSectionsItems.title);

                if (mSubsectionAdapterInterface != null && subSectionsItems != null && subSectionsItems.subsection_id != null) {

                    boolean isFreeSubSection = isFreeSubsectionItems(subSectionsItems);
                    if (isFreeSubSection) {
                        new BaseNavigator().navigateToAssignmentScreen(mContext, subSectionsItems.subsection_id, subSectionsItems.title);
                    } else {
                        mSubsectionAdapterInterface.subSectionItemClicked(subSectionsItems.subsection_id, subSectionsItems.title, mIsDefaultCourse);
                    }
                }

            }
        });
    }

    private void triggerAmplitudeForSubsectionItemClicked(String subsection_name) {
        JSONObject jElement;
        try {
            jElement = new JSONObject();
            jElement.put(AmplitudeUtil.SUBSECTION_NAME, subsection_name);
            AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_SUBSECTION_ITEM_TAPPED, jElement);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    private boolean isFreeSubsectionItems(SubSectionsItems subSectionClickedItem) {
        boolean isFreeCourse = false;
        if (mSectionItems != null && mSubSectionItemCollection != null && mSectionItems.size() > 0) {
            SectionsItems sectionsItems = mSectionItems.get(0);
            if (sectionsItems.subsections != null && sectionsItems.subsections.size() > 0) {
                SubSectionsItems subSectionsItemsOne = sectionsItems.subsections.get(0);
                if (sectionsItems.subsections.size() >= 2) {
                    SubSectionsItems subSectionsItemsTwo = sectionsItems.subsections.get(1);
                    if ((subSectionClickedItem.subsection_id.equalsIgnoreCase(subSectionsItemsOne.subsection_id)
                            || subSectionClickedItem.subsection_id.equalsIgnoreCase(subSectionsItemsTwo.subsection_id))
                            ) {
                        isFreeCourse = true;
                    } else {
                        isFreeCourse = false;
                    }
                } else {
                    if ((subSectionClickedItem.subsection_id.equalsIgnoreCase(subSectionsItemsOne.subsection_id))
                            ) {
                        isFreeCourse = true;
                    } else {
                        isFreeCourse = false;
                    }
                }
            } else {
                isFreeCourse = false;
            }
        }
        return isFreeCourse;
    }

    /**
     * This method return number of item, if list is null then it return 0
     *
     * @return if list is not null then it return number of list items otherwise it return 0
     */
    @Override
    public int getItemCount() {
        return (mSubSectionItemCollection != null) ? mSubSectionItemCollection.size() : 0;
    }

    public interface SubsectionAdapterInterface {
        public void subSectionItemClicked(String subsectionId, String assignmentTitle, boolean isDefaultCourse);
    }
}
