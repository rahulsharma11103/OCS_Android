package com.wagmob.golearningbus.feature.quiz;


import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.AppCompatRadioButton;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.webkit.WebView;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.QuizModelOptions;

import java.util.List;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Recycler view adpter for quiz option
 *
 * @author Rahul Sharma
 */
public class QuizAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    QuizAdapterInterface mQuizAdapterInterface;
    SalesUApplication mGlobalApp;
    boolean isQuizOptionSelect;
    ColorStateList colorStateListGreen;
    ColorStateList colorStateListRed;
    QuizAdapterViewHolder mQuizAdapterViewHolder;
    private Context mContext;
    private List<QuizModelOptions> mQuizOption;
    private String[] mAlphabetNumber = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "G", "K", "L", "M", "N", "O", "P"};

    /**
     * To initialize quiz option list
     *
     * @param context activity context
     */
    public QuizAdapter(Context context, SalesUApplication globalApp) {
        mContext = context;
        mGlobalApp = mGlobalApp = globalApp;
    }

    /**
     * Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.
     * This new ViewHolder should be constructed with a new View that can represent the items of the given type.
     * You can either create a new View manually or inflate it from an XML layout file.
     *
     * @param parent
     * @param viewType
     * @return Recycler view holder
     */
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.quiz_option_list, parent, false);
        viewHolder = new QuizAdapterViewHolder(view);
        colorStateListGreen = new ColorStateList(
                new int[][]{
                        new int[]{android.R.attr.state_enabled} //enabled
                },
                new int[]{mContext.getResources().getColor(R.color.green)}
        );
        colorStateListRed = new ColorStateList(
                new int[][]{
                        new int[]{android.R.attr.state_enabled} //enabled
                },
                new int[]{mContext.getResources().getColor(R.color.red)}
        );
        return viewHolder;
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     * This method should update the contents of the itemView to reflect the item at the given position.
     *
     * @param holder   Recycler view holder
     * @param position position of current item
     */
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        mQuizAdapterViewHolder = (QuizAdapterViewHolder) holder;
        configureQuizViewHolder(mQuizAdapterViewHolder, position);
    }

    /**
     * listener for quiz option
     *
     * @param quizAdapterOptionListener
     */
    public void setQuizAdapterOptionListener(QuizAdapterInterface quizAdapterOptionListener) {
        mQuizAdapterInterface = quizAdapterOptionListener;
    }

    private void configureQuizViewHolder(final QuizAdapterViewHolder quizAdapterViewHolder, final int position) {

        if (mQuizOption.get(position).option_type.equalsIgnoreCase(quizAdapterViewHolder.mQuizTextTypeString)) {
            quizAdapterViewHolder.mQuizOptionHtmlView.setVisibility(View.GONE);
            quizAdapterViewHolder.mQuizOptionTextView.setVisibility(View.VISIBLE);
            quizAdapterViewHolder.mQuizOptionTextView.setText(mQuizOption.get(position).data);
        } else {
            quizAdapterViewHolder.mQuizOptionTextView.setVisibility(View.GONE);
            quizAdapterViewHolder.mQuizOptionHtmlView.setVisibility(View.VISIBLE);
            quizAdapterViewHolder.mQuizOptionHtmlView.loadDataWithBaseURL("", mQuizOption.get(position).data, "text/html", "UTF-8", "");
        }
      /*  quizAdapterViewHolder.mNumberOfQuestion.setText(mAlphabetNumber[position]);
        if(mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.color_primary_hex != null) {
            quizAdapterViewHolder.mNumberOfQuestion.setBackgroundColor(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex));
        }*/

        /*//For set Width Of Number of question
        ViewTreeObserver observer = quizAdapterViewHolder.mQuizLayout.getViewTreeObserver();
        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

            @Override
            public void onGlobalLayout() {
                // TODO Auto-generated method stub
                int a = quizAdapterViewHolder.mQuizLayout.getHeight();
                ViewGroup.LayoutParams params = quizAdapterViewHolder.mNumberOfQuestion.getLayoutParams();
                params.height = a;
                quizAdapterViewHolder.mNumberOfQuestion.setLayoutParams(params);

            }
        });*/

        quizAdapterViewHolder.mQuizLayout.setBackgroundColor(ContextCompat.getColor(mContext, R.color.whiteColor));

        quizAdapterViewHolder.mQuizLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*quizAdapterViewHolder.mQuizLayout.setBackgroundColor(ContextCompat.getColor(mContext, R.color.red));*/
                if (!isQuizOptionSelect) {
                    isQuizOptionSelect = true;
                    if (mQuizOption.get(position).is_correct.equalsIgnoreCase(SalesUConstants.QUIZ_CORRECT_OPTION_STRING)) {
                        quizAdapterViewHolder.mNumberOfQuestionRadio.setButtonDrawable(R.drawable.green_circle);
                        mQuizAdapterInterface.quizOptionSelectEvent(true);
                    } else {
                        quizAdapterViewHolder.mNumberOfQuestionRadio.setButtonDrawable(R.drawable.red_circle);
                        mQuizAdapterInterface.quizOptionSelectEvent(false);
                    }
                }
            }
        });

        quizAdapterViewHolder.mQuizOptionHtmlView.setOnTouchListener(new View.OnTouchListener() {

            public final static int FINGER_RELEASED = 0;
            public final static int FINGER_TOUCHED = 1;
            public final static int FINGER_DRAGGING = 2;
            public final static int FINGER_UNDEFINED = 3;

            private int fingerState = FINGER_RELEASED;


            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                switch (motionEvent.getAction()) {

                    case MotionEvent.ACTION_DOWN:
                        if (fingerState == FINGER_RELEASED) fingerState = FINGER_TOUCHED;
                        else fingerState = FINGER_UNDEFINED;
                        break;

                    case MotionEvent.ACTION_UP:
                        if (fingerState != FINGER_DRAGGING) {
                            fingerState = FINGER_RELEASED;

                            // Your onClick codes
                            if (!isQuizOptionSelect) {
                                isQuizOptionSelect = true;
                                if (mQuizOption.get(position).is_correct.equalsIgnoreCase(SalesUConstants.QUIZ_CORRECT_OPTION_STRING)) {
                                    quizAdapterViewHolder.mNumberOfQuestionRadio.setButtonDrawable(R.drawable.green_circle);
                                    mQuizAdapterInterface.quizOptionSelectEvent(true);
                                } else {
                                    quizAdapterViewHolder.mNumberOfQuestionRadio.setButtonDrawable(R.drawable.red_circle);
                                    mQuizAdapterInterface.quizOptionSelectEvent(false);
                                }
                            }

                        } else if (fingerState == FINGER_DRAGGING) fingerState = FINGER_RELEASED;
                        else fingerState = FINGER_UNDEFINED;
                        break;

                    case MotionEvent.ACTION_MOVE:
                        if (fingerState == FINGER_TOUCHED) {

                            fingerState = FINGER_DRAGGING;


                        } else fingerState = FINGER_UNDEFINED;
                        break;

                    default:
                        fingerState = FINGER_UNDEFINED;

                }

                return false;
            }
        });


        quizAdapterViewHolder.mNumberOfQuestionRadio.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (!isQuizOptionSelect) {
                    isQuizOptionSelect = true;
                    if (mQuizOption.get(position).is_correct.equalsIgnoreCase(SalesUConstants.QUIZ_CORRECT_OPTION_STRING)) {
                        quizAdapterViewHolder.mNumberOfQuestionRadio.setButtonDrawable(R.drawable.green_circle);
                        mQuizAdapterInterface.quizOptionSelectEvent(true);
                    } else {
                        quizAdapterViewHolder.mNumberOfQuestionRadio.setButtonDrawable(R.drawable.red_circle);
                        mQuizAdapterInterface.quizOptionSelectEvent(false);
                    }
                }
            }
        });

    }

    /**
     * set quiz option
     *
     * @param quizOption
     */
    public void setQuizOption(List<QuizModelOptions> quizOption) {
        mQuizOption = quizOption;
        isQuizOptionSelect = false;
        notifyDataSetChanged();
    }

    /**
     * To return number of quiz option
     *
     * @return number quiz option
     */
    @Override
    public int getItemCount() {
        return (mQuizOption != null) ? mQuizOption.size() : 0;
    }

    /**
     * interface for quiz
     */
    public interface QuizAdapterInterface {
        void quizOptionSelectEvent(boolean isSelectedOptionTrue);
    }

    /**
     * To Bind View
     */
    static class QuizAdapterViewHolder extends RecyclerView.ViewHolder

    {

        @BindView(R.id.quiz_layout)
        RelativeLayout mQuizLayout;

        @BindView(R.id.option_number)
        AppCompatRadioButton mNumberOfQuestionRadio;

        @BindView(R.id.quiz_option_text)
        AppCompatTextView mQuizOptionTextView;

        @BindView(R.id.quiz_option_html)
        WebView mQuizOptionHtmlView;

        @BindString(R.string.quiz_html_type)
        String mQuizHtmlTypeString;

        @BindString(R.string.quiz_text_type)
        String mQuizTextTypeString;

        public QuizAdapterViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}


