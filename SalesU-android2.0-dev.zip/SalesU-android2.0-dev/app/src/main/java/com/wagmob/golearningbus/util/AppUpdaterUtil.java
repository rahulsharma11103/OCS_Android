package com.wagmob.golearningbus.util;

import android.content.Context;
import com.github.javiersantos.appupdater.AppUpdater;
import com.github.javiersantos.appupdater.enums.Display;
import com.github.javiersantos.appupdater.enums.UpdateFrom;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;

import timber.log.Timber;

public class AppUpdaterUtil {

    public static AppUpdater prepareAppUpdater(Context context) {
        try {
            if (context != null) {
                return new AppUpdater(context)
                        .setUpdateFrom(UpdateFrom.GOOGLE_PLAY)
                        .setButtonDoNotShowAgain("")
                        .setDisplay(Display.DIALOG);
            }
        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e("Exception caught in prepareAppUpdater ==>> " + e.getMessage());
            }
        }
        return null;
    }

    public static void startAppUpdater(AppUpdater appUpdater) {
        try {
            if (appUpdater != null) {
                appUpdater.start();
            }
        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e("Exception caught in startAppUpdater ==>> " + e.getMessage());
            }
        }
    }

    public static void stopAppUpdater(AppUpdater appUpdater) {
        try {
            if (appUpdater != null) {
                appUpdater.stop();
            }
        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e("Exception caught in stopAppUpdater ==>> " + e.getMessage());
            }
        }
    }

}