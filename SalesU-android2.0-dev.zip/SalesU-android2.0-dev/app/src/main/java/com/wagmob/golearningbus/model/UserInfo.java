package com.wagmob.golearningbus.model;


public class UserInfo {

    public boolean error;
    public int response_code;
    public String[] message;
    public UserInfoMessage data;
}
