package com.wagmob.golearningbus.model.requestModel;

public class SignInRequest {
    public String email_id;
    public String password;
    public String keep_login;


    public String first_name;
    public String last_name;
    public String image_url;


}
