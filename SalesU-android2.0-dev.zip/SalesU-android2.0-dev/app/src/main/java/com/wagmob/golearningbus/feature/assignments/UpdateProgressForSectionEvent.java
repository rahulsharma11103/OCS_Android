package com.wagmob.golearningbus.feature.assignments;

/**
 * @author Rahul Sharma
 *         Event For updateProgress
 */

public class UpdateProgressForSectionEvent {

    public boolean isUpdateProgress;

    public UpdateProgressForSectionEvent(boolean updateProgress) {
        isUpdateProgress = updateProgress;
    }

    public boolean getUserUpdateProgress() {
        return isUpdateProgress;
    }
}
