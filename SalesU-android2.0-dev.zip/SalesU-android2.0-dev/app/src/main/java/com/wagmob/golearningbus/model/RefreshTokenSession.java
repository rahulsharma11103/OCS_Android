package com.wagmob.golearningbus.model;


public class RefreshTokenSession {
    public String accesstoken;
    public String refreshtoken;
}
