package com.wagmob.golearningbus.feature.tutorial;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.github.barteksc.pdfviewer.PDFView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.assignments.UpdateProgressForSectionEvent;
import com.wagmob.golearningbus.feature.edit_user_profile.EditProfileEvent;
import com.wagmob.golearningbus.feature.pdf_reader.PDFViewerService;
import com.wagmob.golearningbus.feature.pdf_reader.PDFViewerServiceImpl;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.TutorialModel;
import com.wagmob.golearningbus.model.requestModel.AssignmentRequest;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

/**
 * Fragment for show Tutorial
 *
 * @author Rahul Sharma
 */

public class TutorialFragment extends LoadDataFragment {


    String mAssignmentId;
    Context mContext;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.tutorial_web_view)
    WebView mTutorialWebView;
    @BindView(R.id.pdfView)
    PDFView mPdfView;
    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.web_service_to_get_quiz)
    String quizServiceUrl;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.web_service_set_assignment_progress)
    String mWebServiceURlForSetAssignmentProgress;
    @BindString(R.string.network_message)
    String mNetworkMessage;

    @BindString(R.string.tutorial_mime_type_html)
    String mTutorialMimeTypeHtml;
    @BindString(R.string.tutorial_mime_type_pdf)
    String mTutorialMimeTypePdf;
    @BindString(R.string.pdf_show_local_progress_title)
    String mPdfShowLocalProgressTitle;
    @BindString(R.string.pdf_show_local_progress_content)
    String mPdfShowLocalProgressContent;
    @BindView(R.id.adView)
    AdView mAdView;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    Gson mGson;
    @Inject
    EventBus mEventBus;
    @BindString(R.string.interstitial_add_id)
    String mInterstitialId;
    private InterstitialAd mInterstitialAd;
    boolean mIsAlreadyPurchase;
    TutorialFragment mTutorialFragment;
    private Unbinder mUnbinder;
    private String mParamName, mSlugUrl, mMethodType;
    private boolean isAccessTokenExpire;
    private boolean isSetProgress;
    private PDFViewerService mPdfViewerService;
    private boolean mIsVisibleToUser;
    private boolean mIsPageLoadedCompletely;

    /**
     * To initialize and return current fragment instance
     *
     * @param context
     * @param assignmentId
     * @return current fragment instance
     */
    public TutorialFragment newInstance(Context context, String assignmentId) {
        mTutorialFragment = new TutorialFragment();
        mTutorialFragment.mAssignmentId = assignmentId;
        mTutorialFragment.mContext = context;
        return mTutorialFragment;
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tutorial_view, container, false);
        mUnbinder = ButterKnife.bind(this, view);
        mPdfViewerService = (PDFViewerService) new PDFViewerServiceImpl();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (mContext != null) {
            initializeComponent();
            if (mSharedPreference != null) {
                mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

                if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {

                    mInterstitialAd = new InterstitialAd(mContext);
                    mInterstitialAd.setAdUnitId(mInterstitialId);
                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                    mInterstitialAd.setAdListener(new AdListener() {
                        @Override
                        public void onAdLoaded() {
                            super.onAdLoaded();
                            mInterstitialAd.show();
                        }
                    });
                }
            }
            setupBannerImage();
            loadTutorial();
        }
    }

    private void setupBannerImage() {
        boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

        if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);
        } else {
            mAdView.setVisibility(View.GONE);
        }
    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        if (mContext != null)
            ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    /**
     * To call Tutorial web service
     */
    private void loadTutorial() {
        showLoading();
        callTutorialDataService("na", quizServiceUrl + "?assignment_id=" + mAssignmentId, SalesUConstants.GET_METHOD_TYPE);
    }

    private void setProgress() {
        isSetProgress = true;
        if (mGlobalApp.isNetworkAvailable()) {
            AssignmentRequest assignmentRequest = new AssignmentRequest();
            assignmentRequest.assignment_id = mAssignmentId;
            String paramName = mGson.toJson(assignmentRequest);
            callTutorialDataService(paramName, mWebServiceURlForSetAssignmentProgress, SalesUConstants.POST_METHOD_TYPE);
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * call Tutorial web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callTutorialDataService(String paramName, String path, String methodType) {
        if (mGlobalApp != null) {
            if (mGlobalApp.isNetworkAvailable()) {
                mParamName = paramName;
                mSlugUrl = path;
                mMethodType = methodType;
                new TutorialService().execute();
            } else {
                hideLoading();
                Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * Response of Tutorial webservice
     *
     * @param response response of web service
     */
    public void tutorialWebServiceResponse(String response) {

        hideLoading();
        try {


            TutorialModel tutorialModel = mGson.fromJson(response, TutorialModel.class);
            if (tutorialModel != null && tutorialModel.data.assignment != null) {
                mGlobalApp.tutorialModelAssignment = tutorialModel.data.assignment;
                setupWebView();
           /* if (mGlobalApp.videoModelAssignment.video_url != null)*/
                //  setupVideoPlayer(mGlobalApp.videoModelAssignment.video_url);
            } else {
                //   Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ex) {
            // Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
        }
    }

    private void setupWebView() {
        mTutorialWebView.getSettings().setJavaScriptEnabled(true);
        mTutorialWebView.getSettings().setBuiltInZoomControls(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mTutorialWebView.getSettings().setMixedContentMode(mTutorialWebView.getSettings().MIXED_CONTENT_ALWAYS_ALLOW);
        }
        showLoading();
        mTutorialWebView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                //  view.loadUrl(url);
                return true;
            }

            public void onPageFinished(WebView view, String url) {
                hideLoading();
                mIsPageLoadedCompletely = true;
                if (mIsVisibleToUser) {
                    setProgress();
                }
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {

                Toast.makeText(mContext, "Oh no! " + description, Toast.LENGTH_SHORT).show();
                hideLoading();

            }
        });
        if (mGlobalApp.tutorialModelAssignment.file_mime != null && mGlobalApp.tutorialModelAssignment.file_mime.equalsIgnoreCase(mTutorialMimeTypeHtml)) {
            mTutorialWebView.loadUrl(mGlobalApp.tutorialModelAssignment.file_url);
        } else if (mGlobalApp.tutorialModelAssignment.file_mime != null && mGlobalApp.tutorialModelAssignment.file_mime.equalsIgnoreCase(mTutorialMimeTypePdf)) {
            hideLoading();
            mTutorialWebView.setVisibility(View.GONE);
            mPdfView.setVisibility(View.VISIBLE);
            setProgress();
            if (mPdfViewerService != null) {
                mPdfViewerService.initialize(mContext, mGlobalApp.tutorialModelAssignment.file_url, mPdfView, mPdfShowLocalProgressTitle, mPdfShowLocalProgressContent);
            }

        }
    }

    /**
     * unbind butter knife
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnbinder.unbind();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            mIsVisibleToUser = true;
            if (mAdView != null && mSharedPreference != null) {
                boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

                if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                    AdRequest adRequest = new AdRequest.Builder().build();
                    mAdView.loadAd(adRequest);
                } else {
                    mAdView.setVisibility(View.GONE);
                }
            }
            if (mIsPageLoadedCompletely) {
                setProgress();
            }
        } else {
            mIsVisibleToUser = false;
        }
    }

    /**
     * To Call Async Web Service
     */
    class TutorialService extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new TutorialService().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new TutorialService().execute();
                    } else {
                        if (!isSetProgress) {
                            tutorialWebServiceResponse(s);
                        } else {
                            mEventBus.post(new EditProfileEvent(true));
                            mEventBus.post(new UpdateProgressForSectionEvent(true));
                        }
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                //  Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }
    }
}
