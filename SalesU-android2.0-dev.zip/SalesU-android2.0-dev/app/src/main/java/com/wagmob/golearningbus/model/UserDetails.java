package com.wagmob.golearningbus.model;


public class UserDetails {
    public String user_id;
    public String first_name;
    public String last_name;
    public String image_id;
    public String image_url;
    public String accesstoken;
    public String refreshtoken;
}
