package com.wagmob.golearningbus.feature.Tour;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.view.BaseActivity;

import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Activity for tour
 *
 * @author Rahul Sharma
 */

public class TourActivity extends BaseActivity {


    Context mContext;
    private Unbinder mUnBinder;
    private TourFragment mTourFragment;


    /**
     * @param context current activity context
     * @return intent of activity
     */
    public static Intent callingIntent(Context context) {
        return new Intent(context, TourActivity.class);
    }

    /**
     * Use to initialize layout and App bar
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.launcher);
        mUnBinder = ButterKnife.bind(this);
        initializeFragment();
    }

    /**
     * Add fragment to activity
     */
    private void initializeFragment() {
        mTourFragment = TourFragment.newInstance(mContext);
        addFragment(R.id.fragment_common_container, mTourFragment);
    }

    /**
     * unbind butter knife object
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mUnBinder.unbind();
    }


}
