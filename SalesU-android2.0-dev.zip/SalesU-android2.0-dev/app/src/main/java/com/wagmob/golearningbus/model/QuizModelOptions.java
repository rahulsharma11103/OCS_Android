package com.wagmob.golearningbus.model;


public class QuizModelOptions {
    public String option_type;
    public String data;
    public String is_correct;
}
