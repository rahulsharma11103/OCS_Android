package com.wagmob.golearningbus.model;

public class FileUploadModelData {
 public FileUploadDataValue image;
}
