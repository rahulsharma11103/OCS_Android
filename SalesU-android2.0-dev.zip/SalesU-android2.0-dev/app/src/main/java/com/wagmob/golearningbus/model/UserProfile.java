package com.wagmob.golearningbus.model;


public class UserProfile {
    public String first_name;
    public String last_name;
    public String image_id;
    public String image_url;
    public UpdateProfileAssignmentStatus assignment_status;
    public String email_id;
}
