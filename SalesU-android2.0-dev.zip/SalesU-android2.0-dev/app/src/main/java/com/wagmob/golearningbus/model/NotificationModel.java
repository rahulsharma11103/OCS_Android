package com.wagmob.golearningbus.model;


public class NotificationModel {
    public boolean error;
    public int response_code;
    public String message[];
    public NotificationModelData data;
}
