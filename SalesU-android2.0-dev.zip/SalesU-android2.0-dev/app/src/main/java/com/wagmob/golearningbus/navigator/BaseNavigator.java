package com.wagmob.golearningbus.navigator;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.Tour.TourActivity;
import com.wagmob.golearningbus.feature.allcourses.AllCoursesActivity;
import com.wagmob.golearningbus.feature.app.HomeActivity;
import com.wagmob.golearningbus.feature.assignment_swipe.SwipeAssignmentActivity;
import com.wagmob.golearningbus.feature.assignments.AssignmentActivity;
import com.wagmob.golearningbus.feature.certificates.CertificatesActivity;
import com.wagmob.golearningbus.feature.change_password.ChangePasswordActivity;
import com.wagmob.golearningbus.feature.course_details.CourseDetailsActivity;
import com.wagmob.golearningbus.feature.edit_user_profile.EditProfileActivity;
import com.wagmob.golearningbus.feature.forgot_password.ForgotPasswordActivity;
import com.wagmob.golearningbus.feature.login.LoginActivity;
import com.wagmob.golearningbus.feature.notification_detail.NotificationsDetailsActivity;
import com.wagmob.golearningbus.feature.perfect_the_pitch.PerfectThePitch;
//import com.wagmob.golearningbus.feature.quiz.QuizActivity;
import com.wagmob.golearningbus.feature.quizreportcard.QuizReportCardActivity;
import com.wagmob.golearningbus.feature.search.SearchActivity;
import com.wagmob.golearningbus.feature.setting.SettingActivity;
import com.wagmob.golearningbus.feature.share.ShareActivity;
import com.wagmob.golearningbus.feature.signup.SignUpActivity;
/*import com.wagmob.golearningbus.feature.tutorial.TutorialActivity;
import com.wagmob.golearningbus.feature.video.VideoPlayerActivity;*/
import com.wagmob.golearningbus.feature.videoroleplay_your_pitch.YourPitchActivity;
import com.wagmob.golearningbus.model.AssignmentItems;
import com.wagmob.golearningbus.model.MyCoursesItem;
import com.wagmob.golearningbus.model.NotificationModelInfo;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

/**
 * This class have methods for navigation from one activity to another activity.
 *
 * @author Rahul Sharma
 */

public class BaseNavigator {

    @Inject
    SalesUApplication mGlobalApp;

    @Inject
    SharedPreferences mSharedPreference;

    /**
     * navigate to Sign up  Screen
     *
     * @param context activity context
     */
    public void
    navigateToSignUp(Context context) {
        if (context != null) {
            Intent intentToLaunch = SignUpActivity.callingIntent(context);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }

    /**
     * navigate to Home Screen
     *
     * @param context activity context
     */
    public void
    navigateToHomeActivity(Context context) {
        if (context != null) {
            Intent intentToLaunch = HomeActivity.callingIntent(context);
            context.startActivity(intentToLaunch);
            ((Activity) context).finish();
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }

    /**
     * navigate to Login Screen
     *
     * @param context activity context
     */
    public void
    navigateToLoginActivity(Context context) {
        if (context != null) {
            ((SalesUApplication) ((Activity) context).getApplication()).getApplicationModule().inject(this);
            mGlobalApp.refreshAllObject();
            SharedPreferences.Editor editor = mSharedPreference.edit();
            editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, false);
            editor.commit();
            Intent intentToLaunch = LoginActivity.callingIntent(context);
            intentToLaunch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            context.startActivity(intentToLaunch);

            ((Activity) context).finish();
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }

    public void
    navigateToShareActivity(Context context) {
        if (context != null) {
            Intent intentToLaunch = ShareActivity.callingIntent(context);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }


    /**
     * navigate to PerfectThePitch Screen
     *
     * @param context activity context
     */
    public void
    navigateToPerfectThePitchActivity(Context context) {
        if (context != null) {
            Intent intentToLaunch = PerfectThePitch.callingIntent(context);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }

    /**
     * navigate to YourPitch Screen
     *
     * @param context activity context
     */
    public void
    navigateToYourPitch(Context context) {
        if (context != null) {
            Intent intentToLaunch = YourPitchActivity.callingIntent(context);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }

    /**
     * navigate to AllCourses Screen
     *
     * @param context    activity context
     * @param categoryId id of category
     */
    public void
    navigateToAllCourses(Context context, String categoryId, String categoryTitle) {
        if (context != null) {
            ((SalesUApplication) ((Activity) context).getApplication()).getApplicationModule().inject(this);
            if (mGlobalApp.coursesItem != null) {
                mGlobalApp.coursesItem = null;
            }
            Intent intentToLaunch = AllCoursesActivity.callingIntent(context);
            intentToLaunch.putExtra(SalesUConstants.CATEGORY_ID, categoryId);
            intentToLaunch.putExtra(SalesUConstants.CATEGORY_TITLE, categoryTitle);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }

    /**
     * navigate to Course Details screen
     *
     * @param context       activity context
     * @param myCoursesItem
     */
    public void
    navigateToCourseDetailsScreen(Context context, MyCoursesItem myCoursesItem) {
        if (context != null) {
            Intent intentToLaunch = CourseDetailsActivity.callingIntent(context);
            intentToLaunch.putExtra(SalesUConstants.MY_COURSE_MODEL, myCoursesItem);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }

    /**
     * navigate to Assignment screen(it have tutorial,video,quiz etc)
     *
     * @param context      activity context
     * @param subsectionId id of subsection
     */
    public void
    navigateToAssignmentScreen(Context context, String subsectionId, String assignmentTitle) {
        if (context != null) {
            Intent intentToLaunch = AssignmentActivity.callingIntent(context);
            intentToLaunch.putExtra(SalesUConstants.SUBSECTION_ID, subsectionId);
            intentToLaunch.putExtra(SalesUConstants.ASSIGNMENT_NAME, assignmentTitle);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }

    /**
     * navigate to Video player screen
     *
     * @param context      activity context
     * @param assignmentId assignmentId
     *//*
    public void
    navigateToVideoPlayerScreen(Context context, String assignmentId) {
        if (context != null) {
            Intent intentToLaunch = VideoPlayerActivity.callingIntent(context);
            intentToLaunch.putExtra(SalesUConstants.ASSIGNMENT_ID, assignmentId);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }*/

   /* *//**
     * navigate to Quiz screen
     *
     * @param context      activity context
     * @param
     *//*
    public void
    navigateToQuizScreen(Context context, String assignmentId) {
        if (context != null) {
            Intent intentToLaunch = QuizActivity.callingIntent(context);
            intentToLaunch.putExtra(SalesUConstants.ASSIGNMENT_ID, assignmentId);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }
*/
    public void
    navigateToEditProfileScreen(Context context) {
        if (context != null) {
            Intent intentToLaunch = EditProfileActivity.callingIntent(context);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }

    public void
    navigateToQuizReportCardScreen(Context context, String assignmentId, String userPercentage, List<AssignmentItems> assignmentItems, int defaultTabPosition) {
        if (context != null && assignmentId != null && userPercentage != null) {
            Intent intentToLaunch = QuizReportCardActivity.callingIntent(context);
            intentToLaunch.putExtra(SalesUConstants.ASSIGNMENT_ID, assignmentId);
            intentToLaunch.putExtra(SalesUConstants.QUIZ_PERCENTAGE, userPercentage);
            intentToLaunch.putExtra(SalesUConstants.ASSIGNMENT_DETAILS, (ArrayList<AssignmentItems>) assignmentItems);
            intentToLaunch.putExtra(SalesUConstants.ASSIGNMENT_DEFAULT_TAB, defaultTabPosition);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
            ((Activity) context).finish();
        }
    }

   /* *//**
     * navigate to Tutorial  screen
     *
     * @param context      activity context
     * @param assignmentId assignmentId
     *//*
    public void
    navigateToTutorialScreen(Context context, String assignmentId, String assignmentName) {
        if (context != null) {
            Intent intentToLaunch = TutorialActivity.callingIntent(context);
            intentToLaunch.putExtra(SalesUConstants.ASSIGNMENT_ID, assignmentId);
            intentToLaunch.putExtra(SalesUConstants.ASSIGNMENT_NAME, assignmentName);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }*/

    /**
     * navigate to Change Password  screen
     *
     * @param context activity context
     */
    public void
    navigateToChangePasswordScreen(Context context) {
        if (context != null) {
            Intent intentToLaunch = ChangePasswordActivity.callingIntent(context);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }

    /**
     * navigate to Forgot Password  screen
     *
     * @param context activity context
     */
    public void
    navigateToForgotPasswordScreen(Context context) {
        if (context != null) {
            Intent intentToLaunch = ForgotPasswordActivity.callingIntent(context);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }


    /**
     * navigate to Tutorial  screen
     *
     * @param context activity context
     */
    public void
    navigateToSearchScreen(Context context) {
        if (context != null) {
            Intent intentToLaunch = SearchActivity.callingIntent(context);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }

    /**
     * navigate to Tour  screen
     *
     * @param context activity context
     */
    public void
    navigateToTourScreen(Context context) {
        if (context != null) {
            Intent intentToLaunch = TourActivity.callingIntent(context);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
            ((Activity) context).finish();
        }
    }

    /**
     * navigate to Tutorial  screen
     *
     * @param context activity context
     */
    public void
    navigateToNotificationDetailsScreen(Context context, NotificationModelInfo notificationModelInfo) {
        if (context != null) {
            Intent intentToLaunch = NotificationsDetailsActivity.callingIntent(context);
            intentToLaunch.putExtra(SalesUConstants.NOTIFICATION_MODEL_INFO, notificationModelInfo);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }

    /**
     * navigate to Tutorial  screen
     *
     * @param context activity context
     */
    public void
    navigateToSwipeAssignmentScreen(Context context, List<AssignmentItems> assignmentItems, int defaultTabPosition) {
        if (context != null) {
            Intent intentToLaunch = SwipeAssignmentActivity.callingIntent(context);
            intentToLaunch.putExtra(SalesUConstants.ASSIGNMENT_DETAILS, (ArrayList<AssignmentItems>) assignmentItems);
            intentToLaunch.putExtra(SalesUConstants.ASSIGNMENT_DEFAULT_TAB, defaultTabPosition);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }

    /**
     * navigate to Setting  screen
     *
     * @param context activity context
     */
    public void
    navigateToSettingScreen(Context context) {
        if (context != null) {
            Intent intentToLaunch = SettingActivity.callingIntent(context);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }

    /**
     * navigate to Certificate  screen
     *
     * @param context activity context
     */
    public void
    navigateToCertificateScreen(Context context,String certificateUrl) {
        if (context != null) {
            Intent intentToLaunch = CertificatesActivity.callingIntent(context);
            intentToLaunch.putExtra(SalesUConstants.CERTIFICATES_URL,certificateUrl);
            context.startActivity(intentToLaunch);
            ((Activity) context).overridePendingTransition(R.anim.activity_transition_in, R.anim.activity_transition_stay_still);
        }
    }
}
