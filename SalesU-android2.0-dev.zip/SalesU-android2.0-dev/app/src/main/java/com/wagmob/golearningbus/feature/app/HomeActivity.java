package com.wagmob.golearningbus.feature.app;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.github.javiersantos.appupdater.AppUpdater;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.readystatesoftware.viewbadger.BadgeView;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.allcategories.AllCategoriesFragment;
import com.wagmob.golearningbus.feature.glb.GLBFragmentTab;
import com.wagmob.golearningbus.feature.me.MeFragmentTab;
import com.wagmob.golearningbus.feature.mycourses.MyCoursesFragment;
import com.wagmob.golearningbus.feature.notification.NotificationEvent;
import com.wagmob.golearningbus.feature.notification.NotificationFragmentTab;
import com.wagmob.golearningbus.feature.notification.NotificationPaymentCheck;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.util.AppUpdaterUtil;
import com.wagmob.golearningbus.util.ImageUtil;
import com.wagmob.golearningbus.util.JavaUtil;
import com.wagmob.golearningbus.view.BaseActivity;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindColor;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;

/**
 * Home Page Activity.Here we take tab layout for home,notification,me and edCast
 *
 * @author Rahul Sharma
 */
public class HomeActivity extends BaseActivity {

    @BindColor(R.color.white)
    public int mColorWhite;
    List<Fragment> mfragmentList = new ArrayList<>();
    List<String> mTabTittle = new ArrayList<>();
    Context mContext;
    ActionBar mActionBar;
    HomeViewPagerAdapter mHomePagerAdapter;
    @BindView(R.id.cobranding_logo)
    AppCompatImageView mCobrandingLogo;
    @BindView(R.id.toolbar)
    Toolbar toolBar;
    @BindView(R.id.home_view_pager)
    ViewPager mViewPager;
    @BindView(R.id.home_tab)
    TabLayout mTabLayout;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    EventBus mEventBus;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @BindString(R.string.search_label_search)
    String mSearchLabel;
    @BindString(R.string.rate_the_app_title)
    String mRateTitle;
    @BindString(R.string.rate_the_app_message)
    String mRateMessage;
    @Inject
    SharedPreferences mSharedPreference;
    AppUpdater mAppUpdater;
    int mAppLaunchCount;
    private SearchView mSearchView;
    private BadgeView mBadgeView;
    private Unbinder mUnBinder;
    private AllCategoriesFragment mAllCategoriesFragment;
    private int mPreviousSelectedTab;
    private String mTitleName[];

    public static Intent callingIntent(Context context) {
        return new Intent(context, HomeActivity.class);
    }

    /**
     * initializing layout and view pager
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        mUnBinder = ButterKnife.bind(this);
        mContext = this;
        initializeComponent();
        setUpToolbar();

        if (mSharedPreference.getBoolean(SalesUConstants.IS_NEED_TO_SHOW_RATING_POPUP, true)) {
            addAppLaunchCount();
        }
        initializeTabTitle();
        if (SalesUConstants.IS_INDIVIDUAL_APP) {
            setupDataResourceForIndividualApp();
        } else {
            setUpDataResourceForLibrary();
        }

        mAllCategoriesFragment = AllCategoriesFragment.newInstance(mContext);
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.color_primary_hex != null) {
            mHomePagerAdapter = new HomeViewPagerAdapter(getSupportFragmentManager(), mfragmentList, mContext, mGlobalApp.appSettingModel.data.settings.color_primary_hex);
        }

        mViewPager.setAdapter(mHomePagerAdapter);
        mViewPager.setOffscreenPageLimit(4);
        mTabLayout.setupWithViewPager(mViewPager);
        mTabLayout.setTabMode(TabLayout.MODE_FIXED);
        mTabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        // Iterate over all tabs and set the custom view
        // setupIconAndTextColor(0);
        for (int i = 0; i < mTabLayout.getTabCount(); i++) {
            if (i == 0) {
                mTabLayout.getTabAt(i).setCustomView(mHomePagerAdapter.getTabView(i, ((ViewGroup) mTabLayout.getTabAt(i).getCustomView()), true));
            } else {
                mTabLayout.getTabAt(i).setCustomView(mHomePagerAdapter.getTabView(i, ((ViewGroup) mTabLayout.getTabAt(i).getCustomView()), false));
            }
        }

        mTabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int currentTabNumber = tab.getPosition();
                if (currentTabNumber > 1) {
                    mActionBar.setTitle(mTitleName[currentTabNumber]);
                    mActionBar.setDisplayShowTitleEnabled(true);
                    mCobrandingLogo.setVisibility(View.GONE);
                } else {
                    mActionBar.setTitle(mTitleName[currentTabNumber]);
                    mActionBar.setDisplayShowTitleEnabled(false);
                    mCobrandingLogo.setVisibility(View.VISIBLE);
                }
                mViewPager.setCurrentItem(currentTabNumber);
                if (currentTabNumber == 2) {
                    hideNotificationBadge();
                }
                removedTabIcon(tab.getPosition());
                TabLayout.Tab currentTab = mTabLayout.getTabAt(tab.getPosition());
                if (currentTab != null) {
                    View custom = mTabLayout.getTabAt(tab.getPosition()).getCustomView();
                    ViewParent icon = custom.getParent();
                    currentTab.setCustomView(mHomePagerAdapter.getTabView(tab.getPosition(), ((ViewGroup) icon), true));
                }

                triggerAmplitudeEventForTabSwitch(mTitleName[tab.getPosition()]);

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                mPreviousSelectedTab = tab.getPosition();
                removedTabIcon(tab.getPosition());
                TabLayout.Tab currentTab = mTabLayout.getTabAt(tab.getPosition());
                if (currentTab != null) {
                    View custom = currentTab.getCustomView();
                    if (custom != null) {
                        ViewParent icon = custom.getParent();
                        currentTab.setCustomView(mHomePagerAdapter.getTabView(tab.getPosition(), ((ViewGroup) icon), false));
                    }
                }
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        // setUpTabIcon();
        initializeAppUpdater();
    }

    private void addAppLaunchCount() {
        mAppLaunchCount = mSharedPreference.getInt(SalesUConstants.TOTAL_APP_LAUNCH, 1);
        if (mAppLaunchCount == SalesUConstants.RATE_MAX_COUNT) {
            mAppLaunchCount = 0;
            rateTheAppDialog();
        } else {
            mAppLaunchCount++;
        }
        SharedPreferences.Editor mEditor = mSharedPreference.edit();
        mEditor.putInt(SalesUConstants.TOTAL_APP_LAUNCH, mAppLaunchCount);
        mEditor.commit();
    }

    private void initializeAppUpdater() {
        mAppUpdater = AppUpdaterUtil.prepareAppUpdater(this);
        AppUpdaterUtil.startAppUpdater(mAppUpdater);
    }

    private void rateTheAppDialog() {
        final SharedPreferences.Editor mEditor = mSharedPreference.edit();
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(mContext);
        alertDialogBuilder.setTitle(mRateTitle);
        // set dialog message
        alertDialogBuilder
                .setMessage(mRateMessage)
                .setCancelable(false).setPositiveButton(SalesUConstants.RATE_IT_NOW, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Uri uri = Uri.parse("market://details?id=" + mContext.getPackageName());
                Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
                mEditor.putBoolean(SalesUConstants.IS_NEED_TO_SHOW_RATING_POPUP, false);
                mEditor.commit();

                // To count with Play market backstack, After pressing back button,
                // to taken back to our application, we need to add following flags to intent.
             /*   goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                        Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                        Intent.FLAG_ACTIVITY_MULTIPLE_TASK);*/
                try {
                    startActivity(goToMarket);
                } catch (ActivityNotFoundException e) {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse(SalesUConstants.PLAY_STORE_URL + mContext.getPackageName())));
                }
            }
        }).setNegativeButton(SalesUConstants.RATE_NO_THANKS, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mEditor.putBoolean(SalesUConstants.IS_NEED_TO_SHOW_RATING_POPUP, false);
                mEditor.commit();
                // callSharePermissionWebService(SalesUConstants.FALSE_FLAG);
            }
        }).setNeutralButton(SalesUConstants.RATE_REMIND_ME_LATER, new DialogInterface.OnClickListener() {

            /**
             * This method will be invoked when a button in the dialog is clicked.
             *
             * @param dialog The dialog that received the click.
             * @param which  The button that was clicked (e.g.
             *               {@link DialogInterface#BUTTON1}) or the position
             */
            @Override
            public void onClick(DialogInterface dialog, int which) {
                SharedPreferences.Editor mEditor = mSharedPreference.edit();
                mEditor.putInt(SalesUConstants.TOTAL_APP_LAUNCH, 1);
                mEditor.commit();

            }
        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        // show it
        alertDialog.show();

    }

    private void triggerAmplitudeEventForTabSwitch(String s) {
        JSONObject jElement;
        try {
            jElement = new JSONObject();
            jElement.put(AmplitudeUtil.TAB_NAME, s);
            AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_TAB_SWITCH, jElement);
        } catch (Exception ex) {

        }
    }

    private void initializeTabTitle() {
        String tabTitle[] = new String[5];
        tabTitle[0] = mContext.getString(R.string.all_courses);
        tabTitle[1] = mContext.getString(R.string.my_course);
        tabTitle[2] = mContext.getString(R.string.tab_footer_notification);
        tabTitle[3] = mContext.getString(R.string.tab_footer_me);
        tabTitle[4] = mContext.getString(R.string.tab_footer_library);
        mTitleName = tabTitle;
    }

    private void showNotificationBadge(String numberOfCount) {
        //For showing notification count's badge
        View notificationTabCustomView = mTabLayout.getTabAt(2).getCustomView();
        mBadgeView = new BadgeView(mContext, notificationTabCustomView);
        mBadgeView.setText(numberOfCount);
        mBadgeView.setBadgeMargin(35, 0);
        mBadgeView.show();
    }

    private void hideNotificationBadge() {
        if (mBadgeView != null) {
            mBadgeView.hide();
        }
    }

    public void setupIconAndTextColor(int currentPosition) {
        for (int i = 0; i < mTabLayout.getTabCount(); i++) {
            if (i == currentPosition) {
                mTabLayout.getTabAt(i).setCustomView(mHomePagerAdapter.getTabView(i, ((ViewGroup) mTabLayout.getTabAt(i).getCustomView()), true));
            } else {
                mTabLayout.getTabAt(i).setCustomView(mHomePagerAdapter.getTabView(i, ((ViewGroup) mTabLayout.getTabAt(i).getCustomView()), false));
            }
        }
    }

    public void removedTabIcon(Integer position) {
        TabLayout.Tab currentTab = mTabLayout.getTabAt(position);
        if (currentTab != null) {
            View custom = currentTab.getCustomView();
            if (custom != null) {
                ViewParent icon = custom.getParent();
                if (icon != null) {
                    ((ViewGroup) icon).removeView(custom);
                }
            }
        }
    }

    /**
     * initializing dagger components
     */
    private void initializeComponent() {
        ((SalesUApplication) this.getApplication()).getApplicationModule().inject(this);
    }

    /**
     * set up tab icon
     *//*
    private void setUpTabIcon() {

        mTabLayout.getTabAt(0).setIcon(R.drawable.home_icon);
        mTabLayout.getTabAt(1).setIcon(R.drawable.notification_icon);
        mTabLayout.getTabAt(2).setIcon(R.drawable.user_icon);
        mTabLayout.getTabAt(3).setIcon(R.drawable.edcast_logo);

    }*/

    /**
     * set up tab title
     */
    private void setUpDataResourceForLibrary() {
        addFragmentAndTabTittle(AllCategoriesFragment.newInstance(mContext), getResources().getString(R.string.all_courses));
        addFragmentAndTabTittle(MyCoursesFragment.newInstance(mContext), getResources().getString(R.string.my_course));
        addFragmentAndTabTittle(NotificationFragmentTab.newInstance(mContext), getResources().getString(R.string.tab_footer_notification));
        addFragmentAndTabTittle(MeFragmentTab.newInstance(mContext), getResources().getString(R.string.tab_footer_me));
    }

    private void setupDataResourceForIndividualApp() {
        addFragmentAndTabTittle(MyCoursesFragment.newInstance(mContext), getResources().getString(R.string.my_course));
        addFragmentAndTabTittle(AllCategoriesFragment.newInstance(mContext), getResources().getString(R.string.all_courses));
        addFragmentAndTabTittle(NotificationFragmentTab.newInstance(mContext), getResources().getString(R.string.tab_footer_notification));
        addFragmentAndTabTittle(MeFragmentTab.newInstance(mContext), getResources().getString(R.string.tab_footer_me));
        addFragmentAndTabTittle(new GLBFragmentTab(), getResources().getString(R.string.tab_footer_library));
    }

    /**
     * add title and icon of tab in list
     *
     * @param frgment
     * @param tabTittle
     */
    private void addFragmentAndTabTittle(Fragment frgment, String tabTittle) {
        mfragmentList.add(frgment);
        mTabTittle.add(tabTittle);
    }


    /**
     * setup tool bar
     */
    private void setUpToolbar() {
        setSupportActionBar(toolBar);
        mActionBar = getSupportActionBar();
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.color_primary_hex != null) {
            mActionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex)));
        }
        mActionBar.setDisplayShowTitleEnabled(false);
        //  mActionBar.setTitle("home");
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.settings != null
                && mGlobalApp.appSettingModel.data.settings.logo_url != null) {
            ImageUtil.getInstance().loadImage(mContext, mGlobalApp.appSettingModel.data.settings.logo_url, mCobrandingLogo, false);
        }
        getSupportActionBar().setElevation(0);
    }

    /**
     * inflate option menu
     *
     * @param menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_item, menu);
       /* mSearchView = (SearchView) menu.findItem(R.id.search_icon).getActionView();
        // mSearchView.setMaxWidth(mSearchViewAutoCompleteMaxSize);
        SearchView.SearchAutoComplete searchAutoComplete = (SearchView.SearchAutoComplete) mSearchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
        searchAutoComplete.setHintTextColor(mColorWhite);
        mSearchView.setQueryHint(mSearchLabel);
        setSearchViewOnQueryTextListener(mSearchView);
        // hide other menu item when SearchView is open or expanded
        mSearchView.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getSupportActionBar() != null) {
                    mCobrandingLogo.setVisibility(View.GONE);
                    // getSupportActionBar().setDisplayShowTitleEnabled(false);
                }
            }
        });

        // show other menu item when SearchView close
        mSearchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                // re-show the action button
                if (getSupportActionBar() != null) {
                    mCobrandingLogo.setVisibility(View.VISIBLE);
                    // getSupportActionBar().setDisplayShowTitleEnabled(true);
                }
                return false;
            }
        });*/
        return super.onCreateOptionsMenu(menu);
    }

    /*public void setSearchViewOnQueryTextListener(SearchView searchView) {
        try {
            if (searchView != null) {
                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        mSearchView.clearFocus();
                        mSearchView.onActionViewCollapsed();
                        mCobrandingLogo.setVisibility(View.VISIBLE);
                        new BaseNavigator().navigateToSearchScreen(mContext, query);
                        //onQueryTextSubmitListener(query);
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        // onQueryTextChangeListener(newText);
                        return false;
                    }
                });
            }
        } catch (Exception e) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e("Exception Caught ==>> " + e.getMessage());
            }
        }
    }*/

    /**
     * @param notificationEvent
     */
    public void onEvent(NotificationEvent notificationEvent) {
        if (Integer.parseInt(notificationEvent.getNotificationCount()) > 0) {
            showNotificationBadge(notificationEvent.getNotificationCount());
        }
    }

    public void onEvent(NotificationPaymentCheck notificationPaymentCheck) {
     /*   boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

        if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);
        } else {
            mAdView.setVisibility(View.GONE);
        }*/
    }

    /**
     * menu option selection
     *
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.search_icon: {
                new BaseNavigator().navigateToSearchScreen(mContext);
                break;
            }
            case R.id.setting_icon: {
                AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_NAME_SETTING_CLICKED);
                new BaseNavigator().navigateToSettingScreen(mContext);
            }

        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!mEventBus.isRegistered(this)) {
            mEventBus.register(this);
        }
    }

    /**
     * unbind butter knife
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mEventBus.unregister(this);
        mUnBinder.unbind();
        AppUpdaterUtil.stopAppUpdater(mAppUpdater);
    }


}
