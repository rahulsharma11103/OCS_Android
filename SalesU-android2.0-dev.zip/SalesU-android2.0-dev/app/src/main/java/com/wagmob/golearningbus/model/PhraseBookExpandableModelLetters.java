package com.wagmob.golearningbus.model;


import android.view.View;

public class PhraseBookExpandableModelLetters {
    public String meaning;
    public String pronunciation;
    public String soundfile_url;
}
