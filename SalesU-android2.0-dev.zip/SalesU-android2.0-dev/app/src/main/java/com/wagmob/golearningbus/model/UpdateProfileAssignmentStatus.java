package com.wagmob.golearningbus.model;


public class UpdateProfileAssignmentStatus {
    public String total;
    public String completed;
}
