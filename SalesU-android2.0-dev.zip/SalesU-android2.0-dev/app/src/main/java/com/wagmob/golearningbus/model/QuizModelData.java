package com.wagmob.golearningbus.model;


public class QuizModelData {
    public QuizModelAssignment assignment;
}
