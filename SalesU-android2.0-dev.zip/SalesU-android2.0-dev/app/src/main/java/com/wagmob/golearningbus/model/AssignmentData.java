package com.wagmob.golearningbus.model;

import java.util.List;

public class AssignmentData {
    public List<AssignmentItems> assignments;
}
