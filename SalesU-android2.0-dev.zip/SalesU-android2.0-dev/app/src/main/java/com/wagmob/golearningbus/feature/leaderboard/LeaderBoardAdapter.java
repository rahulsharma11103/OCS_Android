package com.wagmob.golearningbus.feature.leaderboard;

import android.content.Context;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.constants.JavaUtilClass;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.LeaderBoardModeUserInfo;
import com.wagmob.golearningbus.util.ImageUtil;

import java.util.List;

import butterknife.BindColor;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Adapter for leader board
 *
 * @author Rahul Sharma
 */

public class LeaderBoardAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    LeaderBoardRecyclerView leaderBoardRecyclerView;
    private Context mContext;
    private List<LeaderBoardModeUserInfo> mCollectionLeaderBoardItems;
    private String mCurrentUserId;

    /**
     * Constructor for Adapter
     *
     * @param context
     * @param leaderBoardModeUserInfos
     */
    public LeaderBoardAdapter(Context context, List<LeaderBoardModeUserInfo> leaderBoardModeUserInfos, String currentUserId) {
        mContext = context;
        mCollectionLeaderBoardItems = leaderBoardModeUserInfos;
        mCurrentUserId = currentUserId;
    }

    /**
     * Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.
     * This new ViewHolder should be constructed with a new View that can represent the items of the given type.
     * You can either create a new View manually or inflate it from an XML layout file.
     *
     * @param parent
     * @param viewType
     * @return Recycler view holder
     */
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder mRecyclerView;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.leader_board_items, parent, false);
        mRecyclerView = new LeaderBoardRecyclerView(view);
        return mRecyclerView;
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     * This method should update the contents of the itemView to reflect the item at the given position.
     *
     * @param holder   Recycler view holder
     * @param position position of current item
     */
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        LeaderBoardRecyclerView viewHolder = (LeaderBoardRecyclerView) holder;
        configureLeaderBoardTask(viewHolder, position);
    }

    public void configureLeaderBoardTask(final LeaderBoardRecyclerView viewHolder, int position) {
        final LeaderBoardModeUserInfo leaderBoardModeUserInfo = mCollectionLeaderBoardItems.get(position);
        if (leaderBoardModeUserInfo.user_id.equalsIgnoreCase(mCurrentUserId)) {
            viewHolder.mLeaderBoarLayout.setBackgroundColor(viewHolder.mSelectedUserBackGroundColor);
        } else {
            viewHolder.mLeaderBoarLayout.setBackgroundColor(viewHolder.mWhiteBackgroundColor);
        }
        ImageUtil.getInstance().loadImage(mContext, leaderBoardModeUserInfo.image_url, viewHolder.mUserImageView, R.drawable.anonymous_person_big, true, true);
        viewHolder.mUserNameView.setText(leaderBoardModeUserInfo.first_name + " " + leaderBoardModeUserInfo.last_name);
        viewHolder.mUserPercentageView.setText(JavaUtilClass.calculatePercentage(leaderBoardModeUserInfo.total, leaderBoardModeUserInfo.completed)+SalesUConstants.PERCENTAGE_SYMBOL);


    }

    /**
     * To set Assignment list
     *
     * @param leaderBoardModeUserInfos leaderBoard list item
     */
    public void setAssignmentItems(List<LeaderBoardModeUserInfo> leaderBoardModeUserInfos) {
        mCollectionLeaderBoardItems = leaderBoardModeUserInfos;
        notifyDataSetChanged();
    }

    /**
     * This method return number of item, if list is null then it return 0
     *
     * @return if list is not null then it return number of list items otherwise it return 0
     */
    @Override
    public int getItemCount() {
        return mCollectionLeaderBoardItems != null ? mCollectionLeaderBoardItems.size() : 0;
    }

    /**
     * For binding view item
     */
    static class LeaderBoardRecyclerView extends RecyclerView.ViewHolder {
        @BindView(R.id.leader_board_user_image)
        AppCompatImageView mUserImageView;

        @BindView(R.id.leader_board_user_name)
        AppCompatTextView mUserNameView;

        @BindView(R.id.leader_board_user_percentage)
        AppCompatTextView mUserPercentageView;

        @BindView(R.id.leader_board_layout)
        RelativeLayout mLeaderBoarLayout;

        @BindColor(R.color.leader_board_user_background)
        int mSelectedUserBackGroundColor;

        @BindColor(R.color.white)
        int mWhiteBackgroundColor;


        public LeaderBoardRecyclerView(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

}
