package com.wagmob.golearningbus.model;

import java.util.List;

/**
 * Created by wagmob on 8/28/2017.
 */

public class FlashCardModelAssignment {
    public String title;
    public String description;
    public List<FlashCardModelLetters> letters;
    public List<FlashCardModelLetters> phrasebook_letters;
}
