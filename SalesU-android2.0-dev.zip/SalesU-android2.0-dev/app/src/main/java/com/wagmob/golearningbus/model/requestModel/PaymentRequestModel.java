package com.wagmob.golearningbus.model.requestModel;


public class PaymentRequestModel {
    public String course_id;
    public String transaction_key;
    public String amount;
    public String provider;
    public String pkgname;
    public String productid;
    public String purchasetoken;

}
