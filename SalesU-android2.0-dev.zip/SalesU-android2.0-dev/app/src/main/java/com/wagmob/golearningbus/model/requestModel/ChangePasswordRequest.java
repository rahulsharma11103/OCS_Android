package com.wagmob.golearningbus.model.requestModel;


public class ChangePasswordRequest {

    public String old_password;
    public String new_password;
}
