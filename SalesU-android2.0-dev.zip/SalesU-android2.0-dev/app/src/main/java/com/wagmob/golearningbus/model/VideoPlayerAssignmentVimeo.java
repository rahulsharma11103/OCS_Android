package com.wagmob.golearningbus.model;



public class VideoPlayerAssignmentVimeo {
    public String Hdvimeourl;
    public String Sdvimeourl;
    public String Mobilevimeourl;
    public String Hlsvimeourl;

}
