package com.wagmob.golearningbus.model;



public class GetBrainTreeTokenModelData {

    public String token;
}
