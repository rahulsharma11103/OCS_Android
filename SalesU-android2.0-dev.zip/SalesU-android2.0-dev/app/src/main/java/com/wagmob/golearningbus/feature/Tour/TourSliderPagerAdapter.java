package com.wagmob.golearningbus.feature.Tour;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.AppSettingModelSplash;

import java.util.ArrayList;
import java.util.List;

/**
 * Adapter for tour.
 */

public class TourSliderPagerAdapter extends FragmentPagerAdapter {

    List<AppSettingModelSplash> mAppSettingModelSplash;
    List<Fragment> mFragmentList = new ArrayList<>();

    private Context mContext;





    public TourSliderPagerAdapter(FragmentManager fm, Context context, List<AppSettingModelSplash> appSettingModelSplash) {
        super(fm);
        mContext = context;
        mAppSettingModelSplash = appSettingModelSplash;
    }

    @Override
    public Fragment getItem(int position) {

        if (mAppSettingModelSplash.get(position).splash_type != null && mAppSettingModelSplash.get(position).splash_type.equalsIgnoreCase(SalesUConstants.SPLASH_TYPE_IMAGE)) {
            ImageTour imageTour = new ImageTour();
            imageTour.setPosition(position);
            return imageTour;
        } else if (mAppSettingModelSplash.get(position).splash_type != null && mAppSettingModelSplash.get(position).splash_type.equalsIgnoreCase(SalesUConstants.SPLASH_TYPE_VIDEO)) {
            VideoTourFragment videoTourFragment = new VideoTourFragment();
            videoTourFragment.setPosition(position);
            return videoTourFragment;
        } else if (mAppSettingModelSplash.get(position).splash_type != null && mAppSettingModelSplash.get(position).splash_type.equalsIgnoreCase(SalesUConstants.SPLASH_TYPE_HTML)) {
            WebViewTourFragment webViewTourFragment = new WebViewTourFragment();
            webViewTourFragment.setPosition(position);
            return webViewTourFragment;
        }else if (mAppSettingModelSplash.get(position).splash_type != null && mAppSettingModelSplash.get(position).splash_type.equalsIgnoreCase(SalesUConstants.SPLASH_TYPE_GUEST_LOGIN)) {
            GuestTour guestTour = new GuestTour();
            return guestTour;
        }
        return null;

    }

    @Override
    public int getCount() {
        return mAppSettingModelSplash != null ? mAppSettingModelSplash.size() : 0;
    }

    public void addFragment(Fragment fragment, AppSettingModelSplash appSettingModelSplash) {
        mFragmentList.add(fragment);
        mAppSettingModelSplash.add(appSettingModelSplash);
    }


}
