package com.wagmob.golearningbus.feature.assignments;


import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.Assignments;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

/**
 * Fragment for  showing all Assignment list
 *
 * @author Rahul Sharma
 */
public class AssignmentFragment extends LoadDataFragment {

    private static Context mContext;
    private static String mSubsectionId;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.assignment_list_item)
    RecyclerView mRecyclerView;
    @BindView(R.id.swipe_to_refresh)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @BindString(R.string.web_service_assignment)
    String mAssignmentWebServiceUrl;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @Inject
    Gson mGson;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    EventBus mEventBus;
    @BindView(R.id.adView)
    AdView mAdView;
    @BindString(R.string.add_unit_banner)
    String mBannerAdId;
    View view;
    private String mParamName, mSlugUrl, mMethodType;
    private int mNumberOfMore = 0;
    private Unbinder mUnBinder;
    private boolean isAccessTokenExpire, isGetMoreData;
    private AssignmentAdapter mAssignmentAdapter;
    private boolean mIsGuestLogin;

    /**
     * @param context
     * @param subsectionId
     * @return instance of AssignmentFragment
     */
    public static AssignmentFragment newInstance(Context context, String subsectionId) {
        mSubsectionId = subsectionId;
        mContext = context;
        return new AssignmentFragment();
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.assignment_fragment, container, false);
        mUnBinder = ButterKnife.bind(this, view);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadAssignmentList();
            }
        });
        return view;
    }

    /**
     * Load UI and call webService for all courses
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (mContext != null) {
            initializeComponent();
            mIsGuestLogin=mSharedPreference.getBoolean(SalesUConstants.SHARED_IS_GUEST_USER,false);
            setUpBannerImage();
            setUpUi();
            loadAssignmentList();
        }
    }

    private void setUpBannerImage() {
        if (mSharedPreference != null) {
            boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
            if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                AdRequest adRequest = new AdRequest.Builder().build();
                mAdView.loadAd(adRequest);
            } else {
                mAdView.setVisibility(View.GONE);
            }
        }
    }

    /**
     * To load Assignment list
     */
    private void loadAssignmentList() {
        if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
            // mGlobalApp.sectionsItems = null;
        } else {
            showLoading();
        }
        callCategoryListWebService("na", mAssignmentWebServiceUrl + "?subsection_id=" + mSubsectionId, SalesUConstants.GET_METHOD_TYPE);
    }

    /**
     * setup  recycler Adapter
     */
    private void setUpUi() {


        // final List<SectionsItems> sectionsItems = Arrays.asList(mGlobalApp.sectionsItems.get(0),mGlobalApp.sectionsItems.get(1));
        mAssignmentAdapter = new AssignmentAdapter(mContext, mGlobalApp.assignmentItems,mIsGuestLogin);
        //  mMyCourseAdapter.setOnItemClickListener(categoryAdapterListener);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mRecyclerView.setAdapter(mAssignmentAdapter);

    }


   /* private MyCoursesAdapter.CategoryAdapterInterface categoryAdapterListener = new MyCoursesAdapter.CategoryAdapterInterface() {


    };*/

    /**
     * @param response of Assignment Web Service
     */
    public void categoryWebServiceResponse(String response) {
        try {
            if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                mSwipeRefreshLayout.setRefreshing(false);
            }
            hideLoading();

            Assignments assignment = mGson.fromJson(response, Assignments.class);
            mGlobalApp.assignmentItems = assignment.data.assignments;
            mAssignmentAdapter.setAssignmentItems(mGlobalApp.assignmentItems);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }

    /*    mMyCourseAdapter.setCategoryCollection(mGlobalApp.myCoursesItem, isLoadMore);*/

    }

    /**
     * Initialize Dagger
     */
    private void initializeComponent() {
        if (mContext != null) {
            ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
        }
    }

    /**
     * call All Courses Web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callCategoryListWebService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new GetAssignmentListItem().execute();
        } else {
            if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                mSwipeRefreshLayout.setRefreshing(false);
            }
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if (mEventBus != null && !mEventBus.isRegistered(this)) {
            mEventBus.register(this);
        }
    }

    public void onEvent(UpdateProgressForSectionEvent updateProgressForSectionEvent) {
        if (updateProgressForSectionEvent.isUpdateProgress) {
            loadAssignmentList();
        }
    }

    /**
     * unBind Butter knife
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnBinder.unbind();
        if (mEventBus != null) {
            mEventBus.unregister(this);
        }
    }

    /**
     * calling of Assignment Web service
     */
    class GetAssignmentListItem extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new GetAssignmentListItem().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new GetAssignmentListItem().execute();
                    } else {
                        categoryWebServiceResponse(s);
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.getMessage());
            }

        }
    }
}
