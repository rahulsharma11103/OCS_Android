package com.wagmob.golearningbus.di;

import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import de.greenrobot.event.EventBus;

/**
 * it is application module class,here we can return global object
 */
@Module
public class ApplicationModule {

    private SalesUApplication myApp;


    public ApplicationModule(SalesUApplication app) {
        this.myApp = app;
    }

    @Singleton
    @Provides
    SharedPreferences provideSharedPreferences() {
        return myApp.getSharedPreferences(myApp.getPackageName(), myApp.MODE_PRIVATE);
    }

    @Singleton
    @Provides
    Gson provideGson() {
        return new Gson();
    }

    @Singleton
    @Provides
    SalesUApplication getSaleUApplication() {
        return (SalesUApplication) myApp;
    }

    @Singleton
    @Provides
    WebServiceHelper provideWebService() {
        return new WebServiceHelper(myApp);
    }

    @Singleton
    @Provides
    EventBus provideEventBus() {
        return EventBus.getDefault();
    }
}
