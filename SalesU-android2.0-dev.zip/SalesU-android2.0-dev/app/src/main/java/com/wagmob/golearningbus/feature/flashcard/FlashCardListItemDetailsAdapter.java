package com.wagmob.golearningbus.feature.flashcard;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.model.FlashCardModelLetters;
import com.wagmob.golearningbus.util.ImageUtil;

import java.util.List;

import butterknife.BindDrawable;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Rahul on 8/29/2017.
 */

public class FlashCardListItemDetailsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context mContext;
    List<FlashCardModelLetters> mFlashCardModelLetters;
    FlashCardItemDetailsView mFlashCardItemDetailsView;
    boolean mIsFlashCardItemChecked;
    int mCurrentFocusItem = -1;

    public FlashCardListItemDetailsAdapter(Context context, List<FlashCardModelLetters> flashCardModelLetters) {
        mContext = context;
        mFlashCardModelLetters = flashCardModelLetters;
    }

    /**
     * Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.
     * This new ViewHolder should be constructed with a new View that can represent the items of the given type.
     * You can either create a new View manually or inflate it from an XML layout file.
     *
     * @param parent
     * @param viewType
     * @return Recycler view holder
     */
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder mRecyclerView;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.flash_card_items_details_list, parent, false);
        mRecyclerView = new FlashCardItemDetailsView(view);
        return mRecyclerView;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        mFlashCardItemDetailsView = (FlashCardItemDetailsView) holder;
        if (mFlashCardModelLetters != null) {
            final FlashCardModelLetters flashCardModelLetters = mFlashCardModelLetters.get(position);
            if (flashCardModelLetters.word_image_url != null) {
                ImageUtil.getInstance().loadImage(mContext, flashCardModelLetters.word_image_url, mFlashCardItemDetailsView.mWordImageView, false);
            }
            if (flashCardModelLetters.word != null) {
                mFlashCardItemDetailsView.mWordNameView.setText(flashCardModelLetters.word);
            }
            if (flashCardModelLetters.meaning != null) {
                mFlashCardItemDetailsView.mWordMeaningView.setText(flashCardModelLetters.meaning);
            }
            if (flashCardModelLetters.pronunciation != null) {
                mFlashCardItemDetailsView.mWordPronunciationView.setText(flashCardModelLetters.pronunciation);
            }
            if (mIsFlashCardItemChecked) {
                mFlashCardItemDetailsView.mWordMeaningView.setVisibility(View.GONE);
                mFlashCardItemDetailsView.mWordPronunciationView.setVisibility(View.GONE);
                mFlashCardItemDetailsView.mWordNameSeparatorLayout.setVisibility(View.GONE);
                mFlashCardItemDetailsView.mWordMeaningSeparator.setVisibility(View.GONE);

            } else {
                mFlashCardItemDetailsView.mWordMeaningView.setVisibility(View.VISIBLE);
                mFlashCardItemDetailsView.mWordPronunciationView.setVisibility(View.VISIBLE);
                mFlashCardItemDetailsView.mWordNameSeparatorLayout.setVisibility(View.VISIBLE);
                mFlashCardItemDetailsView.mWordMeaningSeparator.setVisibility(View.VISIBLE);
            }

            mFlashCardItemDetailsView.mSoundFileIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mCurrentFocusItem = position;
                    notifyItemChanged(position);
                    MediaPlayer mp = new MediaPlayer();
                    try {
                        FlashCardModelLetters flashCardModelLettersSoundUrl = mFlashCardModelLetters.get(position);
                        mp.setDataSource(flashCardModelLettersSoundUrl.soundfile_url);//Write your location here
                        mp.prepare();
                        mp.start();
                        mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                            @Override
                            public void onCompletion(MediaPlayer mp) {
                                mCurrentFocusItem = -1;
                                notifyDataSetChanged();
                            }
                        });

                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                }
            });

            if (mCurrentFocusItem == position) {
                mFlashCardItemDetailsView.mSoundFileIcon.setImageDrawable(mFlashCardItemDetailsView.mSoundIconBlue);
            } else {
                mFlashCardItemDetailsView.mSoundFileIcon.setImageDrawable(mFlashCardItemDetailsView.mSoundIcon);
            }
        }
    }

    /**
     * To set FlashCard list
     *
     * @param flashCardModelLetters assignment list item
     */
    public void setFlashCardItems(List<FlashCardModelLetters> flashCardModelLetters) {
        mFlashCardModelLetters = flashCardModelLetters;
        notifyDataSetChanged();
    }

    public void isFlashCardItemChecked(boolean isChecked) {
        mIsFlashCardItemChecked = isChecked;
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    /**
     * Returns the total number of items in the data set held by the adapter.
     *
     * @return The total number of items in this adapter.
     */
    @Override
    public int getItemCount() {
        return mFlashCardModelLetters != null ? mFlashCardModelLetters.size() : 0;
    }

    public interface FlashCardListItemDetailsAdapterInterface {

    }

    static class FlashCardItemDetailsView extends RecyclerView.ViewHolder {
        @BindView(R.id.word_item_image)
        AppCompatImageView mWordImageView;

        @BindView(R.id.word_name_view)
        AppCompatTextView mWordNameView;

        @BindView(R.id.word_meaning_view)
        AppCompatTextView mWordMeaningView;

        @BindView(R.id.word_pronunciation_view)
        AppCompatTextView mWordPronunciationView;

        @BindView(R.id.word_name_separator)
        RelativeLayout mWordNameSeparatorLayout;

        @BindView(R.id.word_meaning_separator)
        RelativeLayout mWordMeaningSeparator;

        @BindView(R.id.sound_icon)
        AppCompatImageView mSoundFileIcon;

        @BindDrawable(R.drawable.sound_flashcard)
        Drawable mSoundIcon;

        @BindDrawable(R.drawable.sound_flashcard_blue)
        Drawable mSoundIconBlue;

        public FlashCardItemDetailsView(View items) {
            super(items);
            ButterKnife.bind(this, items);
        }

    }

}
