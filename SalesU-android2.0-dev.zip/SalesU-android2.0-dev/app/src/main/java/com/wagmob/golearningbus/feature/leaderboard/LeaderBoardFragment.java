package com.wagmob.golearningbus.feature.leaderboard;


import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.LeaderBoardModel;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.requestModel.SharePermissionRequest;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import timber.log.Timber;

/**
 * Fragment for leader board
 *
 * @author Rahul Sharma
 */
public class LeaderBoardFragment extends LoadDataFragment {

    private static Context mContext;
    private static String mCourseId;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.leader_board_list_item)
    RecyclerView mRecyclerView;
    @BindView(R.id.swipe_to_refresh)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @BindView(R.id.no_user_view)
    AppCompatTextView mNoUserView;
    @BindString(R.string.web_service_for_leader_board)
    String mLeaderBoardWebServiceUrl;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.web_service_share_score)
    String mSharePermissionUrl;
    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @BindString(R.string.share_permission_string)
    String mShareCertificatePermissionString;
    @Inject
    Gson mGson;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    View view;
    private String mParamName, mSlugUrl, mMethodType;
    private int mNumberOfMore = 0;
    private boolean isAccessTokenExpire, isGetMoreData;
    private LeaderBoardAdapter mLeaderBoardAdapter;
    private Unbinder mUnBinder;
    private boolean mIsSharePermissionService;


    public static LeaderBoardFragment newInstance(Context context, String courseId) {
        mContext = context;
        mCourseId = courseId;
        return new LeaderBoardFragment();
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.leader_board_fragment, null);
        mUnBinder = ButterKnife.bind(this, view);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadLeaderBoardList();
            }
        });
        return view;
    }

    /**
     * Load UI and call webService for all courses
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initializeComponent();
        if(mContext!=null&&mGlobalApp!=null) {
            setUpUi();
            if (mSharedPreference.getBoolean(SalesUConstants.PERMISSION_ASKED + mSharedPreference.getString(SalesUConstants.USER_ID, SalesUConstants.DEFAULT_VALUE), false)) {
                loadLeaderBoardList();
            }
        }
       /* if (mSharedPreference.getBoolean(SalesUConstants.PERMISSION_ASKED + mSharedPreference.getString(SalesUConstants.USER_ID, SalesUConstants.DEFAULT_VALUE), false)) {
            loadLeaderBoardList();
        } else {
            showPermissionAskDialog();
        }*/
    }

    /**
     * To load Assignment list
     */
    private void loadLeaderBoardList() {
        if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
            // mGlobalApp.sectionsItems = null;
        } else {
            showLoading();
        }
        mIsSharePermissionService = false;
        callLeaderBoardListWebService("na", mLeaderBoardWebServiceUrl + "?course_id=" + mCourseId, SalesUConstants.GET_METHOD_TYPE);
    }

    /**
     * setup  recycler Adapter
     */
    private void setUpUi() {


        // final List<SectionsItems> sectionsItems = Arrays.asList(mGlobalApp.sectionsItems.get(0),mGlobalApp.sectionsItems.get(1));
        mLeaderBoardAdapter = new LeaderBoardAdapter(mContext, mGlobalApp.leaderBoardItems, mSharedPreference.getString(SalesUConstants.USER_ID, "-2"));
        //  mMyCourseAdapter.setOnItemClickListener(categoryAdapterListener);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mRecyclerView.setAdapter(mLeaderBoardAdapter);

    }


    private void showPermissionAskDialog() {
        final SharedPreferences.Editor mEditor = mSharedPreference.edit();
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(mContext);
        alertDialogBuilder.setTitle(SalesUConstants.ALERT_TITLE_MESSAGE);
        // set dialog message
        alertDialogBuilder
                .setMessage(mShareCertificatePermissionString)
                .setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mEditor.putBoolean(SalesUConstants.PERMISSION_ASKED + mSharedPreference.getString(SalesUConstants.USER_ID, SalesUConstants.DEFAULT_VALUE), true);
                mEditor.putBoolean(SalesUConstants.IS_USER_SHARE_PROGRESS + mSharedPreference.getString(SalesUConstants.USER_ID, SalesUConstants.DEFAULT_VALUE), true);
                mEditor.commit();
                callSharePermissionWebService(SalesUConstants.TRUE_FLAG);
                dialog.cancel();
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mEditor.putBoolean(SalesUConstants.PERMISSION_ASKED + mSharedPreference.getString(SalesUConstants.USER_ID, SalesUConstants.DEFAULT_VALUE), true);
                mEditor.putBoolean(SalesUConstants.IS_USER_SHARE_PROGRESS + mSharedPreference.getString(SalesUConstants.USER_ID, SalesUConstants.DEFAULT_VALUE), false);
                mEditor.commit();
                callSharePermissionWebService(SalesUConstants.FALSE_FLAG);
                dialog.cancel();
            }
        });
        mEditor.commit();
        AlertDialog alertDialog = alertDialogBuilder.create();
        // show it
        alertDialog.show();

    }

    private void callSharePermissionWebService(String flag) {
        mIsSharePermissionService = true;
        String userId = mSharedPreference.getString(SalesUConstants.USER_ID, null);
        SharePermissionRequest sharePermissionRequest = new SharePermissionRequest();
        sharePermissionRequest.flag = flag;
        if (userId != null) {
            sharePermissionRequest.user_id = userId;
        }
        String json = mGson.toJson(sharePermissionRequest);
        callLeaderBoardListWebService(json, mSharePermissionUrl, SalesUConstants.POST_METHOD_TYPE);
    }


   /* private MyCoursesAdapter.CategoryAdapterInterface categoryAdapterListener = new MyCoursesAdapter.CategoryAdapterInterface() {


    };*/

    /**
     * @param response of LeaderBoard Web Service
     */
    public void leaderBoardWebServiceResponse(String response) {
        hideLoading();
        try {
            if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                mSwipeRefreshLayout.setRefreshing(false);
            }


            LeaderBoardModel leaderBoardModel = mGson.fromJson(response, LeaderBoardModel.class);
            mGlobalApp.leaderBoardItems = leaderBoardModel.data.leaderboard;
            mLeaderBoardAdapter.setAssignmentItems(mGlobalApp.leaderBoardItems);
            if (mGlobalApp.leaderBoardItems.size() >= 1) {
                mNoUserView.setVisibility(View.GONE);
            } else {
                mNoUserView.setVisibility(View.VISIBLE);
            }
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        }


    /*    mMyCourseAdapter.setCategoryCollection(mGlobalApp.myCoursesItem, isLoadMore);*/

    }

    /**
     * Initialize Dagger
     */
    private void initializeComponent() {
        if(mContext!=null) {
            ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
        }
    }

    /**
     * call All Courses Web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callLeaderBoardListWebService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new GetLeaderBoardListItem().execute();
        } else {
            if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                mSwipeRefreshLayout.setRefreshing(false);
            }
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * unBind Butter knife
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnBinder.unbind();
    }

    private void sharePermissionResponse(String s) {
        loadLeaderBoardList();
    }

    /**
     * calling of Assignment Web service
     */
    class GetLeaderBoardListItem extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new GetLeaderBoardListItem().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new GetLeaderBoardListItem().execute();
                    } else {
                        if (!mIsSharePermissionService) {
                            leaderBoardWebServiceResponse(s);
                        } else {
                            sharePermissionResponse(s);
                        }
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if(getView()!=null)
        {
            if (mSharedPreference!=null&&!(mSharedPreference.getBoolean(SalesUConstants.PERMISSION_ASKED + mSharedPreference.getString(SalesUConstants.USER_ID, SalesUConstants.DEFAULT_VALUE), false))) {
                showPermissionAskDialog();
            }
        }
    }
}
