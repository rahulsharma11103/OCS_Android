package com.wagmob.golearningbus.model;

import java.util.List;

public class Category {
    public List<CategoriesItem> categories;
}
