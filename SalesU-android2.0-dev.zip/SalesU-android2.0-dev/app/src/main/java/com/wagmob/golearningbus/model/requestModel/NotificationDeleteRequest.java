package com.wagmob.golearningbus.model.requestModel;


public class NotificationDeleteRequest {

    public String relation_id;

}
