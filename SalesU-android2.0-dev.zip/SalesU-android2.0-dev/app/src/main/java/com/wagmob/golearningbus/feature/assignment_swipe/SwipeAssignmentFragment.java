package com.wagmob.golearningbus.feature.assignment_swipe;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.AppCompatImageButton;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.app.NonSwipeableViewPager;
import com.wagmob.golearningbus.model.AssignmentItems;
import com.wagmob.golearningbus.view.BaseFragment;

import java.util.List;

import butterknife.BindDimen;
import butterknife.BindDrawable;
import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

/**
 * Fragment For Tour
 *
 * @author Rahul Sharma.
 */

public class SwipeAssignmentFragment extends BaseFragment {

    private static Context mContext;
    private static int mDefaultPosition;
    private static List<AssignmentItems> mCollectionAssignmentItems;
    private static SharedPreferences mSharedPreferences;
    @BindView(R.id.assignment_view_pager)
    NonSwipeableViewPager mPager;
    @BindView(R.id.next_assignment_view)
    AppCompatImageButton mNextAssignmentView;
    @BindView(R.id.previous_assignment_view)
    AppCompatImageButton mPreviousAssignmentView;
    @BindDrawable(R.drawable.assignment_available_background)
    Drawable mAssignmentBackgroundAvailable;
    @BindDrawable(R.drawable.assignment_unavailable_background)
    Drawable mAssignmentBackgroundUnAvailable;
    @BindView(R.id.assignment_bottom)
    RelativeLayout mAssignmentBottom;
    @BindString(R.string.assignment_type_flashcard)
    String mAssignmentTypeFlashCard;
    @BindString(R.string.assignment_type_writing)
    String mAssignmentTypeWriter;
    @BindString(R.string.assignment_type_phrase_card)
    String mAssignmentTypePhraseCard;
    @BindDimen(R.dimen.assignment_bottom_height)
    int mAssignmentBottomHeight;
    @BindView(R.id.assignment_view_pager_layout)
    RelativeLayout mAssViewPagerRelativeLayout;


    private Unbinder mUnBinder;


    /**
     * @param ctx Context of Activity
     * @return Current Class Instance
     */
    public static SwipeAssignmentFragment newInstance(Context ctx, List<AssignmentItems> assignmentItems, int defaultPosition, SharedPreferences sharedPreferences) {
        mContext = ctx;
        mCollectionAssignmentItems = assignmentItems;
        mDefaultPosition = defaultPosition;
        mSharedPreferences = sharedPreferences;
        return new SwipeAssignmentFragment();
    }


    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View swipeAssignmentView = inflater.inflate(R.layout.swipe_assignment_fragment, container, false);
        mUnBinder = ButterKnife.bind(this, swipeAssignmentView);
        return swipeAssignmentView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setUpViewPager();

    }


    private void setUpViewPager() {
        AssignmentSliderPagerAdapter assignmentSliderPagerAdapter = new AssignmentSliderPagerAdapter(getFragmentManager(), mContext, mCollectionAssignmentItems, mDefaultPosition, mPager);
        mPager.setAdapter(assignmentSliderPagerAdapter);
        mPager.setCurrentItem(mDefaultPosition);
        if (mCollectionAssignmentItems != null && !mCollectionAssignmentItems.isEmpty()) {
            getActivity().setTitle(mCollectionAssignmentItems.get(mDefaultPosition).title);
            isNeedToHideBottomNavigation(mCollectionAssignmentItems.get(mDefaultPosition));
        }

        boolean nextArrow = isNeedToShowNextArrow(mDefaultPosition);
        boolean previousArrow = isNeedToShowpreviousArrow(mDefaultPosition);
        setupConfiguration(mDefaultPosition);
        setupAssignmentArrow(nextArrow, previousArrow);
        mPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                boolean nextArrow = isNeedToShowNextArrow(position);
                boolean previousArrow = isNeedToShowpreviousArrow(position);
                setupAssignmentArrow(nextArrow, previousArrow);
                setupConfiguration(position);
                if (mCollectionAssignmentItems != null && !mCollectionAssignmentItems.isEmpty()) {
                    getActivity().setTitle(mCollectionAssignmentItems.get(position).title);
                    isNeedToHideBottomNavigation(mCollectionAssignmentItems.get(position));
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void setupConfiguration(int position) {
        if (mCollectionAssignmentItems != null) {
            AssignmentItems assignmentItem = mCollectionAssignmentItems.get(position);
            if (assignmentItem.assignment_type.equalsIgnoreCase(mContext.getString(R.string.assignment_type_video))
                    || assignmentItem.assignment_type.equalsIgnoreCase(mContext.getString(R.string.assignment_type_tutorial))
                    || assignmentItem.assignment_type.equalsIgnoreCase(mContext.getString(R.string.assignment_type_quiz))) {
                getActivity().setRequestedOrientation(
                        ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            } else {
                getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

            }
        }

    }

    public void isNeedToHideBottomNavigation(AssignmentItems assignmentItems) {
        if (assignmentItems != null) {
            if (assignmentItems.assignment_type.equalsIgnoreCase(mAssignmentTypeFlashCard) ||
                    assignmentItems.assignment_type.equalsIgnoreCase(mAssignmentTypeWriter) ||
                    assignmentItems.assignment_type.equalsIgnoreCase(mAssignmentTypePhraseCard)) {
                mAssignmentBottom.setVisibility(View.GONE);
                RelativeLayout.LayoutParams relativeParams = (RelativeLayout.LayoutParams) mAssViewPagerRelativeLayout.getLayoutParams();
                relativeParams.setMargins(0, 0, 0, 0);  // left, top, right, bottom
                mAssViewPagerRelativeLayout.setLayoutParams(relativeParams);

            } else {
                mAssignmentBottom.setVisibility(View.VISIBLE);
                /*RelativeLayout.LayoutParams relativeParams = (RelativeLayout.LayoutParams) mAssViewPagerRelativeLayout.getLayoutParams();
                relativeParams.setMargins(0, 0, 0, mAssignmentBottomHeight);  // left, top, right, bottom
                mAssViewPagerRelativeLayout.setLayoutParams(relativeParams);
*/
            }
        }
    }


    public void setupAssignmentArrow(boolean nextArrow, boolean previousArrow) {
        if (nextArrow) {
            mNextAssignmentView.setBackgroundDrawable(mAssignmentBackgroundAvailable);
        } else {
            mNextAssignmentView.setBackgroundDrawable(mAssignmentBackgroundUnAvailable);

        }

        if (previousArrow) {
            mPreviousAssignmentView.setBackgroundDrawable(mAssignmentBackgroundAvailable);
        } else {
            mPreviousAssignmentView.setBackgroundDrawable(mAssignmentBackgroundUnAvailable);
        }
    }

    /**
     * Unbind Butter knife object
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnBinder.unbind();
    }


    @OnClick(R.id.next_assignment_view)
    public void moveNextAssignment() {
        if (mPager != null) {
            mPager.setCurrentItem(mPager.getCurrentItem() + 1);
        }
       /* if (mCollectionAssignmentItems != null && !mCollectionAssignmentItems.isEmpty()) {
            getActivity().setTitle(mCollectionAssignmentItems.get(mDefaultPosition).title);
        }*/
    }

    @OnClick(R.id.previous_assignment_view)
    public void movePreviousAssignment() {
        if (mPager != null) {
            mPager.setCurrentItem(mPager.getCurrentItem() - 1);
        }
    }

    public boolean isNeedToShowNextArrow(int currentLocation) {
        currentLocation++;
        if (mCollectionAssignmentItems != null) {
            int collectionSize = mCollectionAssignmentItems.size();
            if (currentLocation >= collectionSize) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public boolean isNeedToShowpreviousArrow(int currentLocation) {
        if (currentLocation <= 0) {
            return false;
        } else {
            return true;
        }
    }

}
