package com.wagmob.golearningbus.model;


public class VideoPlayerAssignment {

    public String video_id;
    public String video_url;
    public String thumb_url;
    public String video_type;
    public VideoPlayerAssignmentVimeo vimeo_urls;
}
