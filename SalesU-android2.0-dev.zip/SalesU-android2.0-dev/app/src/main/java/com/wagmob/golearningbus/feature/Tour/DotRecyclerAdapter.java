package com.wagmob.golearningbus.feature.Tour;


import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.model.TourDotModel;

import java.util.List;

import butterknife.BindDrawable;
import butterknife.BindView;
import butterknife.ButterKnife;

public class DotRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    DotRecyclerAdapterRecyclerView assignmentRecyclerView;
    private Context mContext;
    private List<TourDotModel> mCollectionDotItems;
    public static boolean isProgressIncrease;
    /**
     * Constructor for Adapter
     *
     * @param context
     * @param tourDotModels
     */
    public DotRecyclerAdapter(Context context, List<TourDotModel> tourDotModels) {
        mContext = context;
        mCollectionDotItems = tourDotModels;
    }

    /**
     * Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.
     * This new ViewHolder should be constructed with a new View that can represent the items of the given type.
     * You can either create a new View manually or inflate it from an XML layout file.
     *
     * @param parent
     * @param viewType
     * @return Recycler view holder
     */
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder mRecyclerView;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.tour_item_data, parent, false);
        mRecyclerView = new DotRecyclerAdapterRecyclerView(view);
        return mRecyclerView;
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     * This method should update the contents of the itemView to reflect the item at the given position.
     *
     * @param holder   Recycler view holder
     * @param position position of current item
     */
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        DotRecyclerAdapterRecyclerView viewHolder = (DotRecyclerAdapterRecyclerView) holder;
        configureAssignmentTask(viewHolder, position);
    }

    public void configureAssignmentTask(final DotRecyclerAdapterRecyclerView viewHolder, int position) {
        final TourDotModel tourDotModel = mCollectionDotItems.get(position);

          if(tourDotModel.isSelected)
          {
              viewHolder.mTourDotView.setImageDrawable(viewHolder.mTourSelectedDot);
          }else {
              viewHolder.mTourDotView.setImageDrawable(viewHolder.mTourUnSelectedDot);
          }

    }

    /**
     * To set Assignment list
     *
     * @param tourDotModels assignment list item
     */
    public void setAssignmentItems(List<TourDotModel> tourDotModels) {
        mCollectionDotItems = tourDotModels;
        notifyDataSetChanged();
    }

    /**
     * This method return number of item, if list is null then it return 0
     *
     * @return if list is not null then it return number of list items otherwise it return 0
     */
    @Override
    public int getItemCount() {
        return mCollectionDotItems != null ? mCollectionDotItems.size() : 0;
    }

    /**
     * For binding view item
     */
    static class DotRecyclerAdapterRecyclerView extends RecyclerView.ViewHolder {
        @BindView(R.id.tour_dot)
        AppCompatImageView mTourDotView;

        @BindDrawable(R.drawable.tour_selected_dot)
        Drawable mTourSelectedDot;

        @BindDrawable(R.drawable.tour_unselected_dot)
        Drawable mTourUnSelectedDot;

        public DotRecyclerAdapterRecyclerView(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

}
