package com.wagmob.golearningbus.model.requestModel;

/**
 * Created by Rahul on 6/13/2017.
 */

public class SharePermissionRequest {
    public String user_id;
    public String flag;
}
