package com.wagmob.golearningbus.model;


import java.io.Serializable;

public class AssignmentItems implements Serializable{
    public String assignment_id;
    public String title;
    public String description;
    public String image_id;
    public String image_url;
    public String assignment_type;
    public String type_id;
    public String pr_assignment;
    public String is_complete;
}
