package com.wagmob.golearningbus.feature.Tour;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatImageView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.util.ImageUtil;
import com.wagmob.golearningbus.view.BaseFragment;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Image Tour
 *
 * @author Rahul Sharma.
 */

public class ImageTour extends BaseFragment {

    @BindView(R.id.tour_image)
    AppCompatImageView mTourImageView;

    private Unbinder mUnBinder;
    private static Context mContext;


    @Inject
    SalesUApplication mGlobalApp;

    private int mPosition;


    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.image_tour_fragment, container, false);
        mUnBinder = ButterKnife.bind(this, view);
        mContext = getContext();
        initializeComponent();
        return view;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setUpImageUrl();
    }

    public void setPosition(int position) {
        mPosition = position;
    }


    private void setUpImageUrl() {
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.splash != null) {
            ImageUtil.getInstance().loadImage(mContext, mGlobalApp.appSettingModel.data.splash.get(mPosition).image_portrait_url, mTourImageView, R.drawable.slider_deafult_image, false, true);
        }
    }

    /*
     * initialize dagger component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }


}
