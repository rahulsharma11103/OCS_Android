package com.wagmob.golearningbus.feature.me;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.gson.Gson;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.JavaUtilClass;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.edit_user_profile.EditProfileEvent;
import com.wagmob.golearningbus.model.MyAchievement;
import com.wagmob.golearningbus.model.MyAchievementCertificate;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.UserProfile;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.util.ImageUtil;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import java.util.ArrayList;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

/**
 * Fragment for Me(user profile page)
 *
 * @author Rahul Sharma
 */
public class MeFragmentTab extends LoadDataFragment {


    private static Context mContext;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.me_user_image)
    AppCompatImageView mUserImage;
    @BindView(R.id.me_user_name)
    AppCompatTextView mUserName;
    @BindView(R.id.me_user_progress)
    AppCompatTextView mTotalProgressView;
    @BindView(R.id.my_achievement_list_view)
    RecyclerView mMyAchievementRecyclerView;
    @BindView(R.id.my_achievement_no_certificate)
    AppCompatTextView mMyAchievementTextView;


    @BindString(R.string.web_service_get_user_profile)
    String mGetUserProfileWebService;

    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;

    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;

    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;

    @BindString(R.string.fields_can_not_null)
    String mEmptyFieldsMessage;

    @BindString(R.string.web_service_update_profile)
    String mUpdateProfileUrl;

    @BindString(R.string.default_user_progress)
    String mDefaultUserProgressMessage;

    @BindString(R.string.network_message)
    String mNetworkMessage;

    @BindString(R.string.guest_user)
    String mGuestUserName;

    @BindString(R.string.web_service_my_achievement)
    String mMyAcievementService;

    @BindString(R.string.no_achievement_label)
    String mNoAchievementLabelText;

    @BindString(R.string.sign_in_to_achive)
    String mSignInToAchieveSomething;
    @Inject
    Gson mGson;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    EventBus mEventBus;
    CircularProgressBar circularProgressBar;
    View view;
    MyAchievementsAdapter mMyAchievementsAdapter;
    boolean mIsGetProfileService;
    private Unbinder mUnBinder;
    private boolean isAccessTokenExpire, isGetMoreData;
    private String mParamName, mSlugUrl, mMethodType;
    private UserProfile mUserProfile;
    private boolean mIsGuestLogin;
    private MyAchievementsAdapter.MyAchievementAdapterInterface myAchievementAdapterInterface = new MyAchievementsAdapter.MyAchievementAdapterInterface() {
        @Override
        public void getMoreCategory(int offset) {
            isGetMoreData = true;
            loadAchievementList(offset);
        }
    };

    /**
     * @param context context for Activity
     * @return give instance of current fragment
     */
    public static MeFragmentTab newInstance(Context context) {
        mContext = context;
        return new MeFragmentTab();
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.me_fragment, container, false);
        mUnBinder = ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    /**
     * Load UI
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (mContext != null) {
            initializeComponent();
            mIsGuestLogin = mSharedPreference.getBoolean(SalesUConstants.SHARED_IS_GUEST_USER, false);
            if (mIsGuestLogin) {
                circularProgressBar = (CircularProgressBar) view.findViewById(R.id.circular_progress);
                circularProgressBar.setProgress(0.0f);
                mUserName.setText(mGuestUserName);
                mTotalProgressView.setText(mDefaultUserProgressMessage + " " + 0 + "%");
                mMyAchievementTextView.setVisibility(View.VISIBLE);
                mMyAchievementTextView.setText(mSignInToAchieveSomething);
            } else {
                setUpRecyclerView();
                getUserProfileService();
            }
        }
    }

    private void setUpRecyclerView() {
        mMyAchievementRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mMyAchievementsAdapter = new MyAchievementsAdapter(mContext, new ArrayList<MyAchievementCertificate>(), mMyAchievementRecyclerView);
        mMyAchievementsAdapter.initializeAdapterInterface(myAchievementAdapterInterface);
        mMyAchievementRecyclerView.setAdapter(mMyAchievementsAdapter);
    }

    /**
     * To call category web service
     *
     * @param offset offset number
     */
    private void loadAchievementList(int offset) {
        showLoading();
        getUserProfileService("na", mMyAcievementService + "?limit=" + SalesUConstants.REQUEST_MAX_LIMIT_DATA + "&offset=" + offset, SalesUConstants.GET_METHOD_TYPE);
    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    /**
     * setUp UI
     */
    private void setUpUi() {
        circularProgressBar = (CircularProgressBar) view.findViewById(R.id.circular_progress);

        String userName = mUserProfile.first_name + " " + mUserProfile.last_name;
        String userImageUrl = mUserProfile.image_url;
        String totalPercentage = JavaUtilClass.calculatePercentage(mUserProfile.assignment_status.total, mUserProfile.assignment_status.completed);
        if (mUserName != null && mUserImage != null && circularProgressBar != null && mTotalProgressView != null) {
            mUserName.setText(userName);
            ImageUtil.getInstance().loadImage(mContext, userImageUrl, mUserImage, R.drawable.anonymous_person_big, true, true);
            circularProgressBar.setProgress(Integer.parseInt(totalPercentage));
            mTotalProgressView.setText(mDefaultUserProgressMessage + " " + totalPercentage + "%");
        }
    }


    private void getUserProfileService() {
        /*if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
            // mGlobalApp.sectionsItems = null;
        } else {
            showLoading();
        }*/
        mIsGetProfileService = true;
        showLoading();
        getUserProfileService("na", mGetUserProfileWebService, SalesUConstants.GET_METHOD_TYPE);
    }

    public void getUserProfileService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new GetUserProfile().execute();
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    public void getUserProfileServiceResponse(String response) {
       /* if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
            mSwipeRefreshLayout.setRefreshing(false);
        }*/

        hideLoading();
        try {
            com.wagmob.golearningbus.model.GetUserProfile getUserProfileData = mGson.fromJson(response, com.wagmob.golearningbus.model.GetUserProfile.class);
            mUserProfile = getUserProfileData.data.profile;
            setUpUi();
            mIsGetProfileService = false;
            loadAchievementList(0);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        }

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnBinder.unbind();
        mEventBus.unregister(this);
    }

    private void getAchievementListResponse(String s) {
        try {
            hideLoading();
            boolean isLoadMore = false;
            MyAchievement allCategory = mGson.fromJson(s, MyAchievement.class);
            if (mGlobalApp.myAchievementList == null) {
                mGlobalApp.myAchievementList = allCategory.data.certificate;
            } else {
                isLoadMore = true;
                mGlobalApp.myAchievementList.addAll(allCategory.data.certificate);
            }

            if (allCategory.data.certificate != null && (allCategory.data.certificate.size() > 0 || isGetMoreData)) {
                mMyAchievementTextView.setVisibility(View.GONE);
            } else {
                if (!isGetMoreData) {
                    mMyAchievementTextView.setVisibility(View.VISIBLE);
                    mMyAchievementTextView.setText(mNoAchievementLabelText);
                }
            }

            mMyAchievementsAdapter.setAchievementCollection(mGlobalApp.myAchievementList, isLoadMore);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    /**
     * @param editProfileEvent
     */
    public void onEvent(EditProfileEvent editProfileEvent) {
        if (editProfileEvent.getIsUserUpdateProfile()) {
            if (mGlobalApp.myAchievementList != null) {
                mGlobalApp.myAchievementList = null;
            }
            if (!mIsGuestLogin) {
                getUserProfileService();
            }
        }
    }

    /**
     * register event bus
     */
    @Override
    public void onStart() {
        super.onStart();
        if (!mEventBus.isRegistered(this)) {
            mEventBus.register(this);
        }

    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item = menu.findItem(R.id.search_icon);
        item.setVisible(false);
        MenuItem settingIcon = menu.findItem(R.id.setting_icon);
        settingIcon.setVisible(true);
        super.onPrepareOptionsMenu(menu);
    }

    class GetUserProfile extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new GetUserProfile().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new GetUserProfile().execute();
                    } else {
                        if (mIsGetProfileService) {
                            getUserProfileServiceResponse(s);
                        } else {
                            getAchievementListResponse(s);
                        }
                    }
                } else {
                    hideLoading();
                    if (SalesUConstants.ISLogVisible) {
                        Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                    }

                }
            } catch (Exception e) {
                hideLoading();
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());
            }

        }
    }


}
