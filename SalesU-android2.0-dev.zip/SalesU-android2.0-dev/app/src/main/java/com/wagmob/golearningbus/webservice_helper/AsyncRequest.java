package com.wagmob.golearningbus.webservice_helper;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;

import com.wagmob.golearningbus.SalesUApplication;

import javax.inject.Inject;


public class AsyncRequest extends AsyncTask<Void, Void, String> {


    private String mParamName, mSlugUrl, mMethodType;
    private Context mContext;
    private String mGoogleToken;
    private String mFacebookToken;
    private OnAsyncRequestComplete caller;
    //  private ProgressDialog mProgressDialog;

    @Inject
    WebServiceHelper mWebServiceHelper;

    public interface OnAsyncRequestComplete {
        public void asyncResponse(String response);
    }

    public AsyncRequest(Context context, String paramName, String slugUrl, String methodType,String googleToken,String facebookToken) {
        caller = (OnAsyncRequestComplete) (Activity) context;
        mMethodType = methodType;
        mSlugUrl = slugUrl;
        mParamName = paramName;
        mGoogleToken=googleToken;
        mFacebookToken=facebookToken;
        mContext = context;
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
     /*   mProgressDialog = new ProgressDialog(mContext);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();*/

    }

    @Override
    protected String doInBackground(Void... params) {
        String webServiceResponse = "";
        webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl,mGoogleToken,mFacebookToken);
        return webServiceResponse;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
       /* if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.dismiss();
        }*/
        caller.asyncResponse(s);
    }


}
