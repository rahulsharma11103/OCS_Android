package com.wagmob.golearningbus.feature.mycourses;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.allcourses.UpdateMyCourseListEvent;
import com.wagmob.golearningbus.feature.assignments.UpdateProgressForSectionEvent;
import com.wagmob.golearningbus.feature.edit_user_profile.EditProfileEvent;
import com.wagmob.golearningbus.feature.notification.NotificationPaymentCheck;
import com.wagmob.golearningbus.model.CheckPaymentStatusModel;
import com.wagmob.golearningbus.model.CheckPaymentStatusModelMessage;
import com.wagmob.golearningbus.model.CoursesSubscription;
import com.wagmob.golearningbus.model.MyAllCourses;
import com.wagmob.golearningbus.model.MyCoursesItem;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.requestModel.CoursesSubscriptionRequest;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

/**
 * Fragment for  showing all my courses list
 *
 * @author Rahul Sharma
 */
public class MyCoursesFragment extends LoadDataFragment {

    private static Context mContext;
    private static String mCategoryId;
    View view;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.my_courses_recycler_view)
    RecyclerView mRecyclerView;
    @BindString(R.string.web_service_my_all_courses)
    String allCoursesUrl;
    @BindView(R.id.swipe_to_refresh)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @BindView(R.id.adView)
    AdView mAdView;
    @BindView(R.id.no_course_found_layout)
    RelativeLayout mNoCourseFoundMessageLayout;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @BindString(R.string.web_service_for_check_payment_status)
    String mPaymentStatusServiceUrl;
    @BindString(R.string.web_service_for_course_unsubscribe)
    String mUnSubscribeWebServiceUrl;
    @BindString(R.string.dialogLoadingTitle)
    String mProgressDialogTitle;
    @BindString(R.string.dialogLoadingMessage)
    String mProgressDialogMessage;
    @Inject
    Gson mGson;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    EventBus mEventBus;
    MyCoursesItem mMyCoursesItem;
    List<MyCoursesItem> mMyCourseCollection;
    MyCoursesAdapter.CategoryViewHolder mCategoryViewHolder;
    boolean mIsCourseUnsubscribeCall;
    ProgressDialog mProgressDialog;
    boolean mIsAlreadyServiceCall;
    private String mParamName, mSlugUrl, mMethodType;
    private String mParamNamePayment, mSlugUrlPayment, mMethodTypePayment;
    private int mNumberOfMore = 0;
    private Unbinder mUnBinder;
    private boolean isAccessTokenExpire, isGetMoreData, isAccessTokenExpireForPayment;
    private MyCoursesAdapter mMyCourseAdapter;
    boolean mIsPaymentServiceCallBackComplete;
    private boolean mIsGuestLogin;
    /**
     * Adapter listener
     */
    private MyCoursesAdapter.CategoryAdapterInterface categoryAdapterListener = new MyCoursesAdapter.CategoryAdapterInterface() {

        @Override
        public void getMoreCategory(int offset) {
            isGetMoreData = true;
            loadCategoriesList(offset);
        }

        @Override
        public void unSubscribeClick(MyCoursesItem myCoursesItem, MyCoursesAdapter.CategoryViewHolder categoryViewHolder) {
            mMyCoursesItem = myCoursesItem;
            mCategoryViewHolder = categoryViewHolder;

            CoursesSubscriptionRequest coursesSubscriptionRequest = new CoursesSubscriptionRequest();
            coursesSubscriptionRequest.course_id = mMyCoursesItem.course_id;
            String coursesJson = mGson.toJson(coursesSubscriptionRequest);
            mIsCourseUnsubscribeCall = true;
            callPaymentStatusWebService(coursesJson, mUnSubscribeWebServiceUrl, SalesUConstants.POST_METHOD_TYPE);
        }


    };

    /**
     * To return my course fragment instance
     *
     * @param context
     * @return my course fragment instance
     */
    public static MyCoursesFragment newInstance(Context context) {
        mContext = context;
        return new MyCoursesFragment();
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.my_cource_fragment, null);
        mUnBinder = ButterKnife.bind(this, view);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadCategoriesList(0);
            }
        });
        return view;
    }

    /**
     * Load UI and call webService for my courses
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (mContext != null) {
            initializeComponent();
            mIsGuestLogin=mSharedPreference.getBoolean(SalesUConstants.SHARED_IS_GUEST_USER,false);
            setUpUi();
            setupProgressDialog();
            loadCategoriesList(0);
            loadPaymentStatus();
        }
    }

    /**
     * Call WebService for load all Courses
     *
     * @param offset
     */
    private void loadCategoriesList(int offset) {

        if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
            mGlobalApp.myCoursesItem = null;
        } else {
            showLoading();
        }
        callCategoryListWebService("na", allCoursesUrl + "?limit=" + SalesUConstants.REQUEST_MAX_LIMIT_DATA + "&offset=" + offset, SalesUConstants.GET_METHOD_TYPE);
    }

    private void loadPaymentStatus() {
        callPaymentStatusWebService("na", mPaymentStatusServiceUrl, SalesUConstants.GET_METHOD_TYPE);
    }

    /**
     * setup UI and recycler Adapter
     */
    private void setUpUi() {
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mMyCourseAdapter = new MyCoursesAdapter(mContext, new ArrayList<MyCoursesItem>(), mRecyclerView, mGlobalApp,mIsGuestLogin);
        mMyCourseAdapter.setOnItemClickListener(categoryAdapterListener);
        mRecyclerView.setAdapter(mMyCourseAdapter);
    }

    /**
     * response of my courses
     *
     * @param response response of my courses
     */
    public void categoryWebServiceResponse(String response) {
        try {


            if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                mSwipeRefreshLayout.setRefreshing(false);
            }
            hideLoading();
            boolean isLoadMore = false;
            MyAllCourses allCourses = mGson.fromJson(response, MyAllCourses.class);
            if (mGlobalApp.myCoursesItem == null) {
                mGlobalApp.myCoursesItem = allCourses.data.subscriptions;
            } else {
                isLoadMore = true;
                mGlobalApp.myCoursesItem.addAll(allCourses.data.subscriptions);
            }

            if (allCourses.data.subscriptions != null && (allCourses.data.subscriptions.size() > 0 || isGetMoreData)) {
                mNoCourseFoundMessageLayout.setVisibility(View.GONE);
            } else {
                if (!isGetMoreData)
                    mNoCourseFoundMessageLayout.setVisibility(View.VISIBLE);
            }
            mMyCourseCollection = mGlobalApp.myCoursesItem;
            mMyCourseAdapter.setCategoryCollection(mGlobalApp.myCoursesItem, isLoadMore);
            mIsAlreadyServiceCall = false;
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        }

    }

    /**
     * Initialize Dagger Components
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    /**
     * call web service for my Courses
     *
     * @param paramName
     * @param path
     * @param methodType
     */
    public void callCategoryListWebService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new GetCategoryListItem().execute();
        } else {
            if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                mSwipeRefreshLayout.setRefreshing(false);
            }
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * call web service for my Courses
     *
     * @param paramName
     * @param path
     * @param methodType
     */
    public void callPaymentStatusWebService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            if (mIsCourseUnsubscribeCall) {
                mProgressDialog.show();
            }
            mParamNamePayment = paramName;
            mSlugUrlPayment = path;
            mMethodTypePayment = methodType;
            new GetPaymentStatusService().execute();
        } else {
            hideLoading();
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
            }
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Event for section
     *
     * @param updateMyCourseListEvent
     */
    public void onEvent(UpdateMyCourseListEvent updateMyCourseListEvent) {
        if (updateMyCourseListEvent.getCourseSubscribeUpdate()) {
            if (!mIsAlreadyServiceCall) {
                if (mGlobalApp.myCoursesItem != null) {
                    mGlobalApp.myCoursesItem = null;
                }
                loadCategoriesList(0);
                mIsAlreadyServiceCall = true;
            }
        }
    }


    /**
     * register event bus
     */
    @Override
    public void onStart() {
        super.onStart();
        if (!mEventBus.isRegistered(this)) {
            mEventBus.register(this);
        }

    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {

            if (mAdView != null && mIsPaymentServiceCallBackComplete && mSharedPreference != null) {
                boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

                if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                    AdRequest adRequest = new AdRequest.Builder().build();
                    mAdView.loadAd(adRequest);
                } else {
                    mAdView.setVisibility(View.GONE);
                }
            }
        }
    }

    /**
     * unbind butter knife and unregister  event bus
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnBinder.unbind();
        mEventBus.unregister(this);
        if (mGlobalApp.myCoursesItem != null) {
            mGlobalApp.myCoursesItem = null;
        }
    }

    private void paymentWebServiceResponse(String s) {
        try {
            CheckPaymentStatusModel checkPaymentStatusModel = mGson.fromJson(s, CheckPaymentStatusModel.class);
            SharedPreferences.Editor editor = mSharedPreference.edit();
            if (!checkPaymentStatusModel.error) {
                CheckPaymentStatusModelMessage checkPaymentStatusModelMessage = checkPaymentStatusModel.message;

                if (checkPaymentStatusModelMessage.has_master_subscription) {
                    editor.putBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, true);
                    editor.commit();
                    mAdView.setVisibility(View.GONE);

                } else {
                    editor.putBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
                    editor.commit();
                    if (SalesUConstants.IS_INDIVIDUAL_APP) {
                        AdRequest adRequest = new AdRequest.Builder().build();
                        mAdView.loadAd(adRequest);
                    } else {
                        mAdView.setVisibility(View.GONE);
                    }
                }
            } else {
                editor.putBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
                editor.commit();
                if (SalesUConstants.IS_INDIVIDUAL_APP) {
                    AdRequest adRequest = new AdRequest.Builder().build();
                    mAdView.loadAd(adRequest);
                } else {
                    mAdView.setVisibility(View.GONE);
                }
            }
            mIsPaymentServiceCallBackComplete = true;
            mEventBus.post(new NotificationPaymentCheck());

        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void unSubscribeWebServiceResponse(String s) {
        if (mProgressDialog != null) {
            mProgressDialog.dismiss();
        }
        try {
            CoursesSubscription coursesSubscription = mGson.fromJson(s, CoursesSubscription.class);

            if (coursesSubscription != null && !coursesSubscription.error) {
                courseSuccessfullyUnSubscribeOrNot(true);
                mEventBus.post(new EditProfileEvent(true));
            } else {
                courseSuccessfullyUnSubscribeOrNot(false);
            }

        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        }
    }


    public void courseSuccessfullyUnSubscribeOrNot(boolean isCourseSubscribe) {
        if (mCategoryViewHolder != null && mMyCoursesItem != null) {
            if (isCourseSubscribe) {
                mMyCourseCollection.remove(mMyCoursesItem);
                mRecyclerView.getAdapter().notifyItemRemoved(mCategoryViewHolder.getAdapterPosition());
                Toast.makeText(mContext, mCategoryViewHolder.mCourseUnsubscribeMessage, Toast.LENGTH_SHORT).show();
            } else {
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void setupProgressDialog() {
        mProgressDialog = new ProgressDialog(mContext);
        mProgressDialog.setTitle(mProgressDialogTitle);
        mProgressDialog.setMessage(mProgressDialogMessage);
        mProgressDialog.setCancelable(false);
    }

    /**
     * Call my courses fragment
     */
    class GetCategoryListItem extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new GetCategoryListItem().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new GetCategoryListItem().execute();
                    } else {
                        categoryWebServiceResponse(s);
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());

            }

        }
    }

    /**
     * Call my courses fragment
     */
    class GetPaymentStatusService extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpireForPayment) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamNamePayment, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodTypePayment, mParamNamePayment, mSlugUrlPayment);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpireForPayment = true;
                    new GetPaymentStatusService().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpireForPayment) {
                        isAccessTokenExpireForPayment = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new GetPaymentStatusService().execute();
                    } else {
                        if (mIsCourseUnsubscribeCall) {
                            mIsCourseUnsubscribeCall = false;
                            unSubscribeWebServiceResponse(s);
                        } else {
                            paymentWebServiceResponse(s);
                        }
                    }
                } else {
                    hideLoading();
                    if (mProgressDialog != null) {
                        mProgressDialog.dismiss();
                    }
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                if (mProgressDialog != null) {
                    mProgressDialog.dismiss();
                }
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.toString());

            }

        }
    }


}
