package com.wagmob.golearningbus.model.requestModel;


public class UpdateProfileRequest {
    public String first_name;
    public String last_name;
    public String image_id;
}
