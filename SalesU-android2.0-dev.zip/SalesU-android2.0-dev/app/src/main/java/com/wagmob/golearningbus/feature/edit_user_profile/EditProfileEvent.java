package com.wagmob.golearningbus.feature.edit_user_profile;

/**
 * For Event Bus
 */

public class EditProfileEvent {
    public boolean isUserProfileUpdate;

    public EditProfileEvent(boolean isUserUpload)
    {
        isUserProfileUpdate=isUserUpload;
    }

    public boolean getIsUserUpdateProfile()
    {
        return isUserProfileUpdate;
    }
}
