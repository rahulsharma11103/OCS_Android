package com.wagmob.golearningbus.feature.flashcard;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatCheckBox;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.LinearSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SnapHelper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.assignments.UpdateProgressForSectionEvent;
import com.wagmob.golearningbus.feature.edit_user_profile.EditProfileEvent;
import com.wagmob.golearningbus.model.FlashCardModel;
import com.wagmob.golearningbus.model.FlashCardModelLetters;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.requestModel.AssignmentRequest;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import java.util.List;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnCheckedChanged;
import butterknife.OnClick;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

/**
 * Created by Rahul on 8/24/2017.
 */

public class FlashCardFragment extends LoadDataFragment {

    @BindString(R.string.network_message)
    String mNetworkMessage;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.web_service_to_get_quiz)
    String mAssignmentWebServiceUrl;
    @BindView(R.id.flashcard_items_recycler_view)
    RecyclerView mFlashCardRecyclerViewItem;
    @BindView(R.id.dictionary_check_box)
    AppCompatCheckBox mDictionaryCheckBox;
    @BindView(R.id.flashcard_check_box)
    AppCompatCheckBox mFlashCardCheckBox;
    @BindView(R.id.flashcard_items_details_recycler_view)
    RecyclerView mFlashCardItemDetailsRecyclerView;
    @BindView(R.id.card_number_view)
    AppCompatTextView mCardCountView;
    @BindString(R.string.web_service_set_assignment_progress)
    String mWebServiceURlForSetAssignmentProgress;

    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    Gson mGson;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    EventBus mEventBus;

    FlashCardFragment mFlashCardFragment;
    Context mContext;
    String mAssingmentId;
    FlashCardListItemAdapter mFlashCardListItemAdapter;
    FlashCardListItemDetailsAdapter mFlashCardListItemDetailsAdapter;
    List<FlashCardModelLetters> mFlashCardModelLetters;
    SnapHelper mSnapHelper;
    FlashCardListItemAdapter.FlashCardListItemAdapterInterface flashCardListItemAdapterInterface = new FlashCardListItemAdapter.FlashCardListItemAdapterInterface() {
        @Override
        public void cardItemClick(int cardPosition) {
            mFlashCardItemDetailsRecyclerView.smoothScrollToPosition(cardPosition);
        }
    };
    private Unbinder mUnbinder;
    private String mParamName, mSlugUrl, mMethodType;
    private boolean isAccessTokenExpire;
    private boolean isSetProgress;

    public FlashCardFragment newInstance(Context context, String assignmentId) {
        mFlashCardFragment = new FlashCardFragment();
        mFlashCardFragment.mContext = context;
        mFlashCardFragment.mAssingmentId = assignmentId;
        return mFlashCardFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.flash_card, container, false);
        mUnbinder = ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initializeComponent();
        setupUI();
        loadFlashCardData();
    }

    private void setupUI() {


        mFlashCardListItemAdapter = new FlashCardListItemAdapter(mContext, mFlashCardModelLetters);
        mFlashCardRecyclerViewItem.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false));
        mFlashCardRecyclerViewItem.setAdapter(mFlashCardListItemAdapter);
        mFlashCardListItemAdapter.initialteInterfaceListner(flashCardListItemAdapterInterface);

        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false);
        mFlashCardListItemDetailsAdapter = new FlashCardListItemDetailsAdapter(mContext, mFlashCardModelLetters);
        mFlashCardItemDetailsRecyclerView.setLayoutManager(linearLayoutManager);
        mFlashCardItemDetailsRecyclerView.setAdapter(mFlashCardListItemDetailsAdapter);

        mSnapHelper = new StartSnapHelper();
        mSnapHelper.attachToRecyclerView(mFlashCardItemDetailsRecyclerView);
        mFlashCardItemDetailsRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

            }

            /**
             * Callback method to be invoked when the RecyclerView has been scrolled. This will be
             * called after the scroll has completed.
             * <p>
             * This callback will also be called if visible item range changes after a layout
             * calculation. In that case, dx and dy will be 0.
             *
             * @param recyclerView The RecyclerView which scrolled.
             * @param dx           The amount of horizontal scroll.
             * @param dy           The amount of vertical scroll.
             */
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int position = linearLayoutManager.findFirstCompletelyVisibleItemPosition();
                if (position >= 0) {
                    mFlashCardRecyclerViewItem.smoothScrollToPosition(position);
                    mFlashCardListItemAdapter.setBorderColorInItems(position);
                    setCardCount(++position);
                }
            }
        });
    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        if (mContext != null)
            ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }


    /**
     * To load Assignment list
     */
    private void loadFlashCardData() {
        showLoading();
        callCategoryListWebService("na", mAssignmentWebServiceUrl + "?assignment_id=" + mAssingmentId, SalesUConstants.GET_METHOD_TYPE);
    }

    @OnClick(R.id.dictionary_check_box)
    public void dictionaryCheckBoxClicked() {
        mDictionaryCheckBox.setChecked(true);
        mFlashCardCheckBox.setChecked(false);
        if (mFlashCardListItemDetailsAdapter != null) {
            mFlashCardListItemDetailsAdapter.isFlashCardItemChecked(false);
        }
    }


    @OnClick(R.id.flashcard_check_box)
    public void flashCardCheckBoxClicked() {
        mDictionaryCheckBox.setChecked(false);
        mFlashCardCheckBox.setChecked(true);
        if (mFlashCardListItemDetailsAdapter != null) {
            mFlashCardListItemDetailsAdapter.isFlashCardItemChecked(true);
        }

    }

    public void setCardCount(int currentItem) {
        if (mFlashCardModelLetters != null) {
            mCardCountView.setText("Card " + currentItem + " of " + mFlashCardModelLetters.size());
            if (currentItem == mFlashCardModelLetters.size()) {
                setProgress();
            }
        }
    }

    /**
     * call All Courses Web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callCategoryListWebService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new GetFlashcardListItem().execute();
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    private void flashCardServiceResponse(String s) {

        hideLoading();
        try {
            FlashCardModel flashCardModel = mGson.fromJson(s, FlashCardModel.class);
            if (flashCardModel != null) {
                mFlashCardModelLetters = flashCardModel.data.assignment.letters;
                mFlashCardListItemAdapter.setFlashCardItems(mFlashCardModelLetters);
                mFlashCardListItemDetailsAdapter.setFlashCardItems(mFlashCardModelLetters);

            }
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (getView() != null) {
            if (mFlashCardListItemDetailsAdapter != null) {
                mFlashCardListItemDetailsAdapter.setFlashCardItems(mFlashCardModelLetters);
            }
        }
    }

    private void setProgress() {
        isSetProgress = true;
        if (mGlobalApp.isNetworkAvailable()) {
            AssignmentRequest assignmentRequest = new AssignmentRequest();
            assignmentRequest.assignment_id = mAssingmentId;
            String paramName = mGson.toJson(assignmentRequest);
            callCategoryListWebService(paramName, mWebServiceURlForSetAssignmentProgress, SalesUConstants.POST_METHOD_TYPE);
        } else {
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * calling of Flashcard Web service
     */
    class GetFlashcardListItem extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new GetFlashcardListItem().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new GetFlashcardListItem().execute();
                    } else {
                        if (!isSetProgress) {
                            flashCardServiceResponse(s);
                        } else {
                            mEventBus.post(new EditProfileEvent(true));
                            mEventBus.post(new UpdateProgressForSectionEvent(true));
                            isSetProgress = false;
                        }
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.getMessage());
            }

        }
    }

}

