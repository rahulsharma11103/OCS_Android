package com.wagmob.golearningbus.feature.allcategories;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.List;

/**
 * Created by Rahul on 8/1/2017.
 */

public class PromotionalViewPagerAdapter extends FragmentPagerAdapter {
    List<String> mPromoImageList;

    public PromotionalViewPagerAdapter(List<String> promoImageList, FragmentManager fm) {
        super(fm);
        mPromoImageList = promoImageList;
    }

    /**
     * Return the Fragment associated with a specified position.
     *
     * @param position
     */
    @Override
    public Fragment getItem(int position) {
        PromotionalImage promotionalImage = new PromotionalImage();
        promotionalImage.setImageUrl(mPromoImageList.get(position));
        return promotionalImage;
    }

    /**
     * Return the number of views available.
     */
    @Override
    public int getCount() {
        return mPromoImageList != null ? mPromoImageList.size() : 0;
    }
}
