package com.wagmob.golearningbus.feature.perfect_the_pitch;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.navigator.BaseNavigator;

import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

/**
 * Fragment  for perfect the pitch
 */
public class PerfectThePitchFragment extends Fragment {
    private static Context mContext;
    private Unbinder mUnBinder;


    public static Fragment newInstance(Context context) {
        mContext = context;
        return new PerfectThePitchFragment();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.perfect_the_pitch_fragment, container, false);
        mUnBinder = ButterKnife.bind(this, view);
        return view;
    }

    @OnClick(R.id.your_pitch_img)
    public void yourPitch() {

        new BaseNavigator().navigateToYourPitch(mContext);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        mUnBinder.unbind();
    }
}
