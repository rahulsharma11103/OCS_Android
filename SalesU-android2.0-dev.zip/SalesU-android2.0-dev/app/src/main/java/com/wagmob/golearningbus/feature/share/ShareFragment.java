package com.wagmob.golearningbus.feature.share;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;


import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;


public class ShareFragment extends LoadDataFragment {

    @Nullable
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindString(R.string.empty_field_message)
    String mEmptyMessage;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @Inject
    Gson mGson;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @BindString(R.string.something__went_wrong)
    String mSomethingWentWrong;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindView(R.id.share_more_option_list)
    RecyclerView mShareMoreOptionRecyclerView;
    @BindView(R.id.adView)
    AdView mAdView;

    private static Context mContext;
    private Unbinder mUnBinder;
    List<ResolveInfo> mListApp;
    ShareAdapter mShareAdapter;


    public static ShareFragment newInstance(Context ctx) {
        mContext = ctx;
        return new ShareFragment();
    }

    /**
     * Listener for All shares
     */
    private ShareAdapter.ShareAdapterInterface categoryAdapterListener = new ShareAdapter.ShareAdapterInterface() {

        @Override
        public void shareOptionSelectEvent(ResolveInfo appInfo) {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, SalesUConstants.MARKET_PLACE_URL + mContext.getPackageName());
            if (appInfo != null) {
                sendIntent
                        .setComponent(new ComponentName(
                                appInfo.activityInfo.packageName,
                                appInfo.activityInfo.name));
            }
            sendIntent.setType("text/plain");
            startActivity(sendIntent);
        }
    };

    /**
     * Load UI
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(mContext!=null) {
            setupUI();
            initializeComponent();
            setUpBannerImage();
        }
    }

    private void setUpBannerImage() {
        if (mSharedPreference != null) {
            boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

            if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                AdRequest adRequest = new AdRequest.Builder().build();
                mAdView.loadAd(adRequest);
            } else {
                mAdView.setVisibility(View.GONE);
            }
        }
    }

    private void setupUI() {
        mListApp = showAllShareApp();
        mShareMoreOptionRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mShareAdapter = new ShareAdapter(mContext, mListApp);
        mShareAdapter.setOnItemClickListener(categoryAdapterListener);
        mShareMoreOptionRecyclerView.setAdapter(mShareAdapter);
    }


    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View loginView = inflater.inflate(R.layout.share_fragment, container, false);
        mUnBinder = ButterKnife.bind(this, loginView);
        return loginView;
    }

    /**
     * initialize dagger component
     */
    private void initializeComponent() {
        ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item = menu.findItem(R.id.search_icon);
        item.setVisible(false);
        super.onPrepareOptionsMenu(menu);
    }

    private List<ResolveInfo> showAllShareApp() {
        java.util.List<ResolveInfo> mApps = new ArrayList<ResolveInfo>();
        Intent intent = new Intent(Intent.ACTION_SEND, null);
        intent.putExtra(Intent.EXTRA_TEXT, "This is my text to send.");
        intent.setType("text/plain");
        PackageManager pManager = mContext.getPackageManager();
        mApps = pManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        return mApps;
    }




}
