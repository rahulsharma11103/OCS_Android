package com.wagmob.golearningbus.feature.Tour;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.model.AppSettingModelSplash;
import com.wagmob.golearningbus.model.TourDotModel;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.view.BaseFragment;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

/**
 * Fragment For Tour
 *
 * @author Rahul Sharma.
 */

public class TourFragment extends BaseFragment {

    private static Context mContext;
    @BindView(R.id.tour_view_pager)
    ViewPager mPager;

    @BindView(R.id.dot_recycler_view)
    RecyclerView mDotRecyclerView;

    @BindView(R.id.bottom_layout)
    RelativeLayout mBottomLayout;

    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;




    private Unbinder mUnBinder;
    private DotRecyclerAdapter mDotRecyclerAdapter;

    /**
     * @param ctx Context of Activity
     * @return Current Class Instance
     */
    public static TourFragment newInstance(Context ctx) {
        mContext = ctx;
        return new TourFragment();
    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View loginView = inflater.inflate(R.layout.tour_fragment, container, false);
        mUnBinder = ButterKnife.bind(this, loginView);
        initializeComponent();
        //   mBottomLayout.setBackgroundColor(Color.parseColor(mGlobalApp.appSettingModel.data.settings.color_primary_hex));
        return loginView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (mContext != null) {
            setupRecyclerViewForDot();
            setUpViewPager();
        }
    }

    private void setupRecyclerViewForDot() {
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.splash != null) {
            AppSettingModelSplash appSettingModelSplash = new AppSettingModelSplash();
            appSettingModelSplash.splash_type = SalesUConstants.SPLASH_TYPE_GUEST_LOGIN;
            mGlobalApp.appSettingModel.data.splash.add(appSettingModelSplash);
            List<TourDotModel> tourDotModelList = createTourModelList(0);

            mDotRecyclerAdapter = new DotRecyclerAdapter(mContext, tourDotModelList);
            LinearLayoutManager layoutManager
                    = new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false);
            mDotRecyclerView.setLayoutManager(layoutManager);
            mDotRecyclerView.setAdapter(mDotRecyclerAdapter);
        }
    }

    private void setUpViewPager() {
        if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.splash != null) {
            TourSliderPagerAdapter tourSliderPagerAdapter = new TourSliderPagerAdapter(getFragmentManager(), mContext, mGlobalApp.appSettingModel.data.splash);
            mPager.setAdapter(tourSliderPagerAdapter);
            mPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(int position) {
                    List<TourDotModel> tourDotModelList = createTourModelList(position);
                    mDotRecyclerAdapter.setAssignmentItems(tourDotModelList);
                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });
            int a = mPager.getCurrentItem();
        }
    }

    private List<TourDotModel> createTourModelList(int selectedDot) {
        List<TourDotModel> tourDotModelList = new ArrayList<>();
        for (int i = 0; i < mGlobalApp.appSettingModel.data.splash.size(); i++) {
            TourDotModel tourDotModel = new TourDotModel();
            tourDotModel.tourNumber = i;
            if (i == selectedDot) {
                tourDotModel.isSelected = true;
            } else {
                tourDotModel.isSelected = false;
            }
            tourDotModelList.add(tourDotModel);

        }
        return tourDotModelList;
    }

    /**
     * Initialize Dagger Components
     */
    private void initializeComponent() {
        if (mContext != null) {
            ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
        }
    }

    @OnClick(R.id.sign_in_view)
    public void tourSkip() {
        if (mSharedPreference.getBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, false)) {
            new BaseNavigator().navigateToHomeActivity(mContext);
        } else {
            new BaseNavigator().navigateToLoginActivity(mContext);
        }
    }

    @OnClick(R.id.sign_up_view)
    public void notShownAgain() {
        new BaseNavigator().navigateToSignUp(mContext);
    }


    /**
     * Unbind Butter knife object
     */
    @Override
    public void onDestroy() {
        super.onDestroy();
        mUnBinder.unbind();
    }

}
