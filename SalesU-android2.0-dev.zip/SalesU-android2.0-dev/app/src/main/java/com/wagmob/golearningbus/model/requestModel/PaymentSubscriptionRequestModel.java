package com.wagmob.golearningbus.model.requestModel;



public class PaymentSubscriptionRequestModel {
    public String course_id;
    public String nonce;
}
