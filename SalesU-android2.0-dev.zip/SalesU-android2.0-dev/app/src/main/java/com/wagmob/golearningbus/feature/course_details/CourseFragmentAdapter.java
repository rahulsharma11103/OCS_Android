package com.wagmob.golearningbus.feature.course_details;


import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.feature.leaderboard.LeaderBoardFragment;
import com.wagmob.golearningbus.feature.sections.SectionsFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * Pager Adapter for tab layout
 *
 * @author Rahul Sharma
 */
public class CourseFragmentAdapter extends FragmentPagerAdapter {

    List<String> tabTittle;
    String mCourseId;
    private Context mContext;
    private boolean mIsDefaultCourse;

    public CourseFragmentAdapter(Context context, FragmentManager fragmentManager, String courseId,boolean isDefaultCourse) {
        super(fragmentManager);
        mContext = context;
        mCourseId = courseId;
        mIsDefaultCourse=isDefaultCourse;
        tabTittle = new ArrayList<>();
        tabTittle.add(context.getString(R.string.curriculum));
        tabTittle.add(context.getString(R.string.leaderboard));
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0: {
                return SectionsFragment.newInstance(mContext, mCourseId,mIsDefaultCourse);
            }
            case 1: {
                return LeaderBoardFragment.newInstance(mContext, mCourseId);
            }


        }
        return null;
    }

    @Override
    public int getCount() {
        return tabTittle.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return tabTittle.get(position);
    }
}
