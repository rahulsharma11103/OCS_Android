package com.wagmob.golearningbus.feature.allcategories;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;
import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.SalesUApplication;
import com.wagmob.golearningbus.constants.SalesUConstants;
import com.wagmob.golearningbus.feature.app.NonSwipeableViewPager;
import com.wagmob.golearningbus.feature.notification.NotificationPaymentCheck;
import com.wagmob.golearningbus.model.AllCategory;
import com.wagmob.golearningbus.model.CategoriesItem;
import com.wagmob.golearningbus.model.PaidPromotionalImageModel;
import com.wagmob.golearningbus.model.RefreshToken;
import com.wagmob.golearningbus.model.UnPaidPromotionalImageModel;
import com.wagmob.golearningbus.navigator.BaseNavigator;
import com.wagmob.golearningbus.util.AmplitudeUtil;
import com.wagmob.golearningbus.util.ImageUtil;
import com.wagmob.golearningbus.view.LoadDataFragment;
import com.wagmob.golearningbus.webservice_helper.WebServiceHelper;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import timber.log.Timber;

/**
 * Fragment for showing all category list
 *
 * @author Rahul Sharma
 */
public class AllCategoriesFragment extends LoadDataFragment {

    private static Context mContext;
    private static View view;
    @BindView(R.id.progress_bar_layout)
    RelativeLayout mProgressBarLayout;
    @BindView(R.id.categories_list)
    RecyclerView mRecyclerView;
    @BindView(R.id.swipe_to_refresh)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @BindView(R.id.promotional_image_view_pager)
    NonSwipeableViewPager mPromotionalImageViewPager;
    @BindView(R.id.adView)
    AdView mAdView;
    @BindView(R.id.banner_cancel_icon)
    AppCompatImageView mBannerCancelImage;
    @BindString(R.string.web_service_all_category)
    String allCategoryUrl;
    @BindString(R.string.web_service_refresh_token)
    String mRefreshTokenUrl;
    @BindString(R.string.session_expire_message)
    String mSessionExpireMessage;
    @BindString(R.string.something__went_wrong)
    String mSomeThingWentWrong;
    @BindString(R.string.network_message)
    String mNetworkMessage;
    @Inject
    Gson mGson;
    @Inject
    SalesUApplication mGlobalApp;
    @Inject
    SharedPreferences mSharedPreference;
    @Inject
    WebServiceHelper mWebServiceHelper;
    @Inject
    EventBus mEventBus;
    CountDownTimer mCountDownTimer;
    private String mParamName, mSlugUrl, mMethodType;
    private int mNumberOfMore = 0;
    private CategoryAdapter mCategoryAdapter;
    private Unbinder mUnBinder;
    private boolean isAccessTokenExpire, isGetMoreData;
    private int mTotalViewPagerSize;
    boolean mIsNotificationPaymentCheckComplete;

    /**
     * Adapter Listener
     */
    private CategoryAdapter.CategoryAdapterInterface categoryAdapterListener = new CategoryAdapter.CategoryAdapterInterface() {

        @Override
        public void getMoreCategory(int offset) {
            isGetMoreData = true;
            loadCategoriesList(offset);
        }

        @Override
        public void categoryItemClick(CategoriesItem categoriesItem) {
            triggerAmplitudeForCategorySelection(categoriesItem.title);
            new BaseNavigator().navigateToAllCourses(mContext, categoriesItem.category_id, categoriesItem.title);
        }
    };

    /**
     * For return AllCategoriesFragment object
     *
     * @param context activity context
     * @return instance of AllCategoriesFragment
     */
    public static AllCategoriesFragment newInstance(Context context) {
        mContext = context;
        return new AllCategoriesFragment();
    }

    private void triggerAmplitudeForCategorySelection(String title) {
        JSONObject jElement;
        try {
            jElement = new JSONObject();
            jElement.put(AmplitudeUtil.CATEGORY_NAME, title);
            AmplitudeUtil.logAmplitudeEvent(AmplitudeUtil.EVENT_CATEGORY_TAP, jElement);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }
    }

    private void setScrollListener() {

    }

    /**
     * To initialize layout & butter knife
     *
     * @param inflater           for inflate layout
     * @param container
     * @param savedInstanceState
     * @return return view
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.all_categories_fragment, container, false);
        mUnBinder = ButterKnife.bind(this, view);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadCategoriesList(0);
            }
        });
        return view;
    }

    /**
     * For initialize component,setup UI and calling web service
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initializeComponent();
        if(mContext!=null&&mGlobalApp!=null) {
            setUpUi();
            loadCategoriesList(0);
        }
    }

    /**
     * To call category web service
     *
     * @param offset offset number
     */
    private void loadCategoriesList(int offset) {
        if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
            mGlobalApp.categoryItem = null;
        } else {
            showLoading();
        }
        callCategoryListWebService("na", allCategoryUrl + "?limit=" + SalesUConstants.REQUEST_MAX_LIMIT_DATA + "&offset=" + offset, SalesUConstants.GET_METHOD_TYPE);
    }

    /**
     * SetUp Ui and Adapter
     */
    private void setUpUi() {
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mCategoryAdapter = new CategoryAdapter(mContext, new ArrayList<CategoriesItem>(), mRecyclerView);
        mCategoryAdapter.setOnItemClickListener(categoryAdapterListener);
        mRecyclerView.setAdapter(mCategoryAdapter);
    }

    /**
     * Response of category webservice
     *
     * @param response response of web service
     */
    public void categoryWebServiceResponse(String response) {
        try {

            if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                mSwipeRefreshLayout.setRefreshing(false);
            }
            hideLoading();
            boolean isLoadMore = false;
            AllCategory allCategory = mGson.fromJson(response, AllCategory.class);
            if (mGlobalApp.categoryItem == null) {
                mGlobalApp.categoryItem = allCategory.data.categories;
            } else {
                isLoadMore = true;
                mGlobalApp.categoryItem.addAll(allCategory.data.categories);
            }

            mCategoryAdapter.setCategoryCollection(mGlobalApp.categoryItem, isLoadMore);
        } catch (Exception ex) {
            if (SalesUConstants.ISLogVisible) {
                Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
            }
            if (SalesUConstants.ISLogVisible) {
                Timber.e(ex.getMessage());
            }
        }

    }

    /**
     * Initialize Dagger Component
     */
    private void initializeComponent() {
        if(mContext!=null) {
            ((SalesUApplication) ((Activity) mContext).getApplication()).getApplicationModule().inject(this);
        }
    }

    @OnClick(R.id.banner_cancel_icon)
    public void cancelBanner() {
        mBannerCancelImage.setVisibility(View.GONE);
        mPromotionalImageViewPager.setVisibility(View.GONE);
    }

    public void onEvent(NotificationPaymentCheck notificationPaymentCheck) {
        initializeComponent();
        boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);
        boolean isTablet = mContext.getResources().getBoolean(R.bool.isTablet);
        mIsNotificationPaymentCheckComplete=true;
        if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);
        } else {
            mAdView.setVisibility(View.GONE);
        }
        if (mPromotionalImageViewPager != null)
            if (mIsAlreadyPurchase) {
                if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.paidpromotional_images != null
                        ) {
                    if (mGlobalApp.appSettingModel.data.paidpromotional_images.size() > 0) {
                        setTimerHelper();
                        mPromotionalImageViewPager.setVisibility(View.VISIBLE);
                        mBannerCancelImage.setVisibility(View.VISIBLE);
                        List<String> promoImageUrlForPhone = new ArrayList<>();
                        List<String> promoImageForTablet = new ArrayList<>();
                        for (int i = 0; i < mGlobalApp.appSettingModel.data.paidpromotional_images.size(); i++) {
                            PaidPromotionalImageModel paidPromotionalImageModel = mGlobalApp.appSettingModel.data.paidpromotional_images.get(i);
                            promoImageUrlForPhone.add(paidPromotionalImageModel.androidphone_url);
                            promoImageForTablet.add(paidPromotionalImageModel.androidtablet_url);
                        }
                        if (isTablet) {
                            PromotionalViewPagerAdapter promotionalViewPagerAdapter = new PromotionalViewPagerAdapter(promoImageForTablet, getFragmentManager());
                            mPromotionalImageViewPager.setAdapter(promotionalViewPagerAdapter);
                            mTotalViewPagerSize = promoImageForTablet.size();
                            //    new ImageUtil().loadImage(mContext, paidPromotionalImageModel.androidtablet_url, mPromotionalImage, R.drawable.placeholder_default_rectangular, false, true);
                        } else {
                            PromotionalViewPagerAdapter promotionalViewPagerAdapter = new PromotionalViewPagerAdapter(promoImageUrlForPhone, getFragmentManager());
                            mPromotionalImageViewPager.setAdapter(promotionalViewPagerAdapter);
                            mTotalViewPagerSize = promoImageUrlForPhone.size();
                            // new ImageUtil().loadImage(mContext, paidPromotionalImageModel.androidphone_url, mPromotionalImage, R.drawable.placeholder_default_rectangular, false, true);
                        }
                    }
                }
            } else {

                if (mGlobalApp != null && mGlobalApp.appSettingModel != null && mGlobalApp.appSettingModel.data != null && mGlobalApp.appSettingModel.data.unpaidpromotional_images != null
                        ) {
                    if (mGlobalApp.appSettingModel.data.unpaidpromotional_images.size() > 0) {
                        setTimerHelper();
                        mPromotionalImageViewPager.setVisibility(View.VISIBLE);
                        mBannerCancelImage.setVisibility(View.VISIBLE);
                        List<String> promoImageUrlForPhone = new ArrayList<>();
                        List<String> promoImageForTablet = new ArrayList<>();
                        for (int i = 0; i < mGlobalApp.appSettingModel.data.unpaidpromotional_images.size(); i++) {
                            UnPaidPromotionalImageModel paidPromotionalImageModel = mGlobalApp.appSettingModel.data.unpaidpromotional_images.get(i);
                            promoImageUrlForPhone.add(paidPromotionalImageModel.androidphone_url);
                            promoImageForTablet.add(paidPromotionalImageModel.androidtablet_url);
                        }
                        UnPaidPromotionalImageModel unPaidPromotionalImageModel = mGlobalApp.appSettingModel.data.unpaidpromotional_images.get(0);
                        if (isTablet) {
                            PromotionalViewPagerAdapter promotionalViewPagerAdapter = new PromotionalViewPagerAdapter(promoImageForTablet, getFragmentManager());
                            mPromotionalImageViewPager.setAdapter(promotionalViewPagerAdapter);
                            mTotalViewPagerSize = promoImageForTablet.size();
                            //  new ImageUtil().loadImage(mContext, unPaidPromotionalImageModel.androidtablet_url, mPromotionalImage, R.drawable.placeholder_default_rectangular, false, true);

                        } else {
                            PromotionalViewPagerAdapter promotionalViewPagerAdapter = new PromotionalViewPagerAdapter(promoImageUrlForPhone, getFragmentManager());
                            mPromotionalImageViewPager.setAdapter(promotionalViewPagerAdapter);
                            mTotalViewPagerSize = promoImageUrlForPhone.size();
                            //new ImageUtil().loadImage(mContext, unPaidPromotionalImageModel.androidphone_url, mPromotionalImage, R.drawable.placeholder_default_rectangular, false, true);
                        }
                    }
                }
            }

    }

    /**
     * Timer for Auto Slide
     */
    public void setTimerHelper() {
        if (mCountDownTimer != null) {
            mCountDownTimer.cancel();
            mCountDownTimer = null;
        }
        mCountDownTimer = new CountDownTimer(5000, 1000) {

            public void onTick(long millisUntilFinished) {
                /*if (millisUntilFinished == 10000) {
                    mCountDownTimer.cancel();
                }*/
            }

            public void onFinish() {
                if (mPromotionalImageViewPager != null) {
                    if (mPromotionalImageViewPager.getCurrentItem() == mTotalViewPagerSize - 1) {
                        mPromotionalImageViewPager.setCurrentItem(0, true);
                    } else {
                        mPromotionalImageViewPager.setCurrentItem(mPromotionalImageViewPager.getCurrentItem() + 1, true);
                    }
                    setTimerHelper();
                }
                //setTimerHelper(1000);
            }
        }.start();
    }

    /**
     * call All Courses Web service
     *
     * @param paramName  parameter name with value
     * @param path       path of services
     * @param methodType type of method
     */
    public void callCategoryListWebService(String paramName, String path, String methodType) {
        if (mGlobalApp.isNetworkAvailable()) {
            mParamName = paramName;
            mSlugUrl = path;
            mMethodType = methodType;
            new GetCategoryListItem().execute();
        } else {
            if (mSwipeRefreshLayout != null && mSwipeRefreshLayout.isRefreshing()) {
                mSwipeRefreshLayout.setRefreshing(false);
            }
            hideLoading();
            Toast.makeText(mContext, mNetworkMessage, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUnBinder.unbind();
        if (mGlobalApp.categoryItem != null)
            mGlobalApp.categoryItem = null;
    }

    /**
     * register event bus
     */
    @Override
    public void onStart() {
        super.onStart();
        if (!mEventBus.isRegistered(this)) {
            mEventBus.register(this);
        }

    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {

            if (mAdView != null && mIsNotificationPaymentCheckComplete && mSharedPreference != null) {
                boolean mIsAlreadyPurchase = mSharedPreference.getBoolean(SalesUConstants.IS_USER_ALREADY_PURCHASE_ITEM, false);

                if (SalesUConstants.IS_INDIVIDUAL_APP && !mIsAlreadyPurchase) {
                    AdRequest adRequest = new AdRequest.Builder().build();
                    mAdView.loadAd(adRequest);
                } else {
                    mAdView.setVisibility(View.GONE);
                }
            }
        }
    }
    /**
     * To Call Async Web Service
     */
    class GetCategoryListItem extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            String webServiceResponse = "";
            if (isAccessTokenExpire) {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(SalesUConstants.POST_METHOD_TYPE, mParamName, mRefreshTokenUrl);
            } else {
                webServiceResponse = mWebServiceHelper.getWebServiceResponse(mMethodType, mParamName, mSlugUrl);
            }
            return webServiceResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject response = null;
            try {
                response = new JSONObject(s);
                if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_EXPIRE_ACCESS_TOKEN) {
                    isAccessTokenExpire = true;
                    new GetCategoryListItem().execute();
                } else if (response.getInt(SalesUConstants.RESPONSE_CODE_STRING) == SalesUConstants.RESPONSE_CODE_NUMBER_FOR_SUCCESS) {
                    if (isAccessTokenExpire) {
                        isAccessTokenExpire = false;
                        RefreshToken refreshToken = mGson.fromJson(s, RefreshToken.class);
                        SharedPreferences.Editor editor = mSharedPreference.edit();
                        editor.putString(SalesUConstants.SHARED_ACCESS_TOKEN, refreshToken.data.session.accesstoken);
                        editor.putString(SalesUConstants.SHARED_REFRESH_TOKEN, refreshToken.data.session.refreshtoken);
                        editor.putBoolean(SalesUConstants.SHARED_IS_ALREADY_LOGGED_IN, true);
                        editor.commit();
                        new GetCategoryListItem().execute();
                    } else {
                        categoryWebServiceResponse(s);
                    }
                } else {
                    hideLoading();
                    Toast.makeText(mContext, response.getJSONArray(SalesUConstants.RESPONSE_CODE_MESSAGE_STRING).get(0).toString(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                hideLoading();
                if (SalesUConstants.ISLogVisible) {
                    Toast.makeText(mContext, mSomeThingWentWrong, Toast.LENGTH_SHORT).show();
                }
                if (SalesUConstants.ISLogVisible)
                    Timber.e(e.getMessage());
            }

        }
    }
}
