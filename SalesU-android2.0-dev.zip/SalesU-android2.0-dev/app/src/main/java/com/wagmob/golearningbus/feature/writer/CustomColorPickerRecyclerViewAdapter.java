package com.wagmob.golearningbus.feature.writer;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wagmob.golearningbus.R;
import com.wagmob.golearningbus.constants.SalesUConstants;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Anky on 9/15/2017.
 */

public class CustomColorPickerRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public interface CustomRecyclerViewAdapterInterface
    {
        public void colorSelect(int itemPosition);
    }

    CustomRecyclerViewAdapterView mCustomRecyclerViewAdapterView;
    Context mContext;
    CustomRecyclerViewAdapterInterface mCustomRecyclerViewAdapterInterface;

    public CustomColorPickerRecyclerViewAdapter(Context context)
    {
        mContext=context;
    }

    public void intializeInterfaceObject(CustomRecyclerViewAdapterInterface customRecyclerViewAdapterInterface)
    {
        mCustomRecyclerViewAdapterInterface=customRecyclerViewAdapterInterface;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.color_picker_item, parent, false);
        mCustomRecyclerViewAdapterView=new CustomRecyclerViewAdapterView(view);
        return mCustomRecyclerViewAdapterView;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
      mCustomRecyclerViewAdapterView=(CustomRecyclerViewAdapterView)holder;
        mCustomRecyclerViewAdapterView.mColorPickerImage.setCardBackgroundColor(Color.parseColor(SalesUConstants.COLOR_HEX_CODE[position]));
        mCustomRecyclerViewAdapterView.mColorPickerImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mCustomRecyclerViewAdapterInterface!=null)
                {
                    mCustomRecyclerViewAdapterInterface.colorSelect(position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return 12;
    }


    static class CustomRecyclerViewAdapterView extends RecyclerView.ViewHolder {
        @BindView(R.id.card_view)
        CardView mColorPickerImage;

        public CustomRecyclerViewAdapterView(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
