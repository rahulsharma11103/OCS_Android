#!/bin/bash
echo "Let's start"
cp buildConfig/glb_google-service.json app/google-service1.json
echo "done"