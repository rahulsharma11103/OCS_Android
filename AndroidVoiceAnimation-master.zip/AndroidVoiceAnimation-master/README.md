AndroidVoiceAnimation
=====================

A voice animation demo just like google voice search.  
Use the MediaRecorder to record audio, haven't test on most devices.  
Because I use the `ObjectAnimator` class, so the minApiLevel is 11.You can use the [NineOldAndroids](https://github.com/JakeWharton/NineOldAndroids) library to make it backwards compatible.  
You can download the apk [**here**](https://github.com/kyze8439690/AndroidVoiceAnimation/releases/download/v1.0/voice_animation_demo.apk).
![](https://raw.githubusercontent.com/kyze8439690/AndroidVoiceAnimation/master/screenshot.jpg)
