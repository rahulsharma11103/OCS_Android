//
//  LogoViewController.swift
//  OpenVideoCall
//
//  Created by CavanSu on 2019/11/6.
//  Copyright © 2019 Agora. All rights reserved.
//

import Cocoa

class LogoViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.layer?.backgroundColor = NSColor.AGBlue.cgColor
    }
    
}
