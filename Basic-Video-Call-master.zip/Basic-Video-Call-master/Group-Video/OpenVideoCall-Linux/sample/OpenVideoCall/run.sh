#!/bin/bash

./openVideoCall  --appId  \
                 --uid  \
                 --channel demoChannel \
                 --dynamicKey 0 \
                 --channelProfile 1 \
                 --audioProfile 0 \
                 --audioScenario 0 \
                 --videoProfile 0 \
                 --enableVideo 1 \
                 --enableAudio 1 \
                 --muteLocalVideo 0 \
                 --muteLocalAudio 0 \
                 --enableLocalVideo 1 \
                 --enableWebSdkInteroperability 0 \
                 --openVideoCall 0
