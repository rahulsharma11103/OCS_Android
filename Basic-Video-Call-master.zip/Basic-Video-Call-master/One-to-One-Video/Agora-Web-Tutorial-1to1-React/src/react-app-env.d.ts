/// <reference types="react-scripts" />

declare module 'agora-stream-player' {
  const StreamPlayer: any;
  export default StreamPlayer;
}