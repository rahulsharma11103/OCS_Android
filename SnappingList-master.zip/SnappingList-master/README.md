# SnappingList
This is an example of a -horizontal- list that snaps to the selected item.

The example looks like this:

![](http://www.plattysoft.com/wp-content/uploads/2015/06/ezgif.com-crop.gif)

To read more about the details, you can check http://www.plattysoft.com/2015/06/16/snapping-items-on-a-horizontal-list/
