package info.kimjihyok.ripplelibrary;

/**
 * Created by jihyokkim on 2017. 8. 25..
 */

public enum Rate {
  LOW, MEDIUM, HIGH
}
