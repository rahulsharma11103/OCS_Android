package info.kimjihyok.ripplelibrary.listener;

/**
 * Created by jihyokkim on 2017. 8. 28..
 */

public interface RecordingListener {
  void onRecordingStopped();
  void onRecordingStarted();
}
