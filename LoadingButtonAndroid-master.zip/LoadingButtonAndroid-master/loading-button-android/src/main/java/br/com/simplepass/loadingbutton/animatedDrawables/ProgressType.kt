package br.com.simplepass.loadingbutton.animatedDrawables

enum class ProgressType {
    DETERMINATE, INDETERMINATE
}
