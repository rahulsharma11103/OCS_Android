# Facebook Live Streaming Likes Button Animation
![alt tag](https://github.com/paddypatil90/FacebookLiveStreamingLikeAnimation/blob/master/videotogif_2017.04.02_23.34.39.gif)
